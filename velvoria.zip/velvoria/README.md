# VELVORIA — Online Store

A complete fashion & footwear store: homepage, clothing and sneaker catalogs with filters, product pages with US/EU sizing, shopping bag, wishlist, search, customer accounts, an admin dashboard, and **card payments through Stripe Checkout**.

> **Status:** the code is complete. Payments, accounts and order emails only work after **you** connect your own Supabase and Stripe accounts (steps below) and run a test order. Nothing is live until then.

---

## Words you'll see (plain-English glossary)

| Term | What it means |
|---|---|
| **Next.js** | The framework the website is built with. It runs the pages and the server code. |
| **Supabase** | Your database (where products, orders and customers are stored) plus log-in and photo storage. |
| **Stripe** | The payment company. Customers type their card on Stripe's secure page, so card numbers never touch your site. |
| **Stripe Checkout** | Stripe's ready-made payment page (supports cards, Apple Pay, Google Pay, Link). |
| **Webhook** | A message Stripe sends to your site saying "this payment succeeded". Your site then marks the order paid and reduces stock. |
| **Environment variables** | Secret settings (like passwords/keys) kept outside the code, in a file called `.env.local` or in your hosting dashboard. |
| **Vercel** | A hosting company that puts the site on the internet. (Any Next.js host works.) |
| **RLS (Row Level Security)** | Database rules that stop customers from reading other customers' data or editing prices. |
| **Demo product** | One of the 27 sample products. They show on the site with a "Sample product" tag but **cannot be bought** until you replace them. |

---

## What you need (all have free starter plans)

1. A **Supabase** account — https://supabase.com
2. A **Stripe** account — https://stripe.com
3. A **Vercel** account — https://vercel.com (and a GitHub account to upload the code)
4. **Node.js 20 or newer** on your computer if you want to run it locally first — https://nodejs.org

---

## Setup — step by step

### Step 1 · Create the database (Supabase)
1. In Supabase, click **New project**. Pick a name and a strong database password.
2. Open **SQL Editor → New query**. Paste the whole of `supabase/schema.sql` and click **Run**.
3. New query again: paste `supabase/seed.sql` and **Run**. This adds sizes, categories, collections, 27 sample products, 2 discount codes (`WELCOME10`, `STEP20`) and homepage banners.
4. Go to **Project Settings → API** and copy:
   - Project URL → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon` public key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` secret key → `SUPABASE_SERVICE_ROLE_KEY` (**never share this one**)
5. Go to **Authentication → URL Configuration**:
   - **Site URL:** your website address (e.g. `https://velvoria.com`, or `http://localhost:3000` while testing)
   - **Redirect URLs:** add `https://YOUR-DOMAIN/auth/callback` (and `http://localhost:3000/auth/callback`)

### Step 2 · Set up payments (Stripe) — use **Test mode** first
1. In Stripe, make sure the **Test mode** switch is on.
2. **Developers → API keys** → copy the **Secret key** (`sk_test_…`) → `STRIPE_SECRET_KEY`.
3. **Settings → Payment methods**: turn on the methods you want (cards are on by default; Apple Pay / Google Pay / Link are optional).
4. **Settings → Customer emails**: turn on **Successful payments** so customers get a receipt email from Stripe.

### Step 3 · Put the site online (Vercel)
1. Upload this folder to a new GitHub repository.
2. In Vercel: **Add New → Project**, choose the repository.
3. Under **Environment Variables**, add every line from `.env.example` with your real values. Set `NEXT_PUBLIC_SITE_URL` to your Vercel address (e.g. `https://velvoria.vercel.app`) and `ALLOW_DEMO_CHECKOUT` to `true` **only for testing**.
4. Click **Deploy**.

### Step 4 · Connect the webhook (this is what marks orders as paid)
1. Stripe → **Developers → Webhooks → Add endpoint**.
2. Endpoint URL: `https://YOUR-DOMAIN/api/webhooks/stripe`
3. Select these events: `checkout.session.completed`, `checkout.session.async_payment_succeeded`, `checkout.session.async_payment_failed`, `checkout.session.expired`, `charge.refunded`.
4. Copy the **Signing secret** (`whsec_…`) into Vercel as `STRIPE_WEBHOOK_SECRET`, then **redeploy**.

### Step 5 · Make yourself the admin
1. On your live site, click the account icon and **create an account** (confirm the email).
2. In Supabase **SQL Editor**, run (with your email):
   ```sql
   update public.profiles set is_admin = true where email = 'you@example.com';
   ```
3. Sign out and back in. You'll now see **Admin dashboard** in your account menu (`/admin`).

### Step 6 · Run a test order
1. Add a product to the bag → **Checkout securely**.
2. On Stripe's page use the test card **4242 4242 4242 4242**, any future date, any 3-digit CVC, any ZIP.
3. You should land on the "order confirmed" page. In **Admin → Orders** the order should say **paid**, and stock for that size should drop by 1.
4. If the order stays "Awaiting payment", the webhook isn't connected — re-check Step 4.

### Step 7 · Go live
- [ ] Replace demo products: **Admin → Products → Remove all demo products**, then add your own (name → colorways → sizes → stock → photos). Untick "Demo product" on real items.
- [ ] Upload real photography (4:5 ratio, JPG/PNG/WebP, ≤ 5 MB). Until you do, products show a clearly labelled drawn placeholder.
- [ ] Upload a hero campaign photo in **Admin → Homepage banners**.
- [ ] Fill in the `[bracketed]` details in `app/(info)/content.tsx` and `app/contact/page.tsx` (business name, email, address) and have the Privacy Policy and Terms reviewed.
- [ ] Set `ALLOW_DEMO_CHECKOUT=false`.
- [ ] In Stripe, switch off Test mode, complete account activation, then repeat Step 2 (live `sk_live_…` key) and Step 4 (a **live** webhook with its own signing secret). Update both in Vercel and redeploy.
- [ ] Do one real purchase with your own card, then refund it from Stripe (the order will change to "refunded").
- [ ] Optional: in Stripe, set up **Stripe Tax** and add `STRIPE_AUTOMATIC_TAX=true` to collect sales tax automatically.
- [ ] Optional: Supabase → Authentication → **SMTP Settings** to send sign-up/password emails from your own domain (Supabase's built-in sender is rate-limited).

---

## Running it on your own computer (optional)
```bash
npm install
cp .env.example .env.local   # then fill in your keys
npm run dev                  # open http://localhost:3000
```
To test the webhook locally, install the Stripe CLI and run
`stripe listen --forward-to localhost:3000/api/webhooks/stripe` — it prints a `whsec_…` secret to put in `.env.local`.

---

## What's included

**Shopping:** homepage (hero, Trending Now, Shop by Category, New Arrivals, STEP INTO YOUR STYLE, Sneaker Spotlight, The Everyday Edit, Best Sellers, Complete the Look, Seasonal Collections, Newsletter, Recently Viewed) · Shoes & Sneakers dropdown · catalogs for New Arrivals, Women, Men, Clothing, Shoes & Sneakers, Accessories, Sale, every category and collection · filters (category, men's/women's/unisex, brand, US size, EU size, clothing size, color, price, style, availability, new, best sellers, sale) · sorting (featured, newest, popularity, price) · search with live suggestions · product cards with alternate angle on hover, colorway swatches, badges, wishlist, Quick View and availability · product pages with side/top/back/outsole/detail views, swipeable gallery, zoom, colorway + US/EU size selection that updates the exact variant and stock, separate shoe and clothing size guides, fit notes, materials, reviews with fit feedback, related products and outfit recommendations, sticky mobile Add to Bag.

**Bag & checkout:** slide-out bag, quantity controls, remove, discount codes, free-shipping progress, guest checkout, Stripe Checkout (standard/express shipping), confirmation page, order history. **All prices, discounts and shipping are recalculated on the server** — the browser's numbers are never trusted.

**Accounts:** register, sign in, password reset, profile, saved addresses, order history with status and tracking, wishlist synced across devices, bag saved to the account.

**Admin (`/admin`):** sales analytics (revenue, paid orders, average order, units, 14-day chart, top products, low stock) · add/edit/hide products · colorways · shoe and clothing sizes · per-size, per-colorway stock and price overrides · sale % tool · photo uploads (type, size and file-content checked) · categories (incl. new footwear categories) · collections · featured sneakers · homepage banners · discount codes · orders with status and tracking · review approval. Every admin page and action checks admin rights on the server.

**Pages:** About, Contact (form), FAQ, Shipping, Returns, Privacy Policy, Terms, size guides, 404, sitemap.xml, robots.txt, product structured data for Google.

## What is NOT set up (be aware)
- **Order/shipping emails from your store** are not sent. Stripe sends payment receipts (Step 2.4). Shipping updates appear in the customer's account.
- **Shipping carriers** (live rates, labels) aren't connected — shipping is a flat $7.95 (free over $100) or $18 express. Change these in `lib/shipping.ts`.
- **Sales tax** is off until you enable Stripe Tax.
- **Shipping is US-only** (`allowed_countries` in `app/api/checkout/route.ts`).
- **Stock is reduced when payment succeeds**, not when someone opens checkout, so two people buying the very last pair at the same moment could both succeed. You'd refund one. Fine for small stores.
- **Real photography** — the sample products use drawn placeholders labelled "IMAGE PLACEHOLDER".

## How this was checked before delivery
- The database files were run on PostgreSQL 16: all tables, security rules and 27 products load. The payment-completion step ran twice on the same order and only counted once. A signed-in customer could not make themselves admin, could not see discount codes or other orders, and could not approve their own review.
- The TypeScript code passed a type check, and the stylesheet compiled with Tailwind CSS v4.
- The homepage, sneaker catalog and product page were rendered with the sample data and screenshotted on desktop and mobile (see `docs/`).
- **Not yet done:** a full `npm run build` and a live Stripe test payment. The build needs internet access to download packages, so run Steps 1–6 to finish verification. If `npm run build` reports an error, it will name the file and line.

## Project map
```
app/                 pages (each folder = a web address)
  api/checkout       creates the Stripe payment page (server-side totals)
  api/webhooks/stripe  marks orders paid, reduces stock
  admin/             admin dashboard
  account/           customer account
components/          building blocks (header, product card, bag, filters…)
lib/                 data access, pricing, shipping rules, security helpers
supabase/schema.sql  database tables + security rules
supabase/seed.sql    sample products (regenerate: npm run seed:generate)
```
