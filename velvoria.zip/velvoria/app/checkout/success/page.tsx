import type { Metadata } from "next";
import Link from "next/link";
import { getStripe } from "@/lib/stripe";
import { createAdminClient } from "@/lib/supabase/admin";
import { money } from "@/lib/format";
import { ClearCart } from "./ClearCart";

export const metadata: Metadata = { title: "Order confirmed", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function Page({ searchParams }: { searchParams: Promise<{ session_id?: string }> }) {
  const { session_id } = await searchParams;
  if (!session_id || !/^cs_[A-Za-z0-9_]+$/.test(session_id)) return <Message title="Order not found" body="We couldn't find that checkout session." />;

  let paid = false;
  try {
    const session = await getStripe().checkout.sessions.retrieve(session_id);
    paid = session.payment_status === "paid";
  } catch {
    return <Message title="Order not found" body="We couldn't find that checkout session." />;
  }
  const admin = createAdminClient();
  const { data: order } = await admin.from("orders").select("*, order_items(*)").eq("stripe_session_id", session_id).maybeSingle();
  if (!order) return <Message title="Order not found" body="We couldn't find that order." />;

  return (
    <div className="container-x max-w-2xl pt-14">
      {paid && <ClearCart />}
      <p className="eyebrow mb-2">Order #{order.order_number}</p>
      <h1 className="headline text-4xl sm:text-5xl">{paid ? "Thank you — your order is confirmed." : "We're confirming your payment."}</h1>
      <p className="mt-4 text-ink-soft">
        {paid ? `A receipt will be sent${order.email ? ` to ${order.email}` : ""} by our payment provider. We'll update your order status when it ships.`
          : "Your payment is processing. This page will show the confirmation once it completes — you can refresh in a moment."}
      </p>
      <ul className="mt-10 divide-y divide-charcoal/10 border-y border-charcoal/10">
        {(order.order_items as { id: string; name: string; color: string; size: string; quantity: number; unit_price_cents: number }[]).map((i) => (
          <li key={i.id} className="flex justify-between py-4 text-sm">
            <span>{i.name}<span className="block text-xs text-ink-soft">{i.color} · {i.size} · Qty {i.quantity}</span></span>
            <span>{money(i.unit_price_cents * i.quantity)}</span>
          </li>
        ))}
      </ul>
      <dl className="mt-4 space-y-1 text-sm">
        <div className="flex justify-between"><dt>Subtotal</dt><dd>{money(order.subtotal_cents)}</dd></div>
        {order.discount_cents > 0 && <div className="flex justify-between"><dt>Discount ({order.discount_code})</dt><dd>−{money(order.discount_cents)}</dd></div>}
        <div className="flex justify-between"><dt>Shipping</dt><dd>{order.shipping_cents ? money(order.shipping_cents) : "Free"}</dd></div>
        {order.tax_cents > 0 && <div className="flex justify-between"><dt>Tax</dt><dd>{money(order.tax_cents)}</dd></div>}
        <div className="flex justify-between border-t border-charcoal/10 pt-2 font-medium"><dt>Total</dt><dd>{money(order.total_cents)}</dd></div>
      </dl>
      <div className="mt-10 flex flex-wrap gap-3">
        <Link href="/" className="btn-dark">Continue shopping</Link>
        {order.user_id ? <Link href="/account/orders" className="btn-outline">View order history</Link> : <Link href="/register" className="btn-outline">Create an account</Link>}
      </div>
    </div>
  );
}

function Message({ title, body }: { title: string; body: string }) {
  return (
    <div className="container-x max-w-xl py-24 text-center">
      <h1 className="headline text-4xl">{title}</h1>
      <p className="mt-3 text-ink-soft">{body}</p>
      <Link href="/" className="btn-dark mt-8">Back to shop</Link>
    </div>
  );
}
