"use client";

import { useEffect } from "react";
import { useStore } from "@/components/StoreProvider";

export function ClearCart() {
  const { clearCart, ready } = useStore();
  useEffect(() => {
    if (ready) { clearCart(); try { sessionStorage.removeItem("vel_code"); } catch {} }
  }, [ready, clearCart]);
  return null;
}
