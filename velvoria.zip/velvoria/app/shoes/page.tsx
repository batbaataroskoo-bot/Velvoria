import type { Metadata } from "next";
import { Catalog } from "@/components/Catalog";
import type { SP } from "@/lib/filters";

export const metadata: Metadata = { title: "Shoes & Sneakers", description: "Lifestyle, retro and running-inspired sneakers, high-tops, boots, sandals and slides.", alternates: { canonical: "/shoes" } };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  return (
    <Catalog title="Shoes & Sneakers" eyebrow="Footwear" intro="From everyday low-tops to retro runners — filter by US or EU size, colorway and style."
      preset={{ department: "footwear" }} searchParams={await searchParams} basePath="/shoes"
      quickLinks={[["All Sneakers", "/shoes?category=sneakers"], ["Lifestyle", "/shop/lifestyle-sneakers"], ["Everyday", "/shop/everyday-sneakers"], ["Retro", "/shop/retro-sneakers"], ["Running-Inspired", "/shop/running-inspired-sneakers"], ["High-Top", "/shop/high-top-sneakers"], ["Low-Top", "/shop/low-top-sneakers"], ["Casual Shoes", "/shop/casual-shoes"], ["Boots", "/shop/boots"], ["Sandals", "/shop/sandals"], ["Slides", "/shop/slides"], ["Shoe Size Guide", "/size-guide/shoes"]]} />
  );
}
