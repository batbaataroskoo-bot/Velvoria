import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Catalog } from "@/components/Catalog";
import { getCollections } from "@/lib/catalog";
import type { SP } from "@/lib/filters";

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<SP> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const c = (await getCollections()).find((x) => x.slug === slug);
  return c ? { title: c.name, description: c.description ?? undefined, alternates: { canonical: `/collections/${slug}` } } : {};
}

export default async function Page({ params, searchParams }: Props) {
  const { slug } = await params;
  const c = (await getCollections()).find((x) => x.slug === slug);
  if (!c) notFound();
  return <Catalog title={c.name} eyebrow={c.is_seasonal ? "Seasonal collection" : "Collection"} intro={c.description ?? undefined}
    preset={{ collection: c.slug }} searchParams={await searchParams} basePath={`/collections/${c.slug}`} />;
}
