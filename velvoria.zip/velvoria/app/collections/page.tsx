import type { Metadata } from "next";
import { getAllProducts, getCollections } from "@/lib/catalog";
import { EditorialTile } from "@/components/Sections";
import { ProductMedia, anglesFor } from "@/components/ProductMedia";
import { Reveal } from "@/components/Reveal";

export const revalidate = 60;
export const metadata: Metadata = { title: "Collections", description: "Seasonal campaigns, outfit edits and sneaker spotlights.", alternates: { canonical: "/collections" } };

export default async function Page() {
  const [collections, products] = await Promise.all([getCollections(), getAllProducts()]);
  return (
    <div className="container-x pt-10 sm:pt-14">
      <p className="eyebrow mb-2">Edits & campaigns</p>
      <h1 className="headline mb-10 text-4xl sm:text-6xl">Collections</h1>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {collections.map((c, i) => {
          const cover = products.find((p) => p.collections.includes(c.slug));
          return (
            <Reveal key={c.id} delay={(i % 3) * 0.06}>
              <EditorialTile href={`/collections/${c.slug}`} title={c.name} eyebrow={c.is_seasonal ? "Seasonal" : "Edit"} image={c.image_url} className="aspect-[4/5]">
                {cover && <ProductMedia product={cover} angle={anglesFor(cover).at(-1) ?? "front"} sizes="33vw" className="h-full" />}
              </EditorialTile>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}
