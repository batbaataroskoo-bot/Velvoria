"use server";

import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";

export type FormState = { ok: boolean; message: string } | null;

export async function subscribeNewsletter(_: FormState, form: FormData): Promise<FormState> {
  if (form.get("company")) return { ok: true, message: "Thanks!" }; // spam trap
  const parsed = z.string().trim().toLowerCase().email().max(200).safeParse(form.get("email"));
  if (!parsed.success) return { ok: false, message: "Please enter a valid email address." };
  const { error } = await createAdminClient().from("newsletter_subscribers").upsert({ email: parsed.data });
  if (error) return { ok: false, message: "Something went wrong. Please try again." };
  return { ok: true, message: "You're on the list. Welcome to VELVORIA." };
}

const Contact = z.object({
  name: z.string().trim().min(1).max(120),
  email: z.string().trim().email().max(200),
  message: z.string().trim().min(5).max(4000),
});

export async function sendContact(_: FormState, form: FormData): Promise<FormState> {
  if (form.get("company")) return { ok: true, message: "Thanks!" };
  const parsed = Contact.safeParse(Object.fromEntries(form));
  if (!parsed.success) return { ok: false, message: "Please fill in your name, a valid email and a message." };
  const { error } = await createAdminClient().from("contact_messages").insert(parsed.data);
  if (error) return { ok: false, message: "Something went wrong. Please try again." };
  return { ok: true, message: "Thanks — our team will reply within 1–2 business days." };
}
