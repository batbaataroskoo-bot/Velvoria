import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ClothingSizeTable, ShoeSizeTable } from "@/components/SizeGuide";

export const dynamicParams = false;
export function generateStaticParams() { return [{ type: "clothing" }, { type: "shoes" }]; }
export async function generateMetadata({ params }: { params: Promise<{ type: string }> }): Promise<Metadata> {
  return { title: (await params).type === "shoes" ? "Shoe Size Guide" : "Clothing Size Guide" };
}

export default async function Page({ params }: { params: Promise<{ type: string }> }) {
  const { type } = await params;
  if (type !== "clothing" && type !== "shoes") notFound();
  return (
    <div className="container-x max-w-3xl pt-12 sm:pt-16">
      <div className="mb-6 flex gap-4 text-xs uppercase tracking-[0.14em]">
        <Link href="/size-guide/clothing" className={type === "clothing" ? "underline underline-offset-4" : "text-ink-soft"}>Clothing</Link>
        <Link href="/size-guide/shoes" className={type === "shoes" ? "underline underline-offset-4" : "text-ink-soft"}>Shoes & Sneakers</Link>
      </div>
      <h1 className="headline mb-8 text-4xl sm:text-6xl">{type === "shoes" ? "Shoe Size Guide" : "Clothing Size Guide"}</h1>
      {type === "shoes" ? <ShoeSizeTable /> : <ClothingSizeTable />}
    </div>
  );
}
