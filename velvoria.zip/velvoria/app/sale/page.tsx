import type { Metadata } from "next";
import { Catalog } from "@/components/Catalog";
import type { SP } from "@/lib/filters";

export const metadata: Metadata = { title: "Sale", description: "Reduced clothing, sneakers and shoes.", alternates: { canonical: "/sale" } };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  return <Catalog title="Sale" eyebrow="Limited time" preset={{ sale: true }} searchParams={await searchParams} basePath="/sale" />;
}
