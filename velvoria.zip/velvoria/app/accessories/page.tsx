import type { Metadata } from "next";
import { Catalog } from "@/components/Catalog";
import type { SP } from "@/lib/filters";

export const metadata: Metadata = { title: "Accessories", description: "Bags, beanies and socks to finish every look.", alternates: { canonical: "/accessories" } };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  return <Catalog title="Accessories" eyebrow="Finishing touches" preset={{ department: "accessories" }} searchParams={await searchParams} basePath="/accessories" />;
}
