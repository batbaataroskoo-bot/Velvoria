"use client";

import { useActionState } from "react";
import { sendContact } from "@/app/actions";

export function ContactForm() {
  const [s, a, pending] = useActionState(sendContact, null);
  if (s?.ok) return <p className="self-start bg-sage/40 p-5 text-sm">{s.message}</p>;
  return (
    <form action={a} className="space-y-4">
      <div><label className="label" htmlFor="c-name">Name</label><input id="c-name" name="name" required className="input" autoComplete="name" /></div>
      <div><label className="label" htmlFor="c-email">Email</label><input id="c-email" name="email" type="email" required className="input" autoComplete="email" /></div>
      <div><label className="label" htmlFor="c-msg">Message</label><textarea id="c-msg" name="message" required rows={6} className="input h-auto py-2" /></div>
      <input name="company" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      {s && !s.ok && <p role="alert" className="text-sm text-red-700">{s.message}</p>}
      <button className="btn-dark" disabled={pending}>{pending ? "Sending…" : "Send message"}</button>
    </form>
  );
}
