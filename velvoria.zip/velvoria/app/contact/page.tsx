import type { Metadata } from "next";
import { ContactForm } from "./ContactForm";

export const metadata: Metadata = { title: "Contact", description: "Get in touch with VELVORIA customer care.", alternates: { canonical: "/contact" } };

export default function Page() {
  return (
    <div className="container-x grid max-w-5xl gap-12 pt-12 sm:pt-16 md:grid-cols-2">
      <div>
        <h1 className="headline mb-6 text-4xl sm:text-6xl">Contact</h1>
        <div className="prose-v">
          <p>Questions about an order, sizing or returns? Send us a message and we&apos;ll reply within 1–2 business days.</p>
          <p>Email: [support@yourdomain.com]<br />Hours: Monday–Friday, 9am–5pm [time zone]</p>
          <p>For order questions, include your order number.</p>
        </div>
      </div>
      <ContactForm />
    </div>
  );
}
