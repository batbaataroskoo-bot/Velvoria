import type { Metadata } from "next";
import { Catalog } from "@/components/Catalog";
import type { SP } from "@/lib/filters";

export const metadata: Metadata = { title: "New Arrivals", description: "The latest VELVORIA clothing and sneaker arrivals.", alternates: { canonical: "/new-arrivals" } };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  return <Catalog title="New Arrivals" eyebrow="Just landed" preset={{ isNew: true }} searchParams={{ sort: "newest", ...sp }} basePath="/new-arrivals" />;
}
