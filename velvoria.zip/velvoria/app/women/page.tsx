import type { Metadata } from "next";
import { Catalog } from "@/components/Catalog";
import type { SP } from "@/lib/filters";

export const metadata: Metadata = { title: "Women", description: "Women's everyday clothing, sneakers and shoes — plus unisex essentials.", alternates: { canonical: "/women" } };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  return <Catalog title="Women" eyebrow="Women's & unisex" preset={{ gender: ["women"] }} searchParams={await searchParams} basePath="/women"
    quickLinks={[["Clothing", "/women?department=clothing"], ["Shoes & Sneakers", "/women?department=footwear"], ["Accessories", "/women?department=accessories"]]} />;
}
