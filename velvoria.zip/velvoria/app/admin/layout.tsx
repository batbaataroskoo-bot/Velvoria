import Link from "next/link";
import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";

export const metadata: Metadata = { title: "Admin", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

const NAV = [
  ["Dashboard", "/admin"], ["Products", "/admin/products"], ["Orders", "/admin/orders"], ["Categories", "/admin/categories"],
  ["Collections", "/admin/collections"], ["Homepage banners", "/admin/banners"], ["Discount codes", "/admin/discounts"], ["Reviews", "/admin/reviews"],
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin(); // server-side authorization for every admin page
  return (
    <div className="container-x pt-8">
      <div className="mb-6 flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-[0.2em]">Velvoria Admin</p>
        <Link href="/" className="text-xs underline">View store</Link>
      </div>
      <div className="grid gap-8 lg:grid-cols-[200px_1fr]">
        <nav aria-label="Admin" className="no-scrollbar flex gap-4 overflow-x-auto border-b border-charcoal/10 pb-3 text-sm lg:flex-col lg:gap-2.5 lg:border-0">
          {NAV.map(([l, h]) => <Link key={h} href={h} className="shrink-0 hover:underline">{l}</Link>)}
        </nav>
        <div className="min-w-0">{children}</div>
      </div>
    </div>
  );
}
