import { requireAdmin } from "@/lib/auth";
import { getCategories } from "@/lib/catalog";
import { saveCategory, deleteCategory } from "../actions";
import { Card, H } from "../ui";

export default async function Page() {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const cats = await getCategories();
  const form = (c?: (typeof cats)[number]) => (
    <form action={saveCategory} className="grid items-end gap-2 sm:grid-cols-[1.4fr_1fr_1fr_70px_auto]">
      {c && <input type="hidden" name="id" value={c.id} />}
      <input name="name" defaultValue={c?.name} required placeholder="Name" aria-label="Name" className="input h-10" />
      <input name="slug" defaultValue={c?.slug} placeholder="slug (auto)" aria-label="Slug" className="input h-10" />
      <select name="department" defaultValue={c?.department ?? "footwear"} aria-label="Department" className="input h-10"><option value="clothing">Clothing</option><option value="footwear">Footwear</option><option value="accessories">Accessories</option></select>
      <input name="sort" type="number" defaultValue={c?.sort ?? 0} aria-label="Sort order" className="input h-10" />
      <button className="btn-outline h-10 px-4">{c ? "Save" : "Add"}</button>
    </form>
  );
  return (
    <div className="space-y-6">
      <H>Categories</H>
      <Card title="Add a category (e.g. a new footwear category)">{form()}</Card>
      {(["footwear", "clothing", "accessories"] as const).map((d) => (
        <Card key={d} title={d}>
          <ul className="space-y-2">
            {cats.filter((c) => c.department === d).map((c) => (
              <li key={c.id} className="flex items-center gap-2">
                <div className="flex-1">{form(c)}</div>
                <form action={deleteCategory}><input type="hidden" name="id" value={c.id} /><button className="text-xs text-red-700 underline">Delete</button></form>
              </li>
            ))}
          </ul>
        </Card>
      ))}
    </div>
  );
}
