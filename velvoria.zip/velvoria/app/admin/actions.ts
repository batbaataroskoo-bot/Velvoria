"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { slugify } from "@/lib/format";
import { uploadImageFile } from "@/lib/uploads";

// Every action below starts with requireAdmin(): the check happens on the server,
// so hiding buttons in the browser is never the only protection.

const cents = (v: FormDataEntryValue | null) => {
  const s = String(v ?? "").trim();
  if (!s) return null;
  const n = Math.round(Number(s) * 100);
  if (!Number.isFinite(n) || n < 0) throw new Error("Invalid price");
  return n;
};
const bool = (v: FormDataEntryValue | null) => v === "on" || v === "true";
const str = (v: FormDataEntryValue | null, max = 2000) => { const s = String(v ?? "").trim().slice(0, max); return s || null; };
const uuid = (v: FormDataEntryValue | null) => z.string().uuid().parse(v);

function refreshStore() {
  revalidatePath("/", "layout");
}

// ---------------- Products ----------------
const ProductFields = z.object({
  name: z.string().trim().min(2).max(140),
  slug: z.string().trim().max(160).optional(),
  description: z.string().trim().max(5000).default(""),
  department: z.enum(["clothing", "footwear", "accessories"]),
  category_id: z.string().uuid().nullable(),
  gender: z.enum(["women", "men", "unisex"]),
  brand: z.string().trim().min(1).max(80).default("Velvoria"),
  style: z.string().trim().max(60).nullable(),
  size_system: z.enum(["clothing", "shoe", "one"]),
});

function productFromForm(form: FormData) {
  const base = ProductFields.parse({
    name: form.get("name"), slug: form.get("slug") || undefined, description: form.get("description") ?? "",
    department: form.get("department"), category_id: form.get("category_id") || null, gender: form.get("gender"),
    brand: form.get("brand") || "Velvoria", style: str(form.get("style"), 60), size_system: form.get("size_system"),
  });
  const price = cents(form.get("price"));
  if (price == null) throw new Error("Price is required");
  return {
    ...base,
    slug: slugify(base.slug || base.name),
    price_cents: price,
    compare_at_cents: cents(form.get("compare_at")),
    materials: str(form.get("materials")),
    construction: str(form.get("construction")),
    fit_note: str(form.get("fit_note"), 300),
    is_new: bool(form.get("is_new")), is_trending: bool(form.get("is_trending")),
    is_bestseller: bool(form.get("is_bestseller")), is_featured: bool(form.get("is_featured")),
    is_demo: bool(form.get("is_demo")), active: bool(form.get("active")),
    updated_at: new Date().toISOString(),
  };
}

async function setCollections(productId: string, form: FormData) {
  const db = createAdminClient();
  const ids = form.getAll("collections").map((c) => uuid(c));
  await db.from("product_collections").delete().eq("product_id", productId);
  if (ids.length) await db.from("product_collections").insert(ids.map((collection_id) => ({ product_id: productId, collection_id })));
}

export async function createProduct(form: FormData) {
  await requireAdmin();
  const data = productFromForm(form);
  const { data: p, error } = await createAdminClient().from("products").insert(data).select("id").single();
  if (error) throw new Error(error.code === "23505" ? "A product with this URL slug already exists." : error.message);
  await setCollections(p.id, form);
  refreshStore();
  redirect(`/admin/products/${p.id}?created=1`);
}

export async function updateProduct(form: FormData) {
  await requireAdmin();
  const id = uuid(form.get("id"));
  const { error } = await createAdminClient().from("products").update(productFromForm(form)).eq("id", id);
  if (error) throw new Error(error.message);
  await setCollections(id, form);
  refreshStore();
  revalidatePath(`/admin/products/${id}`);
}

export async function deleteProduct(form: FormData) {
  await requireAdmin();
  const id = uuid(form.get("id"));
  const db = createAdminClient();
  const { data: imgs } = await db.from("product_images").select("url").eq("product_id", id);
  await removeStorageFiles((imgs ?? []).map((i) => i.url));
  const { error } = await db.from("products").delete().eq("id", id);
  // Products that already appear in orders can't be hard-deleted safely — hide them instead.
  if (error) await db.from("products").update({ active: false }).eq("id", id);
  refreshStore();
  redirect("/admin/products");
}

export async function deleteAllDemoProducts() {
  await requireAdmin();
  const db = createAdminClient();
  const { data: demo } = await db.from("products").select("id").eq("is_demo", true);
  for (const p of demo ?? []) {
    const { error } = await db.from("products").delete().eq("id", p.id);
    if (error) await db.from("products").update({ active: false }).eq("id", p.id);
  }
  refreshStore();
  revalidatePath("/admin/products");
}

// ---------------- Colorways, sizes, variants & inventory ----------------
export async function addColorway(form: FormData) {
  await requireAdmin();
  const productId = uuid(form.get("product_id"));
  const name = z.string().trim().min(1).max(60).parse(form.get("name"));
  const hex = z.string().regex(/^#[0-9a-fA-F]{6}$/).parse(form.get("hex"));
  const db = createAdminClient();
  const { data: product } = await db.from("products").select("slug, size_system").eq("id", productId).single();
  const { count } = await db.from("colorways").select("*", { count: "exact", head: true }).eq("product_id", productId);
  const { data: cw, error } = await db.from("colorways").insert({ product_id: productId, name, hex, sort: count ?? 0 }).select("id").single();
  if (error || !product) throw new Error(error?.message ?? "Product not found");
  // Create a variant for every size already offered on this product (or all sizes of its system for the first colorway).
  const { data: existing } = await db.from("product_variants").select("size_id").eq("product_id", productId);
  let sizeIds = [...new Set((existing ?? []).map((v) => v.size_id))];
  if (!sizeIds.length) {
    const { data: sizes } = await db.from("sizes").select("id").eq("system", product.size_system);
    sizeIds = (sizes ?? []).map((s) => s.id);
  }
  if (sizeIds.length) {
    await db.from("product_variants").insert(sizeIds.map((size_id) => ({
      product_id: productId, colorway_id: cw.id, size_id, stock: 0,
      sku: `VEL-${product.slug.slice(0, 10).toUpperCase()}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`,
    })));
  }
  refreshStore();
  revalidatePath(`/admin/products/${productId}`);
}

export async function deleteColorway(form: FormData) {
  await requireAdmin();
  const id = uuid(form.get("id"));
  const productId = uuid(form.get("product_id"));
  await createAdminClient().from("colorways").delete().eq("id", id);
  refreshStore();
  revalidatePath(`/admin/products/${productId}`);
}

export async function addSizeToProduct(form: FormData) {
  await requireAdmin();
  const productId = uuid(form.get("product_id"));
  const sizeId = uuid(form.get("size_id"));
  const db = createAdminClient();
  const [{ data: product }, { data: cws }] = await Promise.all([
    db.from("products").select("slug").eq("id", productId).single(),
    db.from("colorways").select("id").eq("product_id", productId),
  ]);
  if (!product) throw new Error("Product not found");
  await db.from("product_variants").upsert((cws ?? []).map((c) => ({
    product_id: productId, colorway_id: c.id, size_id: sizeId, stock: 0,
    sku: `VEL-${product.slug.slice(0, 10).toUpperCase()}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`,
  })), { onConflict: "colorway_id,size_id", ignoreDuplicates: true });
  refreshStore();
  revalidatePath(`/admin/products/${productId}`);
}

export async function removeSizeFromProduct(form: FormData) {
  await requireAdmin();
  const productId = uuid(form.get("product_id"));
  const sizeId = uuid(form.get("size_id"));
  await createAdminClient().from("product_variants").delete().eq("product_id", productId).eq("size_id", sizeId);
  refreshStore();
  revalidatePath(`/admin/products/${productId}`);
}

/** Saves the whole inventory grid: stock_<variantId> and price_<variantId> fields. */
export async function saveInventory(form: FormData) {
  await requireAdmin();
  const productId = uuid(form.get("product_id"));
  const db = createAdminClient();
  const { data: variants } = await db.from("product_variants").select("id, stock, price_cents").eq("product_id", productId);
  for (const v of variants ?? []) {
    const stockRaw = form.get(`stock_${v.id}`);
    const priceRaw = form.get(`price_${v.id}`);
    if (stockRaw == null) continue;
    const stock = z.coerce.number().int().min(0).max(100000).parse(stockRaw);
    const price = cents(priceRaw);
    if (stock !== v.stock || price !== v.price_cents) {
      await db.from("product_variants").update({ stock, price_cents: price }).eq("id", v.id);
      if (stock !== v.stock) await db.from("inventory_log").insert({ variant_id: v.id, change: stock - v.stock, reason: "admin adjustment" });
    }
  }
  refreshStore();
  revalidatePath(`/admin/products/${productId}`);
}

// ---------------- Images (safe uploads) ----------------
async function removeStorageFiles(urls: string[]) {
  const marker = "/storage/v1/object/public/product-images/";
  const paths = urls.map((u) => (u.includes(marker) ? u.split(marker)[1] : null)).filter(Boolean) as string[];
  if (paths.length) await createAdminClient().storage.from("product-images").remove(paths);
}

export async function uploadProductImage(form: FormData) {
  await requireAdmin();
  const productId = uuid(form.get("product_id"));
  const angle = z.enum(["front", "side", "top", "back", "outsole", "detail", "lifestyle"]).parse(form.get("angle"));
  const colorwayId = form.get("colorway_id") ? uuid(form.get("colorway_id")) : null;
  const url = await uploadImageFile(form.get("file") as File, `products/${productId}`);
  const db = createAdminClient();
  const { count } = await db.from("product_images").select("*", { count: "exact", head: true }).eq("product_id", productId);
  await db.from("product_images").insert({ product_id: productId, colorway_id: colorwayId, url, angle, alt: str(form.get("alt"), 200), sort: count ?? 0 });
  refreshStore();
  revalidatePath(`/admin/products/${productId}`);
}

export async function deleteProductImage(form: FormData) {
  await requireAdmin();
  const id = uuid(form.get("id"));
  const productId = uuid(form.get("product_id"));
  const db = createAdminClient();
  const { data } = await db.from("product_images").select("url").eq("id", id).single();
  if (data) await removeStorageFiles([data.url]);
  await db.from("product_images").delete().eq("id", id);
  refreshStore();
  revalidatePath(`/admin/products/${productId}`);
}

// ---------------- Categories & collections ----------------
export async function saveCategory(form: FormData) {
  await requireAdmin();
  const id = form.get("id") ? uuid(form.get("id")) : null;
  const name = z.string().trim().min(2).max(80).parse(form.get("name"));
  const row = {
    name, slug: slugify(String(form.get("slug") || name)),
    department: z.enum(["clothing", "footwear", "accessories"]).parse(form.get("department")),
    description: str(form.get("description"), 500), sort: Number(form.get("sort") || 0),
  };
  const db = createAdminClient();
  const { error } = id ? await db.from("categories").update(row).eq("id", id) : await db.from("categories").insert(row);
  if (error) throw new Error(error.message);
  refreshStore();
  revalidatePath("/admin/categories");
}

export async function deleteCategory(form: FormData) {
  await requireAdmin();
  await createAdminClient().from("categories").delete().eq("id", uuid(form.get("id")));
  refreshStore();
  revalidatePath("/admin/categories");
}

export async function saveCollection(form: FormData) {
  await requireAdmin();
  const id = form.get("id") ? uuid(form.get("id")) : null;
  const name = z.string().trim().min(2).max(80).parse(form.get("name"));
  const file = form.get("image") as File | null;
  const image_url = file && file.size > 0 ? await uploadImageFile(file, "collections") : undefined;
  const row = {
    name, slug: slugify(String(form.get("slug") || name)), description: str(form.get("description"), 500),
    is_seasonal: bool(form.get("is_seasonal")), active: bool(form.get("active")), sort: Number(form.get("sort") || 0),
    ...(image_url ? { image_url } : {}),
  };
  const db = createAdminClient();
  const { error } = id ? await db.from("collections").update(row).eq("id", id) : await db.from("collections").insert(row);
  if (error) throw new Error(error.message);
  refreshStore();
  revalidatePath("/admin/collections");
}

export async function deleteCollection(form: FormData) {
  await requireAdmin();
  await createAdminClient().from("collections").delete().eq("id", uuid(form.get("id")));
  refreshStore();
  revalidatePath("/admin/collections");
}

// ---------------- Banners ----------------
export async function saveBanner(form: FormData) {
  await requireAdmin();
  const id = form.get("id") ? uuid(form.get("id")) : null;
  const file = form.get("image") as File | null;
  const image_url = file && file.size > 0 ? await uploadImageFile(file, "banners") : undefined;
  const href = str(form.get("cta_href"), 300);
  if (href && !href.startsWith("/") && !href.startsWith("https://")) throw new Error("Links must start with / or https://");
  const row = {
    placement: z.enum(["hero", "sneakers", "seasonal"]).parse(form.get("placement")),
    eyebrow: str(form.get("eyebrow"), 80), title: z.string().trim().min(1).max(120).parse(form.get("title")),
    subtitle: str(form.get("subtitle"), 300), cta_label: str(form.get("cta_label"), 40), cta_href: href,
    active: bool(form.get("active")), sort: Number(form.get("sort") || 0),
    ...(image_url ? { image_url } : {}),
    ...(bool(form.get("remove_image")) ? { image_url: null } : {}),
  };
  const db = createAdminClient();
  const { error } = id ? await db.from("banners").update(row).eq("id", id) : await db.from("banners").insert(row);
  if (error) throw new Error(error.message);
  refreshStore();
  revalidatePath("/admin/banners");
}

export async function deleteBanner(form: FormData) {
  await requireAdmin();
  await createAdminClient().from("banners").delete().eq("id", uuid(form.get("id")));
  refreshStore();
  revalidatePath("/admin/banners");
}

// ---------------- Discounts ----------------
export async function saveDiscount(form: FormData) {
  await requireAdmin();
  const id = form.get("id") ? uuid(form.get("id")) : null;
  const kind = z.enum(["percent", "fixed"]).parse(form.get("kind"));
  const rawValue = Number(form.get("value"));
  const value = kind === "percent" ? z.number().int().min(1).max(100).parse(rawValue) : cents(String(rawValue))!;
  const row = {
    code: z.string().trim().min(3).max(40).regex(/^[A-Za-z0-9_-]+$/).parse(form.get("code")).toUpperCase(),
    kind, value,
    min_subtotal_cents: cents(form.get("min_subtotal")) ?? 0,
    max_uses: form.get("max_uses") ? z.coerce.number().int().min(1).parse(form.get("max_uses")) : null,
    starts_at: str(form.get("starts_at")), ends_at: str(form.get("ends_at")),
    active: bool(form.get("active")),
  };
  const db = createAdminClient();
  const { error } = id ? await db.from("discount_codes").update(row).eq("id", id) : await db.from("discount_codes").insert(row);
  if (error) throw new Error(error.code === "23505" ? "That code already exists." : error.message);
  revalidatePath("/admin/discounts");
}

export async function deleteDiscount(form: FormData) {
  await requireAdmin();
  await createAdminClient().from("discount_codes").delete().eq("id", uuid(form.get("id")));
  revalidatePath("/admin/discounts");
}

/** Sale pricing helper: set a % off across a product (moves the current price to compare-at). */
export async function applyProductDiscount(form: FormData) {
  await requireAdmin();
  const id = uuid(form.get("id"));
  const pct = z.coerce.number().int().min(0).max(90).parse(form.get("percent"));
  const db = createAdminClient();
  const { data: p } = await db.from("products").select("price_cents, compare_at_cents").eq("id", id).single();
  if (!p) throw new Error("Product not found");
  const original = p.compare_at_cents ?? p.price_cents;
  const update = pct === 0 ? { price_cents: original, compare_at_cents: null } : { price_cents: Math.round(original * (100 - pct) / 100), compare_at_cents: original };
  await db.from("products").update(update).eq("id", id);
  refreshStore();
  revalidatePath(`/admin/products/${id}`);
}

// ---------------- Orders ----------------
export async function updateOrder(form: FormData) {
  await requireAdmin();
  const id = uuid(form.get("id"));
  const status = z.enum(["pending", "paid", "processing", "shipped", "delivered", "cancelled", "refunded"]).parse(form.get("status"));
  const trackingUrl = str(form.get("tracking_url"), 500);
  if (trackingUrl && !trackingUrl.startsWith("https://")) throw new Error("Tracking link must start with https://");
  await createAdminClient().from("orders").update({ status, tracking_number: str(form.get("tracking_number"), 100), tracking_url: trackingUrl }).eq("id", id);
  revalidatePath(`/admin/orders/${id}`);
  revalidatePath("/admin/orders");
}

// ---------------- Reviews ----------------
export async function moderateReview(form: FormData) {
  await requireAdmin();
  const id = uuid(form.get("id"));
  const db = createAdminClient();
  if (form.get("op") === "delete") await db.from("reviews").delete().eq("id", id);
  else await db.from("reviews").update({ approved: true }).eq("id", id);
  refreshStore();
  revalidatePath("/admin/reviews");
}
