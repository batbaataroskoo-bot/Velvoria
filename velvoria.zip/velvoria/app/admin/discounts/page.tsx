import { requireAdmin } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { money } from "@/lib/format";
import { saveDiscount, deleteDiscount } from "../actions";
import { Card, H, Field, th, td } from "../ui";

export default async function Page() {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const { data: codes } = await createAdminClient().from("discount_codes").select("*").order("created_at", { ascending: false });
  return (
    <div className="space-y-6">
      <H>Discount codes</H>
      <Card title="New code">
        <form action={saveDiscount} className="grid gap-3 sm:grid-cols-3">
          <Field label="Code"><input name="code" required placeholder="SUMMER15" className="input uppercase" /></Field>
          <Field label="Type"><select name="kind" className="input"><option value="percent">Percent off</option><option value="fixed">Fixed amount off ($)</option></select></Field>
          <Field label="Value (% or $)"><input name="value" type="number" step="0.01" min="0" required className="input" /></Field>
          <Field label="Minimum order ($)"><input name="min_subtotal" type="number" step="0.01" min="0" className="input" /></Field>
          <Field label="Max uses (blank = unlimited)"><input name="max_uses" type="number" min="1" className="input" /></Field>
          <Field label="Ends (optional)"><input name="ends_at" type="datetime-local" className="input" /></Field>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="active" defaultChecked className="accent-charcoal" />Active</label>
          <div className="sm:col-span-3"><button className="btn-dark h-10">Create code</button></div>
        </form>
      </Card>
      <Card title="Existing codes">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[600px] text-sm">
            <thead><tr><th className={th}>Code</th><th className={th}>Discount</th><th className={th}>Min order</th><th className={th}>Used</th><th className={th}>Status</th><th className={th} /></tr></thead>
            <tbody>{(codes ?? []).map((c) => (
              <tr key={c.id} className="border-t border-charcoal/10">
                <td className={`${td} font-medium`}>{c.code}</td>
                <td className={td}>{c.kind === "percent" ? `${c.value}%` : money(c.value)}</td>
                <td className={td}>{c.min_subtotal_cents ? money(c.min_subtotal_cents) : "—"}</td>
                <td className={td}>{c.uses}{c.max_uses ? ` / ${c.max_uses}` : ""}</td>
                <td className={td}>{c.active ? "Active" : "Off"}{c.ends_at ? ` · ends ${new Date(c.ends_at).toLocaleDateString()}` : ""}</td>
                <td className={td}><form action={deleteDiscount}><input type="hidden" name="id" value={c.id} /><button className="text-xs text-red-700 underline">Delete</button></form></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
