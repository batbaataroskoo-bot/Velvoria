import { requireAdmin } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { moderateReview } from "../actions";
import { Card, H } from "../ui";

export default async function Page() {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const { data } = await createAdminClient().from("reviews").select("*, product:products(name)").order("approved").order("created_at", { ascending: false }).limit(100);
  const rows = (data ?? []) as { id: string; rating: number; title: string | null; body: string; author_name: string; approved: boolean; fit: string | null; product: { name: string } | null }[];
  return (
    <div className="space-y-4">
      <H>Reviews</H>
      {rows.length === 0 && <p className="text-sm text-ink-soft">No reviews yet.</p>}
      {rows.map((r) => (
        <Card key={r.id}>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="text-xs text-ink-soft">{r.product?.name} · {r.author_name} · {"★".repeat(r.rating)}{r.fit ? ` · fit: ${r.fit}` : ""}</p>
              {r.title && <p className="mt-1 font-medium">{r.title}</p>}
              <p className="mt-1 text-sm">{r.body}</p>
            </div>
            <div className="flex gap-2">
              {!r.approved && <form action={moderateReview}><input type="hidden" name="id" value={r.id} /><button className="btn-dark h-9 px-4 text-[11px]">Approve</button></form>}
              <form action={moderateReview}><input type="hidden" name="id" value={r.id} /><input type="hidden" name="op" value="delete" /><button className="btn-outline h-9 px-4 text-[11px]">Delete</button></form>
            </div>
          </div>
          {r.approved && <p className="mt-2 text-[11px] uppercase tracking-[0.12em] text-[#4d5a43]">Published</p>}
        </Card>
      ))}
    </div>
  );
}
