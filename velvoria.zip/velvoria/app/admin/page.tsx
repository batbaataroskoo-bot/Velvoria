import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { createAdminClient } from "@/lib/supabase/admin";
import { money } from "@/lib/format";
import { Card, H, th, td } from "./ui";
import { StatusBadge } from "@/app/account/StatusBadge";

const PAID = ["paid", "processing", "shipped", "delivered"];

export default async function Dashboard() {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const db = createAdminClient();
  const since = new Date(Date.now() - 30 * 864e5).toISOString();
  const [{ data: orders }, { data: items }, { data: lowStock }, { count: products }, { count: subscribers }] = await Promise.all([
    db.from("orders").select("id, order_number, status, total_cents, created_at, email").gte("created_at", since).order("created_at", { ascending: false }),
    db.from("order_items").select("name, quantity, unit_price_cents, order:orders!inner(status, created_at)").gte("order.created_at", since).in("order.status", PAID),
    db.from("product_variants").select("id, sku, stock, product:products(id, name, active), size:sizes(label), colorway:colorways(name)").lte("stock", 3).order("stock").limit(12),
    db.from("products").select("*", { count: "exact", head: true }).eq("active", true),
    db.from("newsletter_subscribers").select("*", { count: "exact", head: true }),
  ]);

  const paid = (orders ?? []).filter((o) => PAID.includes(o.status));
  const revenue = paid.reduce((s, o) => s + o.total_cents, 0);
  const units = (items ?? []).reduce((s, i) => s + i.quantity, 0);
  const aov = paid.length ? Math.round(revenue / paid.length) : 0;
  const toFulfil = paid.filter((o) => o.status === "paid" || o.status === "processing").length;

  const byDay = new Map<string, number>();
  for (let i = 13; i >= 0; i--) byDay.set(new Date(Date.now() - i * 864e5).toISOString().slice(0, 10), 0);
  paid.forEach((o) => { const d = o.created_at.slice(0, 10); if (byDay.has(d)) byDay.set(d, byDay.get(d)! + o.total_cents); });
  const maxDay = Math.max(1, ...byDay.values());

  const top = new Map<string, { units: number; revenue: number }>();
  (items ?? []).forEach((i) => { const t = top.get(i.name) ?? { units: 0, revenue: 0 }; t.units += i.quantity; t.revenue += i.quantity * i.unit_price_cents; top.set(i.name, t); });
  const topList = [...top.entries()].sort((a, b) => b[1].revenue - a[1].revenue).slice(0, 6);

  const stat = (l: string, v: string, sub?: string) => (
    <Card><p className="text-[11px] uppercase tracking-[0.12em] text-ink-soft">{l}</p><p className="mt-2 text-2xl">{v}</p>{sub && <p className="mt-1 text-xs text-ink-soft">{sub}</p>}</Card>
  );

  return (
    <div className="space-y-6">
      <H>Sales analytics</H>
      <p className="-mt-4 text-xs text-ink-soft">Last 30 days · paid orders only ({paid.length} of {(orders ?? []).length} orders created; unpaid/cancelled checkouts are excluded).</p>
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stat("Revenue", money(revenue))}
        {stat("Paid orders", String(paid.length), `${toFulfil} waiting to ship`)}
        {stat("Average order", money(aov))}
        {stat("Units sold", String(units), `${products ?? 0} active products · ${subscribers ?? 0} subscribers`)}
      </div>

      <Card title="Revenue — last 14 days">
        <div className="flex h-40 items-end gap-1.5" role="img" aria-label="Daily revenue bar chart">
          {[...byDay.entries()].map(([d, v]) => (
            <div key={d} className="flex flex-1 flex-col items-center gap-1">
              <div className="w-full bg-charcoal" style={{ height: `${(v / maxDay) * 100}%`, minHeight: v ? 2 : 0 }} title={`${d}: ${money(v)}`} />
              <span className="text-[9px] text-ink-soft">{d.slice(8)}</span>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card title="Top products (30 days)">
          {topList.length ? (
            <table className="w-full text-sm"><thead><tr><th className={th}>Product</th><th className={th}>Units</th><th className={th}>Revenue</th></tr></thead>
              <tbody>{topList.map(([n, t]) => <tr key={n} className="border-t border-charcoal/10"><td className={td}>{n}</td><td className={td}>{t.units}</td><td className={td}>{money(t.revenue)}</td></tr>)}</tbody></table>
          ) : <p className="text-sm text-ink-soft">No sales yet.</p>}
        </Card>
        <Card title="Low stock (3 or fewer)">
          <table className="w-full text-sm"><thead><tr><th className={th}>Product</th><th className={th}>Variant</th><th className={th}>Stock</th></tr></thead>
            <tbody>{(lowStock ?? []).map((v) => {
              const r = v as unknown as { id: string; stock: number; product: { id: string; name: string } | null; size: { label: string } | null; colorway: { name: string } | null };
              return <tr key={r.id} className="border-t border-charcoal/10"><td className={td}><Link className="underline" href={`/admin/products/${r.product?.id}`}>{r.product?.name}</Link></td><td className={td}>{r.colorway?.name} / {r.size?.label}</td><td className={`${td} ${r.stock === 0 ? "text-red-700" : ""}`}>{r.stock}</td></tr>;
            })}</tbody></table>
        </Card>
      </div>

      <Card title="Recent orders">
        <table className="w-full text-sm"><thead><tr><th className={th}>Order</th><th className={th}>Date</th><th className={th}>Customer</th><th className={th}>Status</th><th className={th}>Total</th></tr></thead>
          <tbody>{(orders ?? []).slice(0, 8).map((o) => (
            <tr key={o.id} className="border-t border-charcoal/10"><td className={td}><Link className="underline" href={`/admin/orders/${o.id}`}>#{o.order_number}</Link></td><td className={td}>{new Date(o.created_at).toLocaleDateString()}</td><td className={td}>{o.email ?? "—"}</td><td className={td}><StatusBadge status={o.status} /></td><td className={td}>{money(o.total_cents)}</td></tr>
          ))}</tbody></table>
      </Card>
    </div>
  );
}
