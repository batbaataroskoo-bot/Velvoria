import { requireAdmin } from "@/lib/auth";
import Image from "next/image";
import { createAdminClient } from "@/lib/supabase/admin";
import type { Banner } from "@/lib/types";
import { saveBanner, deleteBanner } from "../actions";
import { Card, H, Field } from "../ui";

export default async function Page() {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const { data } = await createAdminClient().from("banners").select("*").order("placement").order("sort");
  const banners = (data ?? []) as Banner[];
  const form = (b?: Banner) => (
    <form action={saveBanner} className="grid gap-3 sm:grid-cols-2">
      {b && <input type="hidden" name="id" value={b.id} />}
      <Field label="Placement">
        <select name="placement" defaultValue={b?.placement ?? "seasonal"} className="input">
          <option value="hero">Homepage hero</option><option value="sneakers">Step Into Your Style (sneakers)</option><option value="seasonal">Seasonal collections tile</option>
        </select>
      </Field>
      <Field label="Small label above title"><input name="eyebrow" defaultValue={b?.eyebrow ?? ""} className="input" /></Field>
      <Field label="Title"><input name="title" defaultValue={b?.title} required className="input" /></Field>
      <Field label="Subtitle"><input name="subtitle" defaultValue={b?.subtitle ?? ""} className="input" /></Field>
      <Field label="Button label"><input name="cta_label" defaultValue={b?.cta_label ?? ""} className="input" /></Field>
      <Field label="Button link (/path or https://)"><input name="cta_href" defaultValue={b?.cta_href ?? ""} className="input" /></Field>
      <Field label="Campaign image (wide, max 5 MB)"><input name="image" type="file" accept="image/jpeg,image/png,image/webp,image/avif" className="text-sm" /></Field>
      <Field label="Sort"><input name="sort" type="number" defaultValue={b?.sort ?? 0} className="input" /></Field>
      <div className="flex gap-6 text-sm sm:col-span-2">
        <label className="flex items-center gap-2"><input type="checkbox" name="active" defaultChecked={b ? b.active : true} className="accent-charcoal" />Active</label>
        {b?.image_url && <label className="flex items-center gap-2"><input type="checkbox" name="remove_image" className="accent-charcoal" />Remove current image</label>}
      </div>
      <div><button className="btn-outline h-10">{b ? "Save banner" : "Add banner"}</button></div>
    </form>
  );
  return (
    <div className="space-y-6">
      <H>Homepage banners</H>
      <p className="-mt-3 text-sm text-ink-soft">The first active banner of each placement is used. Upload campaign photography to replace the placeholder artwork.</p>
      {banners.map((b) => (
        <Card key={b.id} title={`${b.placement} — ${b.title}`}>
          {b.image_url && <div className="relative mb-4 aspect-[16/7] max-w-xl bg-mist"><Image src={b.image_url} alt="" fill sizes="600px" className="object-cover" /></div>}
          {form(b)}
          <form action={deleteBanner} className="mt-3"><input type="hidden" name="id" value={b.id} /><button className="text-xs text-red-700 underline">Delete banner</button></form>
        </Card>
      ))}
      <Card title="Add banner">{form()}</Card>
    </div>
  );
}
