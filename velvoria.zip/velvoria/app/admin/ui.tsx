export function H({ children, action }: { children: React.ReactNode; action?: React.ReactNode }) {
  return <div className="mb-6 flex flex-wrap items-center justify-between gap-3"><h1 className="headline text-3xl">{children}</h1>{action}</div>;
}
export function Card({ title, children, className = "" }: { title?: string; children: React.ReactNode; className?: string }) {
  return (
    <section className={`border border-charcoal/10 bg-white/60 p-5 ${className}`}>
      {title && <h2 className="mb-4 text-xs font-semibold uppercase tracking-[0.14em]">{title}</h2>}
      {children}
    </section>
  );
}
export function Field({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className}`}><span className="label">{label}</span>{children}</label>;
}
export const th = "py-2 pr-3 text-left text-[11px] font-semibold uppercase tracking-[0.1em] text-ink-soft";
export const td = "py-2 pr-3 align-middle";
