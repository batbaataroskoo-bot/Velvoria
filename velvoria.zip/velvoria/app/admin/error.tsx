"use client";

export default function AdminError({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div className="border border-red-200 bg-red-50 p-6">
      <p className="font-medium text-red-800">That didn&apos;t work</p>
      <p className="mt-1 text-sm text-red-700">{error.message || "Something went wrong."}</p>
      <button onClick={reset} className="btn-outline mt-4 h-10">Try again</button>
    </div>
  );
}
