import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { createAdminClient } from "@/lib/supabase/admin";
import { money } from "@/lib/format";
import { deleteAllDemoProducts } from "../actions";
import { H, th, td } from "../ui";

export default async function Page({ searchParams }: { searchParams: Promise<{ q?: string; dept?: string }> }) {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const { q, dept } = await searchParams;
  let query = createAdminClient().from("products").select("id, name, slug, department, price_cents, compare_at_cents, active, is_demo, is_featured, is_new, category:categories(name), variants:product_variants(stock)").order("created_at", { ascending: false });
  if (q) query = query.ilike("name", `%${q.replace(/[%_,()]/g, "")}%`);
  if (dept) query = query.eq("department", dept);
  const { data } = await query;
  const rows = (data ?? []) as unknown as { id: string; name: string; slug: string; department: string; price_cents: number; compare_at_cents: number | null; active: boolean; is_demo: boolean; is_featured: boolean; is_new: boolean; category: { name: string } | null; variants: { stock: number }[] }[];
  const demoCount = rows.filter((r) => r.is_demo).length;
  return (
    <div>
      <H action={<Link href="/admin/products/new" className="btn-dark h-10">Add product</Link>}>Products</H>
      <form className="mb-4 flex flex-wrap gap-2">
        <input name="q" defaultValue={q} placeholder="Search by name" className="input h-10 max-w-xs" />
        <select name="dept" defaultValue={dept ?? ""} className="input h-10 max-w-[180px]"><option value="">All departments</option><option value="clothing">Clothing</option><option value="footwear">Footwear</option><option value="accessories">Accessories</option></select>
        <button className="btn-outline h-10">Filter</button>
      </form>
      {demoCount > 0 && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3 bg-peach/30 px-4 py-3 text-sm">
          <span>{demoCount} demonstration products are listed. They can&apos;t be bought until you replace them with real merchandise.</span>
          <form action={deleteAllDemoProducts}><button className="btn-outline h-9 px-4 text-[11px]">Remove all demo products</button></form>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm">
          <thead><tr><th className={th}>Name</th><th className={th}>Category</th><th className={th}>Price</th><th className={th}>Stock</th><th className={th}>Status</th></tr></thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id} className="border-t border-charcoal/10">
                <td className={td}><Link href={`/admin/products/${p.id}`} className="font-medium underline-offset-4 hover:underline">{p.name}</Link>{p.is_demo && <span className="ml-2 bg-mist px-1.5 text-[10px] uppercase">Demo</span>}{p.is_featured && <span className="ml-1 bg-sage/50 px-1.5 text-[10px] uppercase">Featured</span>}</td>
                <td className={td}>{p.category?.name ?? p.department}</td>
                <td className={td}>{money(p.price_cents)}{p.compare_at_cents ? <span className="ml-1 text-xs text-ink-soft line-through">{money(p.compare_at_cents)}</span> : null}</td>
                <td className={td}>{p.variants.reduce((s, v) => s + v.stock, 0)}</td>
                <td className={td}>{p.active ? "Visible" : <span className="text-ink-soft">Hidden</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-3 text-xs text-ink-soft">{rows.length} products shown.</p>
      </div>
    </div>
  );
}
