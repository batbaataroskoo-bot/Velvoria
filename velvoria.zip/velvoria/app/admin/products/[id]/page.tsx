import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { createAdminClient } from "@/lib/supabase/admin";
import { getCategories } from "@/lib/catalog";
import type { Collection, Colorway, Product, ProductImage, Size } from "@/lib/types";
import {
  updateProduct, deleteProduct, addColorway, deleteColorway, addSizeToProduct, removeSizeFromProduct,
  saveInventory, uploadProductImage, deleteProductImage, applyProductDiscount,
} from "../../actions";
import { ProductForm } from "../ProductForm";
import { Card, H, th, td } from "../../ui";

export default async function Page({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ created?: string }> }) {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const { id } = await params;
  const { created } = await searchParams;
  const db = createAdminClient();
  const { data: product } = await db.from("products").select("*").eq("id", id).maybeSingle();
  if (!product) notFound();
  const p = product as Product;
  const [categories, { data: collections }, { data: pc }, { data: colorways }, { data: variants }, { data: images }, { data: sizes }] = await Promise.all([
    getCategories(),
    db.from("collections").select("*").order("sort"),
    db.from("product_collections").select("collection_id").eq("product_id", id),
    db.from("colorways").select("*").eq("product_id", id).order("sort"),
    db.from("product_variants").select("id, sku, stock, price_cents, colorway_id, size_id").eq("product_id", id),
    db.from("product_images").select("*").eq("product_id", id).order("sort"),
    db.from("sizes").select("*").eq("system", p.size_system).order("sort"),
  ]);
  const cws = (colorways ?? []) as Colorway[];
  const allSizes = (sizes ?? []) as Size[];
  const vs = variants ?? [];
  const usedSizes = allSizes.filter((s) => vs.some((v) => v.size_id === s.id));
  const unusedSizes = allSizes.filter((s) => !vs.some((v) => v.size_id === s.id));
  const sizeName = (s: Size) => (s.system === "shoe" ? `US ${s.us} / EU ${s.eu}` : s.label);

  return (
    <div className="space-y-6">
      <H action={<Link href={`/products/${p.slug}`} className="text-xs underline" target="_blank">View in store ↗</Link>}>{p.name}</H>
      {created && <p className="bg-sage/40 px-4 py-3 text-sm">Product created. Next: add colorways, then set stock and upload photos.</p>}

      <Card title="Details">
        <ProductForm product={p} categories={categories} collections={(collections ?? []) as Collection[]} selected={(pc ?? []).map((r) => r.collection_id)} action={updateProduct} submit="Save details" />
      </Card>

      <Card title="Sale / discount">
        <form action={applyProductDiscount} className="flex flex-wrap items-end gap-3">
          <input type="hidden" name="id" value={p.id} />
          <label><span className="label">Percent off (0 removes the sale)</span><input name="percent" type="number" min={0} max={90} defaultValue={0} className="input h-10 w-32" /></label>
          <button className="btn-outline h-10">Apply</button>
        </form>
      </Card>

      <Card title={p.size_system === "shoe" ? "Colorways" : "Colors"}>
        <ul className="mb-4 flex flex-wrap gap-3">
          {cws.map((c) => (
            <li key={c.id} className="flex items-center gap-2 border border-charcoal/10 px-3 py-2 text-sm">
              <span className="h-4 w-4 rounded-full border" style={{ background: c.hex }} />{c.name}
              <form action={deleteColorway}><input type="hidden" name="id" value={c.id} /><input type="hidden" name="product_id" value={p.id} /><button className="ml-1 text-xs text-red-700" aria-label={`Delete ${c.name}`}>×</button></form>
            </li>
          ))}
        </ul>
        <form action={addColorway} className="flex flex-wrap items-end gap-3">
          <input type="hidden" name="product_id" value={p.id} />
          <label><span className="label">Name</span><input name="name" required className="input h-10" placeholder="e.g. Sage" /></label>
          <label><span className="label">Color</span><input name="hex" type="color" defaultValue="#B2B8A7" className="h-10 w-16 border border-charcoal/20" /></label>
          <button className="btn-outline h-10">Add colorway</button>
        </form>
      </Card>

      {p.size_system !== "one" && (
        <Card title={p.size_system === "shoe" ? "Shoe sizes offered" : "Sizes offered"}>
          <div className="mb-4 flex flex-wrap gap-2">
            {usedSizes.map((s) => (
              <form key={s.id} action={removeSizeFromProduct} className="flex items-center gap-1 border border-charcoal/15 px-2 py-1 text-xs">
                <input type="hidden" name="product_id" value={p.id} /><input type="hidden" name="size_id" value={s.id} />
                {sizeName(s)}<button className="text-red-700" aria-label={`Remove ${sizeName(s)}`}>×</button>
              </form>
            ))}
          </div>
          {unusedSizes.length > 0 && cws.length > 0 && (
            <form action={addSizeToProduct} className="flex flex-wrap items-end gap-3">
              <input type="hidden" name="product_id" value={p.id} />
              <select name="size_id" className="input h-10 w-auto">{unusedSizes.map((s) => <option key={s.id} value={s.id}>{sizeName(s)}</option>)}</select>
              <button className="btn-outline h-10">Add size</button>
            </form>
          )}
          {cws.length === 0 && <p className="text-sm text-ink-soft">Add a colorway first — sizes are created for each colorway.</p>}
        </Card>
      )}

      {vs.length > 0 && (
        <Card title="Inventory by size & colorway">
          <form action={saveInventory}>
            <input type="hidden" name="product_id" value={p.id} />
            <div className="overflow-x-auto">
              <table className="w-full min-w-[560px] text-sm">
                <thead><tr><th className={th}>Size</th>{cws.map((c) => <th key={c.id} className={th}>{c.name}<span className="block font-normal normal-case">stock · price override $</span></th>)}</tr></thead>
                <tbody>
                  {(p.size_system === "one" ? allSizes.filter((s) => vs.some((v) => v.size_id === s.id)) : usedSizes).map((s) => (
                    <tr key={s.id} className="border-t border-charcoal/10">
                      <td className={td}>{sizeName(s)}</td>
                      {cws.map((c) => {
                        const v = vs.find((x) => x.size_id === s.id && x.colorway_id === c.id);
                        return (
                          <td key={c.id} className={td}>
                            {v ? (
                              <div className="flex gap-1">
                                <input name={`stock_${v.id}`} type="number" min={0} defaultValue={v.stock} aria-label={`Stock ${c.name} ${s.label}`} className={`input h-9 w-20 ${v.stock === 0 ? "border-red-300" : ""}`} />
                                <input name={`price_${v.id}`} type="number" step="0.01" min={0} defaultValue={v.price_cents == null ? "" : (v.price_cents / 100).toFixed(2)} placeholder="—" aria-label={`Price ${c.name} ${s.label}`} className="input h-9 w-20" />
                              </div>
                            ) : "—"}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <button className="btn-dark mt-4 h-10">Save inventory</button>
          </form>
        </Card>
      )}

      <Card title="Product images (4:5 ratio recommended, max 5 MB)">
        <ul className="mb-5 grid grid-cols-3 gap-3 sm:grid-cols-5">
          {((images ?? []) as ProductImage[]).map((img) => (
            <li key={img.id} className="text-xs">
              <div className="relative aspect-[4/5] bg-mist"><Image src={img.url} alt={img.alt ?? ""} fill sizes="160px" className="object-cover" /></div>
              <p className="mt-1">{img.angle}{img.colorway_id ? ` · ${cws.find((c) => c.id === img.colorway_id)?.name ?? ""}` : ""}</p>
              <form action={deleteProductImage}><input type="hidden" name="id" value={img.id} /><input type="hidden" name="product_id" value={p.id} /><button className="text-red-700 underline">Delete</button></form>
            </li>
          ))}
        </ul>
        <form action={uploadProductImage} className="flex flex-wrap items-end gap-3">
          <input type="hidden" name="product_id" value={p.id} />
          <label><span className="label">Image</span><input name="file" type="file" accept="image/jpeg,image/png,image/webp,image/avif" required className="text-sm" /></label>
          <label><span className="label">View</span>
            <select name="angle" className="input h-10 w-auto">{["front", "side", "top", "back", "outsole", "detail", "lifestyle"].map((a) => <option key={a}>{a}</option>)}</select>
          </label>
          <label><span className="label">Colorway</span>
            <select name="colorway_id" className="input h-10 w-auto"><option value="">All colorways</option>{cws.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
          </label>
          <label><span className="label">Alt text</span><input name="alt" className="input h-10" placeholder="Describe the photo" /></label>
          <button className="btn-outline h-10">Upload</button>
        </form>
      </Card>

      <Card title="Danger zone">
        <form action={deleteProduct}>
          <input type="hidden" name="id" value={p.id} />
          <button className="h-10 border border-red-300 px-4 text-xs font-semibold uppercase tracking-[0.12em] text-red-700 hover:bg-red-50">Delete product</button>
          <span className="ml-3 text-xs text-ink-soft">Products that appear in past orders are hidden instead of deleted.</span>
        </form>
      </Card>
    </div>
  );
}
