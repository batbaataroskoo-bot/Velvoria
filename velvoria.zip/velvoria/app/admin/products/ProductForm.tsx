import type { Category, Collection, Product } from "@/lib/types";
import { Field } from "../ui";

export function ProductForm({ product, categories, collections, selected = [], action, submit }: {
  product?: Product; categories: Category[]; collections: Collection[]; selected?: string[];
  action: (form: FormData) => Promise<void>; submit: string;
}) {
  const p = product;
  const dollars = (c: number | null | undefined) => (c == null ? "" : (c / 100).toFixed(2));
  return (
    <form action={action} className="grid gap-4 sm:grid-cols-2">
      {p && <input type="hidden" name="id" value={p.id} />}
      <Field label="Product name"><input name="name" required defaultValue={p?.name} className="input" /></Field>
      <Field label="URL slug (auto if empty)"><input name="slug" defaultValue={p?.slug} className="input" /></Field>
      <Field label="Description" className="sm:col-span-2"><textarea name="description" rows={4} defaultValue={p?.description} className="input h-auto py-2" /></Field>
      <Field label="Department">
        <select name="department" defaultValue={p?.department ?? "clothing"} className="input">
          <option value="clothing">Clothing</option><option value="footwear">Shoes & Sneakers</option><option value="accessories">Accessories</option>
        </select>
      </Field>
      <Field label="Category">
        <select name="category_id" defaultValue={p?.category_id ?? ""} className="input">
          <option value="">—</option>
          {(["clothing", "footwear", "accessories"] as const).map((d) => (
            <optgroup key={d} label={d}>{categories.filter((c) => c.department === d).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</optgroup>
          ))}
        </select>
      </Field>
      <Field label="Size type">
        <select name="size_system" defaultValue={p?.size_system ?? "clothing"} className="input">
          <option value="clothing">Clothing sizes (XS–XXL)</option><option value="shoe">Shoe sizes (US / EU)</option><option value="one">One size</option>
        </select>
      </Field>
      <Field label="Gender">
        <select name="gender" defaultValue={p?.gender ?? "unisex"} className="input"><option value="women">Women&apos;s</option><option value="men">Men&apos;s</option><option value="unisex">Unisex</option></select>
      </Field>
      <Field label="Price (USD)"><input name="price" type="number" step="0.01" min="0" required defaultValue={dollars(p?.price_cents)} className="input" /></Field>
      <Field label="Compare-at price (shows as sale)"><input name="compare_at" type="number" step="0.01" min="0" defaultValue={dollars(p?.compare_at_cents)} className="input" /></Field>
      <Field label="Brand"><input name="brand" defaultValue={p?.brand ?? "Velvoria"} className="input" /></Field>
      <Field label="Style (e.g. Retro, Court, Oversized)"><input name="style" defaultValue={p?.style ?? ""} className="input" /></Field>
      <Field label="Materials" className="sm:col-span-2"><input name="materials" defaultValue={p?.materials ?? ""} className="input" /></Field>
      <Field label="Construction details"><input name="construction" defaultValue={p?.construction ?? ""} className="input" /></Field>
      <Field label="Fit note (only when verified)"><input name="fit_note" defaultValue={p?.fit_note ?? ""} placeholder="e.g. True to size" className="input" /></Field>
      <fieldset className="sm:col-span-2">
        <legend className="label">Flags</legend>
        <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
          {([["active", "Visible in store", p ? p.active : true], ["is_new", "New Arrival", p?.is_new], ["is_trending", "Trending", p?.is_trending], ["is_bestseller", "Best Seller", p?.is_bestseller], ["is_featured", "Featured (Sneaker Spotlight)", p?.is_featured], ["is_demo", "Demo product (blocked at checkout)", p ? p.is_demo : false]] as const).map(([n, l, v]) => (
            <label key={n} className="flex items-center gap-2"><input type="checkbox" name={n} defaultChecked={Boolean(v)} className="accent-charcoal" />{l}</label>
          ))}
        </div>
      </fieldset>
      <fieldset className="sm:col-span-2">
        <legend className="label">Collections</legend>
        <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
          {collections.map((c) => <label key={c.id} className="flex items-center gap-2"><input type="checkbox" name="collections" value={c.id} defaultChecked={selected.includes(c.id)} className="accent-charcoal" />{c.name}</label>)}
        </div>
      </fieldset>
      <div className="sm:col-span-2"><button className="btn-dark">{submit}</button></div>
    </form>
  );
}
