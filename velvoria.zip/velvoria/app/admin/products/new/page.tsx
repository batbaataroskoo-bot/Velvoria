import { requireAdmin } from "@/lib/auth";
import { getCategories } from "@/lib/catalog";
import { createAdminClient } from "@/lib/supabase/admin";
import type { Collection } from "@/lib/types";
import { createProduct } from "../../actions";
import { ProductForm } from "../ProductForm";
import { Card, H } from "../../ui";

export default async function Page() {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const [categories, { data: collections }] = await Promise.all([getCategories(), createAdminClient().from("collections").select("*").order("sort")]);
  return (
    <div>
      <H>Add product</H>
      <Card><ProductForm categories={categories} collections={(collections ?? []) as Collection[]} action={createProduct} submit="Create product" /></Card>
      <p className="mt-3 text-xs text-ink-soft">After creating the product you can add colorways, sizes, stock and photos.</p>
    </div>
  );
}
