import { requireAdmin } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import type { Collection } from "@/lib/types";
import { saveCollection, deleteCollection } from "../actions";
import { Card, H, Field } from "../ui";

export default async function Page() {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const { data } = await createAdminClient().from("collections").select("*").order("sort");
  const cols = (data ?? []) as Collection[];
  const form = (c?: Collection) => (
    <form action={saveCollection} className="grid gap-3 sm:grid-cols-2">
      {c && <input type="hidden" name="id" value={c.id} />}
      <Field label="Name"><input name="name" defaultValue={c?.name} required className="input" /></Field>
      <Field label="Slug"><input name="slug" defaultValue={c?.slug} className="input" /></Field>
      <Field label="Description" className="sm:col-span-2"><input name="description" defaultValue={c?.description ?? ""} className="input" /></Field>
      <Field label="Cover image (optional)"><input name="image" type="file" accept="image/jpeg,image/png,image/webp,image/avif" className="text-sm" /></Field>
      <Field label="Sort"><input name="sort" type="number" defaultValue={c?.sort ?? 0} className="input" /></Field>
      <div className="flex gap-6 text-sm sm:col-span-2">
        <label className="flex items-center gap-2"><input type="checkbox" name="is_seasonal" defaultChecked={c?.is_seasonal} className="accent-charcoal" />Seasonal</label>
        <label className="flex items-center gap-2"><input type="checkbox" name="active" defaultChecked={c ? c.active : true} className="accent-charcoal" />Active</label>
      </div>
      <div><button className="btn-outline h-10">{c ? "Save" : "Create collection"}</button></div>
    </form>
  );
  return (
    <div className="space-y-6">
      <H>Collections</H>
      <p className="-mt-3 text-sm text-ink-soft">Assign products to collections from each product&apos;s page.</p>
      <Card title="New collection">{form()}</Card>
      {cols.map((c) => (
        <Card key={c.id} title={c.name}>
          {form(c)}
          <form action={deleteCollection} className="mt-3"><input type="hidden" name="id" value={c.id} /><button className="text-xs text-red-700 underline">Delete collection</button></form>
        </Card>
      ))}
    </div>
  );
}
