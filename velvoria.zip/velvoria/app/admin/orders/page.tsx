import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { createAdminClient } from "@/lib/supabase/admin";
import { money } from "@/lib/format";
import { StatusBadge } from "@/app/account/StatusBadge";
import { H, th, td } from "../ui";

const STATUSES = ["paid", "processing", "shipped", "delivered", "cancelled", "refunded", "pending"];

export default async function Page({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const { status } = await searchParams;
  let q = createAdminClient().from("orders").select("id, order_number, status, email, total_cents, created_at, shipping_method").order("created_at", { ascending: false }).limit(200);
  if (status && STATUSES.includes(status)) q = q.eq("status", status);
  else q = q.neq("status", "pending");
  const { data: orders } = await q;
  return (
    <div>
      <H>Orders</H>
      <div className="mb-4 flex flex-wrap gap-2 text-xs">
        <Link href="/admin/orders" className={`border px-3 py-1.5 ${!status ? "border-charcoal bg-charcoal text-cream" : "border-charcoal/20"}`}>All placed</Link>
        {STATUSES.map((s) => <Link key={s} href={`/admin/orders?status=${s}`} className={`border px-3 py-1.5 capitalize ${status === s ? "border-charcoal bg-charcoal text-cream" : "border-charcoal/20"}`}>{s === "pending" ? "Abandoned / unpaid" : s}</Link>)}
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[680px] text-sm">
          <thead><tr><th className={th}>Order</th><th className={th}>Date</th><th className={th}>Customer</th><th className={th}>Shipping</th><th className={th}>Status</th><th className={th}>Total</th></tr></thead>
          <tbody>{(orders ?? []).map((o) => (
            <tr key={o.id} className="border-t border-charcoal/10">
              <td className={td}><Link href={`/admin/orders/${o.id}`} className="font-medium underline">#{o.order_number}</Link></td>
              <td className={td}>{new Date(o.created_at).toLocaleString()}</td><td className={td}>{o.email ?? "—"}</td><td className={td}>{o.shipping_method ?? "—"}</td>
              <td className={td}><StatusBadge status={o.status} /></td><td className={td}>{money(o.total_cents)}</td>
            </tr>
          ))}</tbody>
        </table>
        <p className="mt-3 text-xs text-ink-soft">{(orders ?? []).length} orders shown (newest 200 at most).</p>
      </div>
    </div>
  );
}
