import { requireAdmin } from "@/lib/auth";
import Link from "next/link";
import { notFound } from "next/navigation";
import { createAdminClient } from "@/lib/supabase/admin";
import { money } from "@/lib/format";
import { updateOrder } from "../../actions";
import { Card, H, Field } from "../../ui";
import { StatusBadge } from "@/app/account/StatusBadge";

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  await requireAdmin(); // checked again here: layouts alone are not a security boundary
  const { id } = await params;
  const { data: o } = await createAdminClient().from("orders").select("*, order_items(*)").eq("id", id).maybeSingle();
  if (!o) notFound();
  const addr = o.shipping_address as Record<string, string> | null;
  return (
    <div className="space-y-6">
      <Link href="/admin/orders" className="text-xs underline">← Orders</Link>
      <H action={<StatusBadge status={o.status} />}>Order #{o.order_number}</H>
      <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <Card title="Items">
          <ul className="divide-y divide-charcoal/10">
            {(o.order_items as { id: string; name: string; color: string; size: string; quantity: number; unit_price_cents: number }[]).map((i) => (
              <li key={i.id} className="flex justify-between py-3 text-sm"><span>{i.name}<span className="block text-xs text-ink-soft">{i.color} · {i.size} · Qty {i.quantity}</span></span><span>{money(i.unit_price_cents * i.quantity)}</span></li>
            ))}
          </ul>
          <dl className="mt-3 space-y-1 border-t border-charcoal/10 pt-3 text-sm">
            <div className="flex justify-between"><dt>Subtotal</dt><dd>{money(o.subtotal_cents)}</dd></div>
            {o.discount_cents > 0 && <div className="flex justify-between"><dt>Discount ({o.discount_code})</dt><dd>−{money(o.discount_cents)}</dd></div>}
            <div className="flex justify-between"><dt>Shipping ({o.shipping_method ?? "—"})</dt><dd>{money(o.shipping_cents)}</dd></div>
            <div className="flex justify-between"><dt>Tax</dt><dd>{money(o.tax_cents)}</dd></div>
            <div className="flex justify-between font-medium"><dt>Total charged</dt><dd>{money(o.total_cents)}</dd></div>
          </dl>
          {o.stripe_payment_intent && <p className="mt-3 text-xs text-ink-soft">Stripe payment: {o.stripe_payment_intent} — refunds are issued from your Stripe dashboard and update here automatically.</p>}
        </Card>
        <div className="space-y-6">
          <Card title="Customer & shipping">
            <p className="text-sm">{o.email ?? "—"}{!o.user_id && <span className="ml-2 text-xs text-ink-soft">(guest)</span>}</p>
            {addr ? <address className="mt-2 text-sm not-italic text-ink-soft">{addr.name}<br />{addr.line1}{addr.line2 ? `, ${addr.line2}` : ""}<br />{addr.city}, {addr.state} {addr.postal_code}<br />{addr.phone}</address> : <p className="text-sm text-ink-soft">No address yet (unpaid).</p>}
          </Card>
          <Card title="Fulfilment">
            <form action={updateOrder} className="space-y-3">
              <input type="hidden" name="id" value={o.id} />
              <Field label="Status">
                <select name="status" defaultValue={o.status} className="input">
                  {["pending", "paid", "processing", "shipped", "delivered", "cancelled", "refunded"].map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </Field>
              <Field label="Tracking number"><input name="tracking_number" defaultValue={o.tracking_number ?? ""} className="input" /></Field>
              <Field label="Tracking link (https://)"><input name="tracking_url" defaultValue={o.tracking_url ?? ""} className="input" /></Field>
              <button className="btn-dark h-10">Update order</button>
              <p className="text-xs text-ink-soft">Customers see the status and tracking in their account. Automatic shipping emails are not set up.</p>
            </form>
          </Card>
        </div>
      </div>
    </div>
  );
}
