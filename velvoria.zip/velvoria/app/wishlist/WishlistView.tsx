"use client";

import Link from "next/link";
import type { ProductFull } from "@/lib/types";
import { useStore } from "@/components/StoreProvider";
import { ProductGrid } from "@/components/ProductCard";

export function WishlistView({ products }: { products: ProductFull[] }) {
  const { wish, ready, userId } = useStore();
  if (!ready) return null;
  const list = wish.map((id) => products.find((p) => p.id === id)).filter(Boolean) as ProductFull[];
  const clothing = list.filter((p) => p.department !== "footwear");
  const shoes = list.filter((p) => p.department === "footwear");
  if (!list.length) {
    return (
      <div className="py-16 text-center">
        <p className="text-ink-soft">Tap the heart on any product to save it here.</p>
        <div className="mt-6 flex justify-center gap-3"><Link href="/clothing" className="btn-dark">Shop Clothing</Link><Link href="/shoes" className="btn-outline">Shop Sneakers</Link></div>
      </div>
    );
  }
  return (
    <div className="space-y-16">
      {!userId && <p className="bg-sand/60 px-4 py-3 text-sm"><Link href="/login?next=/wishlist" className="link-u">Sign in</Link> to keep your wishlist on every device.</p>}
      {shoes.length > 0 && <section><h2 className="eyebrow mb-5">Shoes & Sneakers ({shoes.length})</h2><ProductGrid products={shoes} /></section>}
      {clothing.length > 0 && <section><h2 className="eyebrow mb-5">Clothing & Accessories ({clothing.length})</h2><ProductGrid products={clothing} /></section>}
    </div>
  );
}
