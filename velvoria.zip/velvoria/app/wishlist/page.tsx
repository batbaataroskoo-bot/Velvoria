import type { Metadata } from "next";
import { getAllProducts } from "@/lib/catalog";
import { WishlistView } from "./WishlistView";

export const metadata: Metadata = { title: "Wishlist", robots: { index: false } };

export default async function Page() {
  const products = await getAllProducts();
  return (
    <div className="container-x pt-10 sm:pt-14">
      <h1 className="headline mb-8 text-4xl sm:text-5xl">Wishlist</h1>
      <WishlistView products={products} />
    </div>
  );
}
