import type { Metadata } from "next";
import { Catalog } from "@/components/Catalog";
import type { SP } from "@/lib/filters";

export const metadata: Metadata = { title: "Clothing", description: "Everyday clothing: tees, hoodies, denim, trousers, outerwear, dresses and knitwear.", alternates: { canonical: "/clothing" } };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  return (
    <Catalog title="Clothing" eyebrow="Everyday wardrobe" intro="Relaxed essentials, denim and layers designed to be worn on repeat."
      preset={{ department: "clothing" }} searchParams={await searchParams} basePath="/clothing"
      quickLinks={[["T-Shirts & Tops", "/shop/t-shirts-tops"], ["Hoodies & Sweatshirts", "/shop/hoodies-sweatshirts"], ["Jeans & Denim", "/shop/jeans-denim"], ["Pants & Trousers", "/shop/pants-trousers"], ["Jackets & Outerwear", "/shop/jackets-outerwear"], ["Dresses & Skirts", "/shop/dresses-skirts"], ["Knitwear", "/shop/knitwear"], ["Shorts", "/shop/shorts"], ["Activewear", "/shop/activewear"], ["Everyday Essentials", "/shop/everyday-essentials"]]} />
  );
}
