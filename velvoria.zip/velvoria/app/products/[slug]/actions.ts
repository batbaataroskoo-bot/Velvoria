"use server";

import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import type { FormState } from "@/app/actions";

const Review = z.object({
  productId: z.string().uuid(),
  rating: z.coerce.number().int().min(1).max(5),
  title: z.string().trim().max(120).optional(),
  body: z.string().trim().min(10).max(2000),
  fit: z.enum(["small", "true", "large"]).optional(),
});

export async function submitReview(_: FormState, form: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { ok: false, message: "Please sign in to write a review." };
  const raw = Object.fromEntries(form);
  const parsed = Review.safeParse({ ...raw, fit: raw.fit || undefined, title: raw.title || undefined });
  if (!parsed.success) return { ok: false, message: "Please choose a rating and write at least 10 characters." };
  const { data: profile } = await supabase.from("profiles").select("full_name").eq("id", user.id).single();
  const { error } = await supabase.from("reviews").insert({
    product_id: parsed.data.productId, user_id: user.id, rating: parsed.data.rating, title: parsed.data.title ?? null,
    body: parsed.data.body, fit: parsed.data.fit ?? null, approved: false,
    author_name: (profile?.full_name || user.email?.split("@")[0] || "Customer").slice(0, 60),
  });
  if (error) return { ok: false, message: "Could not save your review. Please try again." };
  return { ok: true, message: "Thanks! Your review will appear once it has been approved." };
}
