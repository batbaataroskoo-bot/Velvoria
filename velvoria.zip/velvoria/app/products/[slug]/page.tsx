import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getAllProducts, getProduct, getReviews, totalStock } from "@/lib/catalog";
import { ProductDetail } from "@/components/ProductDetail";
import { ProductRail, SectionHead, LookCard } from "@/components/Sections";
import { RecentlyViewed } from "@/components/RecentlyViewed";
import { StarIcon } from "@/components/Icons";
import { createClient } from "@/lib/supabase/server";
import { ReviewForm } from "./ReviewForm";
import { SITE_URL } from "@/lib/format";
import type { ProductFull } from "@/lib/types";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await getProduct((await params).slug);
  if (!p) return {};
  const img = p.images[0]?.url;
  return {
    title: p.name,
    description: p.description.slice(0, 155),
    alternates: { canonical: `/products/${p.slug}` },
    openGraph: { title: p.name, description: p.description.slice(0, 155), images: img ? [img] : undefined },
  };
}

function outfitFor(p: ProductFull, all: ProductFull[]) {
  const others = all.filter((x) => x.id !== p.id && x.department !== p.department && x.collections.some((c) => p.collections.includes(c)));
  const pick = (pred: (x: ProductFull) => boolean) => others.find(pred);
  if (p.department === "footwear") {
    const top = pick((x) => ["t-shirts-tops", "hoodies-sweatshirts", "knitwear", "jackets-outerwear", "dresses-skirts"].includes(x.category?.slug ?? ""));
    const bottom = top?.category?.slug === "dresses-skirts" ? undefined : pick((x) => ["jeans-denim", "pants-trousers", "shorts"].includes(x.category?.slug ?? ""));
    return [top, bottom, p].filter(Boolean) as ProductFull[];
  }
  const shoe = pick((x) => x.department === "footwear");
  const acc = pick((x) => x.department === "accessories");
  return [p, shoe, acc].filter(Boolean) as ProductFull[];
}

export default async function Page({ params }: Props) {
  const { slug } = await params;
  const [product, all] = await Promise.all([getProduct(slug), getAllProducts()]);
  if (!product) notFound();
  const reviews = await getReviews(product.id);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;
  const fitVotes = reviews.filter((r) => r.fit);
  const related = all
    .filter((p) => p.id !== product.id && p.department === product.department)
    .sort((a, b) => Number(b.category_id === product.category_id) - Number(a.category_id === product.category_id) || b.popularity - a.popularity)
    .slice(0, 4);
  const outfit = outfitFor(product, all);
  const isShoe = product.department === "footwear";

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    description: product.description,
    brand: { "@type": "Brand", name: product.brand },
    sku: product.variants[0]?.sku,
    image: product.images.map((i) => i.url),
    url: `${SITE_URL}/products/${product.slug}`,
    offers: {
      "@type": "Offer", priceCurrency: "USD", price: (product.price_cents / 100).toFixed(2),
      availability: totalStock(product) > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
    ...(reviews.length ? { aggregateRating: { "@type": "AggregateRating", ratingValue: avg.toFixed(1), reviewCount: reviews.length } } : {}),
  };

  return (
    <div className="container-x pb-24 pt-6 sm:pt-10 lg:pb-0">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }} />
      <nav aria-label="Breadcrumb" className="mb-5 text-xs text-ink-soft">
        <Link href="/" className="hover:underline">Home</Link> /{" "}
        <Link href={isShoe ? "/shoes" : product.department === "clothing" ? "/clothing" : "/accessories"} className="hover:underline">{isShoe ? "Shoes & Sneakers" : product.department === "clothing" ? "Clothing" : "Accessories"}</Link>
        {product.category && <> / <Link href={`/shop/${product.category.slug}`} className="hover:underline">{product.category.name}</Link></>}
      </nav>

      <ProductDetail product={product} rating={{ avg, count: reviews.length }} />

      {outfit.length > 1 && (
        <section className="mt-24">
          <SectionHead eyebrow="Outfit recommendation" title="Complete the Look" />
          <div className="max-w-2xl"><LookCard look={outfit} index={0} /></div>
        </section>
      )}

      <section id="reviews" className="mt-24 scroll-mt-24">
        <SectionHead eyebrow="Customer reviews" title={reviews.length ? `${avg.toFixed(1)} out of 5` : "Reviews"} />
        <div className="grid gap-12 lg:grid-cols-[1fr_1.4fr]">
          <div>
            {fitVotes.length > 0 && (
              <div className="mb-8">
                <p className="label">Fit feedback ({fitVotes.length})</p>
                {(["small", "true", "large"] as const).map((f) => {
                  const n = fitVotes.filter((r) => r.fit === f).length;
                  return (
                    <div key={f} className="mb-2 flex items-center gap-3 text-sm">
                      <span className="w-28">{f === "true" ? "True to size" : f === "small" ? "Runs small" : "Runs large"}</span>
                      <span className="h-1.5 flex-1 bg-sand"><span className="block h-1.5 bg-charcoal" style={{ width: `${(n / fitVotes.length) * 100}%` }} /></span>
                      <span className="w-6 text-right text-ink-soft">{n}</span>
                    </div>
                  );
                })}
              </div>
            )}
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-[0.14em]">Write a review</h3>
            {user ? <ReviewForm productId={product.id} isShoe={isShoe} /> : <p className="text-sm text-ink-soft"><Link href={`/login?next=/products/${product.slug}`} className="link-u">Sign in</Link> to write a review.</p>}
          </div>
          <ul className="divide-y divide-charcoal/10">
            {reviews.length === 0 && <li className="py-4 text-sm text-ink-soft">No reviews yet — be the first.</li>}
            {reviews.map((r) => (
              <li key={r.id} className="py-6">
                <div className="flex items-center gap-1" aria-label={`${r.rating} out of 5 stars`}>
                  {[1, 2, 3, 4, 5].map((i) => <StarIcon key={i} filled={i <= r.rating} className="h-3.5 w-3.5" />)}
                </div>
                {r.title && <p className="mt-2 font-medium">{r.title}</p>}
                <p className="mt-1 text-sm leading-6 text-ink-soft">{r.body}</p>
                <p className="mt-2 text-xs text-ink-soft">{r.author_name} · {new Date(r.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}{r.fit ? ` · Fit: ${r.fit === "true" ? "true to size" : `runs ${r.fit}`}` : ""}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {related.length > 0 && (
        <section className="mt-24">
          <SectionHead eyebrow="You may also like" title={isShoe ? "Related Sneakers & Shoes" : "Related Products"} />
          <ProductRail products={related} />
        </section>
      )}

      <RecentlyViewed products={all} excludeId={product.id} />
    </div>
  );
}
