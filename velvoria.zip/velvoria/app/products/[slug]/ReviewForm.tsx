"use client";

import { useActionState } from "react";
import { submitReview } from "./actions";

export function ReviewForm({ productId, isShoe }: { productId: string; isShoe: boolean }) {
  const [state, action, pending] = useActionState(submitReview, null);
  if (state?.ok) return <p className="bg-sage/30 p-4 text-sm">{state.message}</p>;
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="productId" value={productId} />
      <fieldset>
        <legend className="label">Rating</legend>
        <div className="flex gap-3">
          {[5, 4, 3, 2, 1].map((n) => (
            <label key={n} className="flex items-center gap-1 text-sm"><input type="radio" name="rating" value={n} required className="accent-charcoal" />{n}★</label>
          ))}
        </div>
      </fieldset>
      <div><label className="label" htmlFor="rv-title">Title</label><input id="rv-title" name="title" maxLength={120} className="input" /></div>
      <div><label className="label" htmlFor="rv-body">Review</label><textarea id="rv-body" name="body" required minLength={10} maxLength={2000} rows={4} className="input h-auto py-2" /></div>
      <div>
        <label className="label" htmlFor="rv-fit">How did it fit?</label>
        <select id="rv-fit" name="fit" className="input">
          <option value="">Prefer not to say</option>
          <option value="small">Runs small</option>
          <option value="true">True to size</option>
          <option value="large">Runs large</option>
        </select>
        {isShoe && <p className="mt-1 text-xs text-ink-soft">Fit feedback helps us verify sizing notes for this shoe.</p>}
      </div>
      {state && !state.ok && <p role="alert" className="text-sm text-red-700">{state.message}</p>}
      <button className="btn-dark" disabled={pending}>{pending ? "Sending…" : "Submit review"}</button>
    </form>
  );
}
