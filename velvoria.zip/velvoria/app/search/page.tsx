import type { Metadata } from "next";
import { Catalog } from "@/components/Catalog";
import type { SP } from "@/lib/filters";

export const metadata: Metadata = { title: "Search", robots: { index: false } };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const q = (Array.isArray(sp.q) ? sp.q[0] : sp.q) ?? "";
  return <Catalog title={q ? `Results for “${q}”` : "Search"} searchParams={sp} basePath={`/search?q=${encodeURIComponent(q)}`} />;
}
