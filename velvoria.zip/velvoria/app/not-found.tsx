import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container-x py-28 text-center">
      <p className="eyebrow mb-3">404</p>
      <h1 className="headline text-5xl">This page stepped out.</h1>
      <p className="mt-4 text-ink-soft">The page you&apos;re looking for doesn&apos;t exist or has moved.</p>
      <div className="mt-8 flex justify-center gap-3"><Link href="/" className="btn-dark">Home</Link><Link href="/shoes" className="btn-outline">Shop Sneakers</Link></div>
    </div>
  );
}
