"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import type { FormState } from "@/app/actions";

async function userClient() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");
  return { supabase, user };
}

export async function updateProfile(_: FormState, form: FormData): Promise<FormState> {
  const parsed = z.object({ full_name: z.string().trim().max(120), phone: z.string().trim().max(30) }).safeParse(Object.fromEntries(form));
  if (!parsed.success) return { ok: false, message: "Please check your details." };
  const { supabase, user } = await userClient();
  const { error } = await supabase.from("profiles").update(parsed.data).eq("id", user.id);
  revalidatePath("/account");
  return error ? { ok: false, message: "Could not save." } : { ok: true, message: "Profile saved." };
}

const Address = z.object({
  label: z.string().trim().max(40).default("Home"),
  full_name: z.string().trim().min(1).max(120),
  line1: z.string().trim().min(1).max(200),
  line2: z.string().trim().max(200).optional(),
  city: z.string().trim().min(1).max(100),
  state: z.string().trim().min(2).max(50),
  postal_code: z.string().trim().regex(/^\d{5}(-\d{4})?$/, "Enter a valid ZIP code"),
  country: z.literal("US").default("US"),
  is_default: z.preprocess((v) => v === "on", z.boolean()),
});

export async function addAddress(_: FormState, form: FormData): Promise<FormState> {
  const parsed = Address.safeParse(Object.fromEntries(form));
  if (!parsed.success) return { ok: false, message: parsed.error.issues[0]?.message ?? "Please complete the address." };
  const { supabase, user } = await userClient();
  if (parsed.data.is_default) await supabase.from("addresses").update({ is_default: false }).eq("user_id", user.id);
  const { error } = await supabase.from("addresses").insert({ ...parsed.data, user_id: user.id });
  revalidatePath("/account/addresses");
  return error ? { ok: false, message: "Could not save address." } : { ok: true, message: "Address saved." };
}

export async function deleteAddress(form: FormData) {
  const id = z.string().uuid().parse(form.get("id"));
  const { supabase } = await userClient();
  await supabase.from("addresses").delete().eq("id", id); // RLS limits this to the user's own rows
  revalidatePath("/account/addresses");
}
