import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { isAdmin } from "@/lib/auth";
import { signOut } from "@/app/(auth)/actions";

export const dynamic = "force-dynamic";

export default async function AccountLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const admin = await isAdmin(user.id);
  return (
    <div className="container-x pt-10 sm:pt-14">
      <p className="eyebrow mb-2">My account</p>
      <h1 className="headline mb-8 text-4xl sm:text-5xl">Hello{user.user_metadata?.full_name ? `, ${String(user.user_metadata.full_name).split(" ")[0]}` : ""}.</h1>
      <div className="grid gap-10 lg:grid-cols-[220px_1fr]">
        <nav aria-label="Account" className="no-scrollbar flex gap-5 overflow-x-auto border-b border-charcoal/10 pb-3 text-sm lg:flex-col lg:gap-3 lg:border-0">
          <Link href="/account" className="shrink-0 hover:underline">Profile</Link>
          <Link href="/account/orders" className="shrink-0 hover:underline">Orders</Link>
          <Link href="/account/addresses" className="shrink-0 hover:underline">Addresses</Link>
          <Link href="/wishlist" className="shrink-0 hover:underline">Wishlist</Link>
          {admin && <Link href="/admin" className="shrink-0 font-medium hover:underline">Admin dashboard</Link>}
          <form action={signOut}><button className="shrink-0 text-ink-soft hover:underline">Sign out</button></form>
        </nav>
        <div>{children}</div>
      </div>
    </div>
  );
}
