import Link from "next/link";
import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { money } from "@/lib/format";
import { StatusBadge } from "../../StatusBadge";

const STEPS = ["paid", "processing", "shipped", "delivered"];

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await requireUser("/account/orders");
  const supabase = await createClient();
  const { data: o } = await supabase.from("orders").select("*, order_items(*)").eq("id", id).maybeSingle(); // RLS: own orders only
  if (!o) notFound();
  const step = STEPS.indexOf(o.status);
  const addr = o.shipping_address as Record<string, string> | null;
  return (
    <section>
      <Link href="/account/orders" className="text-xs underline underline-offset-4">← All orders</Link>
      <div className="mb-6 mt-4 flex flex-wrap items-center gap-3">
        <h2 className="headline text-3xl">Order #{o.order_number}</h2><StatusBadge status={o.status} />
      </div>
      {step >= 0 && (
        <ol className="mb-8 grid grid-cols-4 gap-2 text-[11px] uppercase tracking-[0.1em]">
          {STEPS.map((s, i) => <li key={s} className={`border-t-2 pt-2 ${i <= step ? "border-charcoal" : "border-charcoal/15 text-ink-soft"}`}>{s === "paid" ? "Confirmed" : s}</li>)}
        </ol>
      )}
      {o.tracking_number && (
        <p className="mb-6 bg-sand/60 px-4 py-3 text-sm">Tracking: <strong>{o.tracking_number}</strong>{o.tracking_url && <> — <a href={o.tracking_url} target="_blank" rel="noopener noreferrer" className="link-u">Track package</a></>}</p>
      )}
      <ul className="divide-y divide-charcoal/10 border-y border-charcoal/10">
        {(o.order_items as { id: string; name: string; color: string; size: string; quantity: number; unit_price_cents: number }[]).map((i) => (
          <li key={i.id} className="flex justify-between py-4 text-sm"><span>{i.name}<span className="block text-xs text-ink-soft">{i.color} · {i.size} · Qty {i.quantity}</span></span><span>{money(i.unit_price_cents * i.quantity)}</span></li>
        ))}
      </ul>
      <div className="mt-6 grid gap-8 sm:grid-cols-2">
        <dl className="space-y-1 text-sm">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{money(o.subtotal_cents)}</dd></div>
          {o.discount_cents > 0 && <div className="flex justify-between"><dt>Discount</dt><dd>−{money(o.discount_cents)}</dd></div>}
          <div className="flex justify-between"><dt>Shipping ({o.shipping_method ?? "Standard"})</dt><dd>{o.shipping_cents ? money(o.shipping_cents) : "Free"}</dd></div>
          {o.tax_cents > 0 && <div className="flex justify-between"><dt>Tax</dt><dd>{money(o.tax_cents)}</dd></div>}
          <div className="flex justify-between border-t border-charcoal/10 pt-2 font-medium"><dt>Total</dt><dd>{money(o.total_cents)}</dd></div>
        </dl>
        {addr && <address className="text-sm not-italic text-ink-soft"><span className="label">Ships to</span>{addr.name}<br />{addr.line1}{addr.line2 ? `, ${addr.line2}` : ""}<br />{addr.city}, {addr.state} {addr.postal_code}</address>}
      </div>
    </section>
  );
}
