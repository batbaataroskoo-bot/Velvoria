import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { money } from "@/lib/format";
import { StatusBadge } from "../StatusBadge";

export default async function Page() {
  const user = await requireUser("/account/orders");
  const supabase = await createClient();
  const { data: orders } = await supabase.from("orders").select("id, order_number, status, total_cents, created_at, order_items(quantity)")
    .eq("user_id", user.id).neq("status", "pending").order("created_at", { ascending: false });
  return (
    <section>
      <h2 className="mb-6 text-sm font-semibold uppercase tracking-[0.14em]">Order history</h2>
      {!orders?.length ? <p className="text-sm text-ink-soft">No orders yet. <Link href="/" className="link-u">Start shopping</Link></p> : (
        <ul className="divide-y divide-charcoal/10 border-y border-charcoal/10">
          {orders.map((o) => (
            <li key={o.id}>
              <Link href={`/account/orders/${o.id}`} className="flex flex-wrap items-center justify-between gap-3 py-4 hover:bg-sand/30">
                <span className="font-medium">#{o.order_number}</span>
                <span className="text-sm text-ink-soft">{new Date(o.created_at).toLocaleDateString()}</span>
                <span className="text-sm text-ink-soft">{(o.order_items as { quantity: number }[]).reduce((s, i) => s + i.quantity, 0)} items</span>
                <StatusBadge status={o.status} />
                <span className="text-sm">{money(o.total_cents)}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
