import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { deleteAddress } from "../actions";
import { AddressForm } from "./AddressForm";

export default async function Page() {
  const user = await requireUser("/account/addresses");
  const supabase = await createClient();
  const { data: addresses } = await supabase.from("addresses").select("*").eq("user_id", user.id).order("is_default", { ascending: false });
  return (
    <section className="space-y-10">
      <div>
        <h2 className="mb-6 text-sm font-semibold uppercase tracking-[0.14em]">Saved shipping addresses</h2>
        {!addresses?.length ? <p className="text-sm text-ink-soft">No saved addresses yet.</p> : (
          <ul className="grid gap-4 sm:grid-cols-2">
            {addresses.map((a) => (
              <li key={a.id} className="border border-charcoal/15 bg-white/50 p-4 text-sm">
                <p className="mb-1 font-medium">{a.label}{a.is_default && <span className="ml-2 bg-sage/50 px-1.5 py-0.5 text-[10px] uppercase">Default</span>}</p>
                <p className="text-ink-soft">{a.full_name}<br />{a.line1}{a.line2 ? `, ${a.line2}` : ""}<br />{a.city}, {a.state} {a.postal_code}</p>
                <form action={deleteAddress} className="mt-3"><input type="hidden" name="id" value={a.id} /><button className="text-xs underline">Remove</button></form>
              </li>
            ))}
          </ul>
        )}
      </div>
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-[0.14em]">Add an address</h3>
        <AddressForm />
        <p className="mt-4 text-xs text-ink-soft">Your shipping address is entered on the secure checkout page; saved addresses are kept here for your reference.</p>
      </div>
    </section>
  );
}
