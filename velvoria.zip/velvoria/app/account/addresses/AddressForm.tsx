"use client";

import { useActionState } from "react";
import { addAddress } from "../actions";

export function AddressForm() {
  const [s, a, pending] = useActionState(addAddress, null);
  return (
    <form action={a} className="grid max-w-xl gap-4 sm:grid-cols-2">
      <div><label className="label" htmlFor="label">Label</label><input id="label" name="label" defaultValue="Home" className="input" /></div>
      <div><label className="label" htmlFor="full_name">Full name</label><input id="full_name" name="full_name" required className="input" autoComplete="name" /></div>
      <div className="sm:col-span-2"><label className="label" htmlFor="line1">Address</label><input id="line1" name="line1" required className="input" autoComplete="address-line1" /></div>
      <div className="sm:col-span-2"><label className="label" htmlFor="line2">Apartment, suite (optional)</label><input id="line2" name="line2" className="input" autoComplete="address-line2" /></div>
      <div><label className="label" htmlFor="city">City</label><input id="city" name="city" required className="input" autoComplete="address-level2" /></div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="label" htmlFor="state">State</label><input id="state" name="state" required maxLength={2} className="input uppercase" autoComplete="address-level1" /></div>
        <div><label className="label" htmlFor="postal_code">ZIP</label><input id="postal_code" name="postal_code" required className="input" autoComplete="postal-code" /></div>
      </div>
      <input type="hidden" name="country" value="US" />
      <label className="flex items-center gap-2 text-sm sm:col-span-2"><input type="checkbox" name="is_default" className="accent-charcoal" /> Make this my default address</label>
      {s && <p role="status" className={`text-sm sm:col-span-2 ${s.ok ? "" : "text-red-700"}`}>{s.message}</p>}
      <button className="btn-dark sm:col-span-2 sm:justify-self-start" disabled={pending}>Save address</button>
    </form>
  );
}
