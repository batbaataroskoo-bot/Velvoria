const tone: Record<string, string> = {
  pending: "bg-mist", paid: "bg-sage/50", processing: "bg-sand", shipped: "bg-peach/60", delivered: "bg-sage", cancelled: "bg-red-100", refunded: "bg-red-100",
};
export function StatusBadge({ status }: { status: string }) {
  return <span className={`px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] ${tone[status] ?? "bg-mist"}`}>{status === "pending" ? "Awaiting payment" : status}</span>;
}
