import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { ProfileForm } from "./ProfileForm";

export default async function Page() {
  const user = await requireUser();
  const supabase = await createClient();
  const { data } = await supabase.from("profiles").select("full_name, phone").eq("id", user.id).single();
  return (
    <section>
      <h2 className="mb-6 text-sm font-semibold uppercase tracking-[0.14em]">Profile</h2>
      <ProfileForm name={data?.full_name ?? ""} phone={data?.phone ?? ""} email={user.email ?? ""} />
    </section>
  );
}
