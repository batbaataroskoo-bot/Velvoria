"use client";

import { useActionState } from "react";
import { updateProfile } from "./actions";

export function ProfileForm({ name, phone, email }: { name: string; phone: string; email: string }) {
  const [s, a, pending] = useActionState(updateProfile, null);
  return (
    <form action={a} className="max-w-md space-y-4">
      <div><label className="label">Email</label><input value={email} disabled className="input bg-mist" /></div>
      <div><label className="label" htmlFor="full_name">Full name</label><input id="full_name" name="full_name" defaultValue={name} className="input" /></div>
      <div><label className="label" htmlFor="phone">Phone</label><input id="phone" name="phone" defaultValue={phone} className="input" autoComplete="tel" /></div>
      {s && <p role="status" className="text-sm">{s.message}</p>}
      <button className="btn-dark" disabled={pending}>Save profile</button>
    </form>
  );
}
