"use server";

import { redirect } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { SITE_URL } from "@/lib/format";
import type { FormState } from "@/app/actions";

const safeNext = (n: FormDataEntryValue | null) => {
  const s = typeof n === "string" ? n : "";
  return s.startsWith("/") && !s.startsWith("//") ? s : "/account";
};
const Email = z.string().trim().toLowerCase().email().max(200);
const Password = z.string().min(8, "Password must be at least 8 characters.").max(72);

export async function login(_: FormState, form: FormData): Promise<FormState> {
  const email = Email.safeParse(form.get("email"));
  const password = z.string().min(1).safeParse(form.get("password"));
  if (!email.success || !password.success) return { ok: false, message: "Enter your email and password." };
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email: email.data, password: password.data });
  if (error) return { ok: false, message: "Email or password is incorrect." };
  redirect(safeNext(form.get("next")));
}

export async function register(_: FormState, form: FormData): Promise<FormState> {
  const parsed = z.object({ name: z.string().trim().min(1).max(120), email: Email, password: Password }).safeParse(Object.fromEntries(form));
  if (!parsed.success) return { ok: false, message: parsed.error.issues[0]?.message ?? "Please check your details." };
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email: parsed.data.email, password: parsed.data.password,
    options: { data: { full_name: parsed.data.name }, emailRedirectTo: `${SITE_URL}/auth/callback?next=/account` },
  });
  if (error) return { ok: false, message: error.message };
  if (data.session) redirect("/account");
  return { ok: true, message: "Check your inbox to confirm your email, then sign in." };
}

export async function forgotPassword(_: FormState, form: FormData): Promise<FormState> {
  const email = Email.safeParse(form.get("email"));
  if (!email.success) return { ok: false, message: "Enter a valid email." };
  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(email.data, { redirectTo: `${SITE_URL}/auth/callback?next=/reset-password` });
  return { ok: true, message: "If an account exists for that email, a reset link is on its way." };
}

export async function resetPassword(_: FormState, form: FormData): Promise<FormState> {
  const pw = Password.safeParse(form.get("password"));
  if (!pw.success) return { ok: false, message: pw.error.issues[0].message };
  if (pw.data !== form.get("confirm")) return { ok: false, message: "Passwords don't match." };
  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: pw.data });
  if (error) return { ok: false, message: "Your reset link has expired. Please request a new one." };
  redirect("/account");
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}
