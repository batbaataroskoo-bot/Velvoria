import type { Metadata } from "next";
import { LoginForm } from "../AuthForms";
export const metadata: Metadata = { title: "Sign in", robots: { index: false } };
export default async function Page({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  return <LoginForm next={(await searchParams).next} />;
}
