import type { Metadata } from "next";
import { ForgotForm } from "../AuthForms";
export const metadata: Metadata = { title: "Reset password", robots: { index: false } };
export default function Page() { return <ForgotForm />; }
