import type { Metadata } from "next";
import { ResetForm } from "../AuthForms";
export const metadata: Metadata = { title: "New password", robots: { index: false } };
export default function Page() { return <ResetForm />; }
