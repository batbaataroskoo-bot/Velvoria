import type { Metadata } from "next";
import { RegisterForm } from "../AuthForms";
export const metadata: Metadata = { title: "Create account", robots: { index: false } };
export default function Page() { return <RegisterForm />; }
