"use client";

import Link from "next/link";
import { useActionState } from "react";
import { login, register, forgotPassword, resetPassword } from "./actions";
import type { FormState } from "@/app/actions";

function Shell({ title, children, footer }: { title: string; children: React.ReactNode; footer?: React.ReactNode }) {
  return (
    <div className="container-x flex justify-center py-16 sm:py-24">
      <div className="w-full max-w-md">
        <h1 className="headline mb-8 text-center text-4xl">{title}</h1>
        {children}
        {footer && <div className="mt-8 text-center text-sm text-ink-soft">{footer}</div>}
      </div>
    </div>
  );
}
const Msg = ({ s }: { s: FormState }) => s ? <p role={s.ok ? "status" : "alert"} className={`text-sm ${s.ok ? "bg-sage/40 p-3" : "text-red-700"}`}>{s.message}</p> : null;
const Field = (p: { label: string; name: string; type?: string; auto?: string }) => (
  <div><label className="label" htmlFor={p.name}>{p.label}</label><input id={p.name} name={p.name} type={p.type ?? "text"} autoComplete={p.auto} required className="input" /></div>
);

export function LoginForm({ next }: { next?: string }) {
  const [s, a, pending] = useActionState(login, null);
  return (
    <Shell title="Sign in" footer={<>New to VELVORIA? <Link href="/register" className="link-u">Create an account</Link></>}>
      <form action={a} className="space-y-4">
        <input type="hidden" name="next" value={next ?? "/account"} />
        <Field label="Email" name="email" type="email" auto="email" />
        <Field label="Password" name="password" type="password" auto="current-password" />
        <Msg s={s} />
        <button className="btn-dark w-full" disabled={pending}>{pending ? "Signing in…" : "Sign in"}</button>
        <p className="text-center text-sm"><Link href="/forgot-password" className="link-u">Forgot your password?</Link></p>
      </form>
    </Shell>
  );
}

export function RegisterForm() {
  const [s, a, pending] = useActionState(register, null);
  return (
    <Shell title="Create account" footer={<>Already have an account? <Link href="/login" className="link-u">Sign in</Link></>}>
      <form action={a} className="space-y-4">
        <Field label="Full name" name="name" auto="name" />
        <Field label="Email" name="email" type="email" auto="email" />
        <Field label="Password (8+ characters)" name="password" type="password" auto="new-password" />
        <Msg s={s} />
        <button className="btn-dark w-full" disabled={pending}>{pending ? "Creating…" : "Create account"}</button>
        <p className="text-center text-xs text-ink-soft">By creating an account you agree to our <Link href="/terms" className="link-u">Terms</Link> and <Link href="/privacy" className="link-u">Privacy Policy</Link>.</p>
      </form>
    </Shell>
  );
}

export function ForgotForm() {
  const [s, a, pending] = useActionState(forgotPassword, null);
  return (
    <Shell title="Reset password" footer={<Link href="/login" className="link-u">Back to sign in</Link>}>
      <form action={a} className="space-y-4">
        <p className="text-sm text-ink-soft">Enter your email and we&apos;ll send you a link to set a new password.</p>
        <Field label="Email" name="email" type="email" auto="email" />
        <Msg s={s} />
        <button className="btn-dark w-full" disabled={pending}>Send reset link</button>
      </form>
    </Shell>
  );
}

export function ResetForm() {
  const [s, a, pending] = useActionState(resetPassword, null);
  return (
    <Shell title="Choose a new password">
      <form action={a} className="space-y-4">
        <Field label="New password" name="password" type="password" auto="new-password" />
        <Field label="Confirm password" name="confirm" type="password" auto="new-password" />
        <Msg s={s} />
        <button className="btn-dark w-full" disabled={pending}>Update password</button>
      </form>
    </Shell>
  );
}
