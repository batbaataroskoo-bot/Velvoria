import type { Metadata } from "next";
import { Catalog } from "@/components/Catalog";
import type { SP } from "@/lib/filters";

export const metadata: Metadata = { title: "Men", description: "Men's everyday clothing, sneakers and shoes — plus unisex essentials.", alternates: { canonical: "/men" } };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  return <Catalog title="Men" eyebrow="Men's & unisex" preset={{ gender: ["men"] }} searchParams={await searchParams} basePath="/men"
    quickLinks={[["Clothing", "/men?department=clothing"], ["Shoes & Sneakers", "/men?department=footwear"], ["Accessories", "/men?department=accessories"]]} />;
}
