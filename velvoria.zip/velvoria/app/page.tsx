import Link from "next/link";
import Image from "next/image";
import { getAllProducts, getBanners, isSneaker } from "@/lib/catalog";
import { Hero } from "@/components/Hero";
import { ProductRail, SectionHead, LookCard, buildLooks, EditorialTile } from "@/components/Sections";
import { ProductCard } from "@/components/ProductCard";
import { ProductArt } from "@/components/ProductArt";
import { Reveal, ImageReveal } from "@/components/Reveal";
import { Newsletter } from "@/components/Newsletter";
import { RecentlyViewed } from "@/components/RecentlyViewed";

export const revalidate = 60;

export default async function Home() {
  const [products, banners] = await Promise.all([getAllProducts(), getBanners()]);
  const hero = banners.find((b) => b.placement === "hero");
  const sneakerBanner = banners.find((b) => b.placement === "sneakers");
  const seasonal = banners.filter((b) => b.placement === "seasonal").slice(0, 2);

  const byPop = [...products].sort((a, b) => b.popularity - a.popularity);
  const trending = byPop.filter((p) => p.is_trending).slice(0, 8);
  const newest = [...products].filter((p) => p.is_new).sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at)).slice(0, 8);
  const bestSellers = byPop.filter((p) => p.is_bestseller).slice(0, 8);
  const sneakers = products.filter(isSneaker);
  const spotlight = [...sneakers.filter((p) => p.is_featured), ...sneakers.filter((p) => !p.is_featured && p.collections.includes("sneaker-spotlight"))].slice(0, 4);
  const everydayLooks = buildLooks(products, "everyday-edit", 3);
  const completeLooks = buildLooks(products, "complete-the-look", 2);

  return (
    <>
      <Hero banner={hero} />

      {trending.length > 0 && (
        <section className="container-x mt-20 sm:mt-28">
          <Reveal><SectionHead eyebrow="Right now" title="Trending Now" href="/shop?sort=popular" /></Reveal>
          <ProductRail products={trending.slice(0, 4)} />
        </section>
      )}

      {/* Shop by Category */}
      <section className="container-x mt-24 sm:mt-32">
        <Reveal><SectionHead eyebrow="Explore" title="Shop by Category" /></Reveal>
        <div className="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">
          {[
            { t: "Clothing", h: "/clothing", kind: "tee" as const, hex: "#F3EEE6", bg: "bg-sand" },
            { t: "Sneakers", h: "/shoes?category=sneakers", kind: "sneaker" as const, hex: "#FAFAF7", bg: "bg-sage" },
            { t: "Shoes", h: "/shoes", kind: "boot" as const, hex: "#7A5A44", bg: "bg-[#E9E2D8]" },
            { t: "Accessories", h: "/accessories", kind: "bag" as const, hex: "#E6DCD0", bg: "bg-peach/70" },
          ].map((c, i) => (
            <Reveal key={c.t} delay={i * 0.06}>
              <EditorialTile href={c.h} title={c.t} className={`aspect-[4/5] ${c.bg}`}>
                <div className={`h-full w-full ${c.bg}`}><ProductArt kind={c.kind} hex={c.hex} label={false} className="h-full w-full" /></div>
              </EditorialTile>
            </Reveal>
          ))}
        </div>
      </section>

      {newest.length > 0 && (
        <section className="container-x mt-24 sm:mt-32">
          <Reveal><SectionHead eyebrow="Just landed" title="New Arrivals" href="/new-arrivals" /></Reveal>
          <ProductRail products={newest.slice(0, 4)} />
        </section>
      )}

      {/* STEP INTO YOUR STYLE */}
      <section className="mt-24 bg-charcoal text-cream sm:mt-32" aria-labelledby="step-title">
        <div className="container-x grid items-center gap-10 py-16 lg:grid-cols-[1fr_1.4fr] lg:py-24">
          <Reveal>
            <p className="mb-4 text-[11px] uppercase tracking-[0.28em] text-cream/60">{sneakerBanner?.eyebrow ?? "Footwear"}</p>
            <h2 id="step-title" className="headline text-5xl leading-[0.95] sm:text-7xl">{sneakerBanner?.title ?? "STEP INTO YOUR STYLE"}</h2>
            <p className="mt-6 max-w-md text-cream/75">{sneakerBanner?.subtitle ?? "Clean lines, cushioned soles and colorways made to match everything you own."}</p>
            <Link href={sneakerBanner?.cta_href ?? "/shoes?category=sneakers"} className="btn-light mt-8">{sneakerBanner?.cta_label ?? "Shop Sneakers"}</Link>
          </Reveal>
          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            {sneakerBanner?.image_url ? (
              <ImageReveal className="col-span-2 aspect-[16/11]"><Image src={sneakerBanner.image_url} alt="Velvoria sneakers" fill sizes="(min-width:1024px) 55vw, 100vw" className="object-cover" /></ImageReveal>
            ) : (
              <>
                <ImageReveal className="col-span-2 aspect-[16/10] bg-[#3A3A38]"><ProductArt kind="sneaker" hex="#B2B8A7" angle="side" label={false} className="h-full w-full" /></ImageReveal>
                <ImageReveal className="aspect-square"><ProductArt kind="sneaker" hex="#F3EEE6" angle="detail" label={false} className="h-full w-full" /></ImageReveal>
                <ImageReveal className="aspect-square"><ProductArt kind="hightop" hex="#EBA98C" angle="side" label={false} className="h-full w-full" /></ImageReveal>
              </>
            )}
          </div>
        </div>
      </section>

      {spotlight.length > 0 && (
        <section className="container-x mt-24 sm:mt-32">
          <Reveal><SectionHead eyebrow="Featured releases" title="Sneaker Spotlight" href="/collections/sneaker-spotlight" /></Reveal>
          <div className="grid grid-cols-2 gap-x-3 gap-y-10 sm:gap-x-5 lg:grid-cols-4">
            {spotlight.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}

      {everydayLooks.length > 0 && (
        <section className="mt-24 bg-sand/60 py-20 sm:mt-32 sm:py-24">
          <div className="container-x">
            <Reveal><SectionHead eyebrow="Outfits" title="The Everyday Edit" href="/collections/everyday-edit" cta="Shop the edit" /></Reveal>
            <div className="grid gap-5 md:grid-cols-3">{everydayLooks.map((l, i) => <LookCard key={i} look={l} index={i} />)}</div>
          </div>
        </section>
      )}

      {bestSellers.length > 0 && (
        <section className="container-x mt-24 sm:mt-32">
          <Reveal><SectionHead eyebrow="Customer favourites" title="Best Sellers" href="/shop?best=1" /></Reveal>
          <ProductRail products={bestSellers.slice(0, 4)} />
        </section>
      )}

      {completeLooks.length > 0 && (
        <section className="container-x mt-24 sm:mt-32">
          <Reveal><SectionHead eyebrow="Head to toe" title="Complete the Look" href="/collections/complete-the-look" /></Reveal>
          <div className="grid gap-5 md:grid-cols-2">{completeLooks.map((l, i) => <LookCard key={i} look={l} index={i} />)}</div>
        </section>
      )}

      {seasonal.length > 0 && (
        <section className="container-x mt-24 sm:mt-32">
          <Reveal><SectionHead eyebrow="Seasonal" title="Seasonal Collections" href="/collections" /></Reveal>
          <div className="grid gap-3 sm:gap-5 md:grid-cols-2">
            {seasonal.map((b, i) => (
              <Reveal key={b.id} delay={i * 0.08}>
                <EditorialTile href={b.cta_href ?? "/collections"} title={b.title} eyebrow={b.subtitle ?? undefined} image={b.image_url} className={`aspect-[4/5] sm:aspect-[5/4] ${i ? "bg-peach/60" : "bg-sage"}`}>
                  <div className={`h-full w-full ${i ? "bg-peach/60" : "bg-sage"}`}>
                    <ProductArt kind={i ? "slide" : "boot"} hex={i ? "#F3EEE6" : "#7A5A44"} label={false} className="mx-auto h-full" />
                  </div>
                </EditorialTile>
              </Reveal>
            ))}
          </div>
        </section>
      )}

      <RecentlyViewed products={products} />

      <section className="container-x mt-24 sm:mt-32">
        <Reveal className="flex flex-col items-center bg-sage/50 px-6 py-16 text-center sm:py-20">
          <p className="eyebrow mb-3">Newsletter</p>
          <h2 className="headline max-w-2xl text-4xl sm:text-5xl">First look at new collections & exclusive offers</h2>
          <p className="mb-8 mt-4 max-w-md text-sm text-ink-soft">Sneaker drops, seasonal edits and members-only offers — straight to your inbox. Unsubscribe anytime.</p>
          <Newsletter />
        </Reveal>
      </section>
    </>
  );
}
