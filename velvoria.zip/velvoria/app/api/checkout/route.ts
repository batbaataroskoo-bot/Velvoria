import { NextResponse } from "next/server";
import { z } from "zod";
import type Stripe from "stripe";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import { getStripe } from "@/lib/stripe";
import { evaluateDiscount } from "@/lib/pricing";
import { EXPRESS_SHIPPING, standardShipping } from "@/lib/shipping";
import { SITE_URL } from "@/lib/format";

export const runtime = "nodejs";

const Body = z.object({
  items: z.array(z.object({ variantId: z.string().uuid(), qty: z.number().int().min(1).max(10) })).min(1).max(50),
  discountCode: z.string().max(40).nullish(),
});

interface VariantRow {
  id: string; sku: string; stock: number; price_cents: number | null;
  colorway: { id: string; name: string } | null;
  size: { label: string; us: number | null; system: string } | null;
  product: { id: string; name: string; slug: string; price_cents: number; active: boolean; is_demo: boolean; gender: string } | null;
}

export async function POST(req: Request) {
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Your bag looks invalid. Please refresh and try again." }, { status: 400 });

  // Combine duplicate lines.
  const qtyById = new Map<string, number>();
  for (const i of parsed.data.items) qtyById.set(i.variantId, Math.min(10, (qtyById.get(i.variantId) ?? 0) + i.qty));

  const admin = createAdminClient();
  const { data, error } = await admin
    .from("product_variants")
    .select("id, sku, stock, price_cents, colorway:colorways(id, name), size:sizes(label, us, system), product:products(id, name, slug, price_cents, active, is_demo, gender)")
    .in("id", [...qtyById.keys()]);
  if (error) return NextResponse.json({ error: "Checkout is temporarily unavailable." }, { status: 500 });
  const rows = (data ?? []) as unknown as VariantRow[];

  // Prices ALWAYS come from the database, never from the browser.
  const lines = [];
  for (const [variantId, qty] of qtyById) {
    const v = rows.find((r) => r.id === variantId);
    if (!v || !v.product || !v.product.active) return NextResponse.json({ error: "An item in your bag is no longer available. Please remove it." }, { status: 409 });
    if (v.product.is_demo && process.env.ALLOW_DEMO_CHECKOUT !== "true") {
      return NextResponse.json({ error: `"${v.product.name}" is a sample product and can't be purchased yet.` }, { status: 409 });
    }
    if (v.stock < qty) {
      return NextResponse.json({ error: v.stock === 0 ? `${v.product.name} (${v.size?.label}) just sold out.` : `Only ${v.stock} left of ${v.product.name} (${v.size?.label}). Please lower the quantity.` }, { status: 409 });
    }
    const sizeLabel = v.size?.system === "shoe" && v.product.gender === "women" ? `W ${Number(v.size.us) + 1.5}` : v.size?.label ?? "";
    lines.push({ v, qty, unit: v.price_cents ?? v.product.price_cents, sizeLabel });
  }

  // Look up an uploaded photo for each line (optional, used in Stripe & order history).
  const { data: imgs } = await admin.from("product_images").select("product_id, colorway_id, url, sort").in("product_id", lines.map((l) => l.v.product!.id)).order("sort");
  const imageFor = (pid: string, cid?: string) =>
    (imgs ?? []).find((i) => i.product_id === pid && i.colorway_id === cid)?.url ?? (imgs ?? []).find((i) => i.product_id === pid)?.url ?? null;

  const subtotal = lines.reduce((s, l) => s + l.unit * l.qty, 0);
  let discountCents = 0;
  let discountCode: string | null = null;
  if (parsed.data.discountCode) {
    const d = await evaluateDiscount(parsed.data.discountCode, subtotal);
    if ("error" in d) return NextResponse.json({ error: d.error }, { status: 400 });
    discountCents = d.amountCents;
    discountCode = d.code;
  }
  const afterDiscount = subtotal - discountCents;
  const standard = standardShipping(afterDiscount);

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  // 1) Create a pending order.
  const { data: order, error: orderErr } = await admin.from("orders").insert({
    user_id: user?.id ?? null, email: user?.email ?? null, status: "pending",
    subtotal_cents: subtotal, discount_cents: discountCents, discount_code: discountCode,
    shipping_cents: standard, total_cents: afterDiscount + standard,
  }).select("id, order_number").single();
  if (orderErr || !order) return NextResponse.json({ error: "Could not start checkout." }, { status: 500 });

  const { error: itemsErr } = await admin.from("order_items").insert(lines.map((l) => ({
    order_id: order.id, product_id: l.v.product!.id, variant_id: l.v.id, name: l.v.product!.name,
    color: l.v.colorway?.name, size: l.sizeLabel, unit_price_cents: l.unit, quantity: l.qty,
    image_url: imageFor(l.v.product!.id, l.v.colorway?.id),
  })));
  if (itemsErr) return NextResponse.json({ error: "Could not start checkout." }, { status: 500 });

  // 2) Create the Stripe Checkout Session.
  try {
    const stripe = getStripe();
    let coupon: string | undefined;
    if (discountCents > 0) {
      const c = await stripe.coupons.create({ amount_off: discountCents, currency: "usd", duration: "once", name: discountCode ?? "Discount", max_redemptions: 1 });
      coupon = c.id;
    }
    const params: Stripe.Checkout.SessionCreateParams = {
      mode: "payment",
      line_items: lines.map((l) => {
        const img = imageFor(l.v.product!.id, l.v.colorway?.id);
        return {
          quantity: l.qty,
          price_data: {
            currency: "usd",
            unit_amount: l.unit,
            product_data: {
              name: l.v.product!.name,
              description: `${l.v.colorway?.name ?? ""} · Size ${l.sizeLabel} · SKU ${l.v.sku}`,
              ...(img?.startsWith("https://") ? { images: [img] } : {}),
              metadata: { variant_id: l.v.id },
            },
          },
        };
      }),
      ...(coupon ? { discounts: [{ coupon }] } : {}),
      shipping_address_collection: { allowed_countries: ["US"] },
      shipping_options: [
        { shipping_rate_data: { display_name: standard === 0 ? "Free standard shipping" : "Standard shipping", type: "fixed_amount", fixed_amount: { amount: standard, currency: "usd" }, delivery_estimate: { minimum: { unit: "business_day", value: 3 }, maximum: { unit: "business_day", value: 6 } } } },
        { shipping_rate_data: { display_name: "Express shipping", type: "fixed_amount", fixed_amount: { amount: EXPRESS_SHIPPING, currency: "usd" }, delivery_estimate: { minimum: { unit: "business_day", value: 1 }, maximum: { unit: "business_day", value: 2 } } } },
      ],
      phone_number_collection: { enabled: true },
      ...(process.env.STRIPE_AUTOMATIC_TAX === "true" ? { automatic_tax: { enabled: true } } : {}),
      ...(user?.email ? { customer_email: user.email } : {}),
      client_reference_id: order.id,
      metadata: { order_id: order.id, order_number: String(order.order_number) },
      payment_intent_data: { metadata: { order_id: order.id } },
      success_url: `${SITE_URL}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${SITE_URL}/bag?cancelled=1`,
      expires_at: Math.floor(Date.now() / 1000) + 60 * 60, // 1 hour
    };
    const session = await stripe.checkout.sessions.create(params, { idempotencyKey: `order-${order.id}` });
    await admin.from("orders").update({ stripe_session_id: session.id }).eq("id", order.id);
    return NextResponse.json({ url: session.url });
  } catch (e) {
    console.error("Stripe checkout error", e);
    await admin.from("orders").update({ status: "cancelled" }).eq("id", order.id);
    return NextResponse.json({ error: "Payment service is not configured yet. Please try again later." }, { status: 502 });
  }
}
