import { NextResponse } from "next/server";
import { z } from "zod";
import { evaluateDiscount } from "@/lib/pricing";

const Body = z.object({ code: z.string().max(40), subtotalCents: z.number().int().min(0).max(10_000_000) });

/** Preview only — the checkout route re-validates the code against real prices. */
export async function POST(req: Request) {
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  const result = await evaluateDiscount(parsed.data.code, parsed.data.subtotalCents);
  if ("error" in result) return NextResponse.json(result, { status: 400 });
  return NextResponse.json(result);
}
