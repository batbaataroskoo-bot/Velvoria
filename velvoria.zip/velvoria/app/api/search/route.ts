import { NextResponse } from "next/server";
import { getAllProducts } from "@/lib/catalog";
import { matchesQuery } from "@/lib/filters";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const q = new URL(req.url).searchParams.get("q")?.trim().slice(0, 80) ?? "";
  if (q.length < 2) return NextResponse.json({ results: [] });
  const results = (await getAllProducts())
    .filter((p) => matchesQuery(p, q))
    .sort((a, b) => Number(b.name.toLowerCase().includes(q.toLowerCase())) - Number(a.name.toLowerCase().includes(q.toLowerCase())) || b.popularity - a.popularity)
    .slice(0, 8)
    .map((p) => ({ slug: p.slug, name: p.name, price_cents: p.price_cents, department: p.department, hex: p.colorways[0]?.hex ?? "#E6DCD0" }));
  return NextResponse.json({ results });
}
