import { NextResponse } from "next/server";
import type Stripe from "stripe";
import { getStripe } from "@/lib/stripe";
import { createAdminClient } from "@/lib/supabase/admin";
import { EXPRESS_SHIPPING } from "@/lib/shipping";

export const runtime = "nodejs";

type ShippingDetails = { name?: string | null; address?: Stripe.Address | null } | null | undefined;

async function completeFromSession(session: Stripe.Checkout.Session) {
  const orderId = session.metadata?.order_id;
  if (!orderId || session.payment_status !== "paid") return;
  // Newer API versions put shipping under collected_information; older ones under shipping_details.
  const s = session as unknown as { collected_information?: { shipping_details?: ShippingDetails }; shipping_details?: ShippingDetails };
  const ship = s.collected_information?.shipping_details ?? s.shipping_details ?? null;
  const shippingCents = session.shipping_cost?.amount_total ?? 0;
  const { error } = await createAdminClient().rpc("complete_order", {
    p_order_id: orderId,
    p_payment_intent: typeof session.payment_intent === "string" ? session.payment_intent : session.payment_intent?.id ?? null,
    p_email: session.customer_details?.email ?? null,
    p_address: ship ? { name: ship.name, phone: session.customer_details?.phone ?? null, ...ship.address } : null,
    p_shipping_cents: shippingCents,
    p_tax_cents: session.total_details?.amount_tax ?? 0,
    p_total_cents: session.amount_total ?? 0,
    p_shipping_method: shippingCents === EXPRESS_SHIPPING ? "Express" : "Standard",
  });
  if (error) throw new Error(error.message);
}

export async function POST(req: Request) {
  const signature = req.headers.get("stripe-signature");
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!signature || !secret) return NextResponse.json({ error: "Missing signature" }, { status: 400 });

  let event: Stripe.Event;
  try {
    event = getStripe().webhooks.constructEvent(await req.text(), signature, secret);
  } catch (e) {
    console.error("Webhook signature failed", (e as Error).message);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  const admin = createAdminClient();
  try {
    switch (event.type) {
      case "checkout.session.completed":
      case "checkout.session.async_payment_succeeded":
        await completeFromSession(event.data.object);
        break;
      case "checkout.session.expired":
      case "checkout.session.async_payment_failed": {
        const id = event.data.object.metadata?.order_id;
        if (id) await admin.from("orders").update({ status: "cancelled" }).eq("id", id).eq("status", "pending");
        break;
      }
      case "charge.refunded": {
        const charge = event.data.object;
        const pi = typeof charge.payment_intent === "string" ? charge.payment_intent : charge.payment_intent?.id;
        if (pi && charge.refunded) await admin.from("orders").update({ status: "refunded" }).eq("stripe_payment_intent", pi);
        break;
      }
    }
  } catch (e) {
    console.error("Webhook handler error", e);
    return NextResponse.json({ error: "Handler failed" }, { status: 500 }); // Stripe will retry
  }
  return NextResponse.json({ received: true });
}
