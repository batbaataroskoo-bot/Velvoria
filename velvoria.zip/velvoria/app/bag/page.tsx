import type { Metadata } from "next";
import { BagContents } from "@/components/Bag";

export const metadata: Metadata = { title: "Your Bag", robots: { index: false } };

export default async function Page({ searchParams }: { searchParams: Promise<{ cancelled?: string }> }) {
  const { cancelled } = await searchParams;
  return (
    <div className="container-x max-w-2xl pt-10 sm:pt-14">
      <h1 className="headline mb-6 text-4xl sm:text-5xl">Your Bag</h1>
      {cancelled && <p className="mb-4 bg-sand px-4 py-3 text-sm">Checkout was cancelled — your bag has been saved.</p>}
      <div className="flex min-h-[50vh] flex-col border border-charcoal/10 bg-white/40"><BagContents /></div>
    </div>
  );
}
