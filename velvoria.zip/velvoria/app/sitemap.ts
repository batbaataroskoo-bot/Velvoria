import type { MetadataRoute } from "next";
import { getAllProducts, getCategories, getCollections } from "@/lib/catalog";
import { SITE_URL } from "@/lib/format";

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [products, categories, collections] = await Promise.all([getAllProducts(), getCategories(), getCollections()]);
  const fixed = ["", "/shop", "/clothing", "/shoes", "/accessories", "/women", "/men", "/new-arrivals", "/sale", "/collections",
    "/about", "/faq", "/shipping", "/returns", "/contact", "/privacy", "/terms", "/size-guide/clothing", "/size-guide/shoes"];
  return [
    ...fixed.map((p) => ({ url: `${SITE_URL}${p}`, changeFrequency: "weekly" as const, priority: p === "" ? 1 : 0.7 })),
    ...categories.map((c) => ({ url: `${SITE_URL}/shop/${c.slug}`, changeFrequency: "weekly" as const, priority: 0.6 })),
    ...collections.map((c) => ({ url: `${SITE_URL}/collections/${c.slug}`, changeFrequency: "weekly" as const, priority: 0.6 })),
    ...products.map((p) => ({ url: `${SITE_URL}/products/${p.slug}`, lastModified: p.created_at, changeFrequency: "daily" as const, priority: 0.8 })),
  ];
}
