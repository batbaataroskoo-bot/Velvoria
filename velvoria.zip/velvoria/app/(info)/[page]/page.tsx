import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PAGES } from "../content";

export const dynamicParams = false;
export function generateStaticParams() { return Object.keys(PAGES).map((page) => ({ page })); }

export async function generateMetadata({ params }: { params: Promise<{ page: string }> }): Promise<Metadata> {
  const p = PAGES[(await params).page];
  return p ? { title: p.title, description: p.description, alternates: { canonical: `/${(await params).page}` } } : {};
}

export default async function Page({ params }: { params: Promise<{ page: string }> }) {
  const p = PAGES[(await params).page];
  if (!p) notFound();
  return (
    <article className="container-x max-w-3xl pt-12 sm:pt-16">
      <h1 className="headline mb-8 text-4xl sm:text-6xl">{p.title}</h1>
      <div className="prose-v">{p.body}</div>
    </article>
  );
}
