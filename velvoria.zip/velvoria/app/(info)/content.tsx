// Store policy pages. Replace [bracketed] details with your business information and
// have the Privacy Policy and Terms reviewed by a lawyer before launch.
export const PAGES: Record<string, { title: string; description: string; body: React.ReactNode }> = {
  about: {
    title: "About VELVORIA",
    description: "Modern everyday fashion and footwear, made to be worn on repeat.",
    body: (<>
      <p>VELVORIA started with a simple idea: the clothes and sneakers you reach for every day should look considered, feel comfortable and work with everything else you own.</p>
      <h2>What we make</h2>
      <p>Relaxed essentials, denim, knitwear and outerwear — plus a footwear line built around clean low-tops, retro runners, boots, sandals and slides. Every colorway is designed to sit inside one calm palette, so pieces pair easily.</p>
      <h2>How we design</h2>
      <ul><li>Fewer, better pieces with long wardrobe life.</li><li>Comfort-first fits and cushioned footwear for real days.</li><li>Clear sizing guidance and honest fit notes.</li></ul>
    </>),
  },
  faq: {
    title: "FAQ",
    description: "Answers about orders, sizing, shipping, returns and payments.",
    body: (<>
      <h2>Do I need an account to order?</h2><p>No — guest checkout is available. An account lets you track orders, save addresses and keep your wishlist across devices.</p>
      <h2>How do I find my shoe size?</h2><p>Use our <a href="/size-guide/shoes" className="link-u">shoe size guide</a> with US, EU and foot-length conversions. Each sneaker page also shows fit notes where they have been verified.</p>
      <h2>How do I find my clothing size?</h2><p>See the <a href="/size-guide/clothing" className="link-u">clothing size guide</a>. Oversized and relaxed styles are cut with extra room.</p>
      <h2>Which payment methods do you accept?</h2><p>Payments are processed securely by Stripe. Depending on your device and location, you can pay by card, Apple Pay, Google Pay or Link. We never see or store your full card details.</p>
      <h2>Can I change or cancel my order?</h2><p>Contact us as soon as possible. Once an order has shipped it can&apos;t be changed, but you can return it.</p>
      <h2>Where is my order?</h2><p>Sign in and open <a href="/account/orders" className="link-u">Order history</a>. Tracking appears once your order ships.</p>
    </>),
  },
  shipping: {
    title: "Shipping",
    description: "Shipping options, costs and delivery times.",
    body: (<>
      <ul><li><strong>Standard (3–6 business days):</strong> $7.95, free on orders of $100 or more after discounts.</li><li><strong>Express (1–2 business days):</strong> $18.00.</li></ul>
      <p>We currently ship within the United States. Orders placed before 1 pm [your time zone] on business days usually leave our warehouse the same or next business day.</p>
      <p>Final shipping costs are shown at checkout before you pay.</p>
    </>),
  },
  returns: {
    title: "Returns & Exchanges",
    description: "Free returns within 30 days.",
    body: (<>
      <p>You can return unworn, unwashed items with original tags within 30 days of delivery for a full refund to your original payment method.</p>
      <h2>Footwear</h2><p>Please try shoes on indoors on a clean, soft surface. Shoes must be returned in their original box, without outdoor wear.</p>
      <h2>How to return</h2><ul><li>Contact us with your order number via the <a href="/contact" className="link-u">contact page</a>.</li><li>We&apos;ll send a prepaid return label.</li><li>Refunds are issued within 5–10 business days of the return arriving.</li></ul>
      <p>Final-sale items are marked on the product page and cannot be returned.</p>
    </>),
  },
  privacy: {
    title: "Privacy Policy",
    description: "How VELVORIA collects and uses personal information.",
    body: (<>
      <p><em>Last updated: [date]. Template — have this reviewed by a qualified professional before launch.</em></p>
      <h2>Information we collect</h2><ul><li>Account details (name, email, phone, saved addresses).</li><li>Order details (items, shipping address, order history).</li><li>Newsletter sign-ups and messages you send us.</li><li>Basic technical data needed to run the site (e.g. sign-in cookies, bag contents stored in your browser).</li></ul>
      <h2>Payments</h2><p>Payments are handled by Stripe. Card details go directly to Stripe and are never stored on our servers.</p>
      <h2>How we use it</h2><p>To process and deliver orders, provide customer support, send emails you opted into, prevent fraud and improve the store. We do not sell personal information.</p>
      <h2>Service providers</h2><p>We use Supabase (database & authentication), Stripe (payments) and our hosting provider to operate the store.</p>
      <h2>Your choices</h2><p>You can update your details in your account, unsubscribe from emails at any time, or contact [privacy email] to request access to or deletion of your data.</p>
    </>),
  },
  terms: {
    title: "Terms of Service",
    description: "Terms that apply when you use the VELVORIA store.",
    body: (<>
      <p><em>Last updated: [date]. Template — have this reviewed by a qualified professional before launch.</em></p>
      <h2>Orders</h2><p>All orders are subject to acceptance and availability. Prices are in USD and may change without notice. If a pricing error occurs we may cancel the order and refund you in full.</p>
      <h2>Payment</h2><p>Payment is taken at checkout by our processor, Stripe.</p>
      <h2>Shipping & returns</h2><p>See our <a href="/shipping" className="link-u">Shipping</a> and <a href="/returns" className="link-u">Returns</a> pages.</p>
      <h2>Accounts</h2><p>You are responsible for keeping your password secure and for activity on your account.</p>
      <h2>Content</h2><p>All site content, product designs, photography and the VELVORIA name belong to [legal business name].</p>
      <h2>Contact</h2><p>[Legal business name], [address], [email].</p>
    </>),
  },
};
