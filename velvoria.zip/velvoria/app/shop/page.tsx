import type { Metadata } from "next";
import { Catalog } from "@/components/Catalog";
import type { SP } from "@/lib/filters";

export const metadata: Metadata = { title: "Shop All", description: "Shop all VELVORIA clothing, shoes, sneakers and accessories.", alternates: { canonical: "/shop" } };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  return <Catalog title="Shop All" eyebrow="Velvoria" searchParams={await searchParams} basePath="/shop" />;
}
