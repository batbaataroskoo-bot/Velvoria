import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Catalog } from "@/components/Catalog";
import { getCategories } from "@/lib/catalog";
import type { SP } from "@/lib/filters";

type Props = { params: Promise<{ category: string }>; searchParams: Promise<SP> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { category } = await params;
  const c = (await getCategories()).find((x) => x.slug === category);
  if (!c) return {};
  return { title: c.name, description: c.description ?? `Shop ${c.name} at VELVORIA.`, alternates: { canonical: `/shop/${c.slug}` } };
}

export default async function Page({ params, searchParams }: Props) {
  const { category } = await params;
  const c = (await getCategories()).find((x) => x.slug === category);
  if (!c) notFound();
  const back = c.department === "footwear" ? "/shoes" : c.department === "clothing" ? "/clothing" : "/accessories";
  return (
    <Catalog title={c.name} eyebrow={c.department === "footwear" ? "Shoes & Sneakers" : c.department === "clothing" ? "Clothing" : "Accessories"}
      intro={c.description ?? undefined} preset={{ department: c.department, category: [c.slug] }}
      searchParams={await searchParams} basePath={`/shop/${c.slug}`} quickLinks={[["← Back to all", back]]} />
  );
}
