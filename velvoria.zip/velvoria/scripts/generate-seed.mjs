// Generates supabase/seed.sql with the VELVORIA demonstration catalog.
// Run: node scripts/generate-seed.mjs
import { writeFileSync } from "node:fs";

const q = (s) => (s == null ? "null" : `'${String(s).replace(/'/g, "''")}'`);

const categories = [
  ["t-shirts-tops", "T-Shirts & Tops", "clothing"],
  ["hoodies-sweatshirts", "Hoodies & Sweatshirts", "clothing"],
  ["jeans-denim", "Jeans & Denim", "clothing"],
  ["pants-trousers", "Pants & Trousers", "clothing"],
  ["jackets-outerwear", "Jackets & Outerwear", "clothing"],
  ["dresses-skirts", "Dresses & Skirts", "clothing"],
  ["knitwear", "Knitwear", "clothing"],
  ["shorts", "Shorts", "clothing"],
  ["activewear", "Activewear", "clothing"],
  ["everyday-essentials", "Everyday Essentials", "clothing"],
  ["lifestyle-sneakers", "Lifestyle Sneakers", "footwear"],
  ["everyday-sneakers", "Everyday Sneakers", "footwear"],
  ["retro-sneakers", "Retro Sneakers", "footwear"],
  ["running-inspired-sneakers", "Running-Inspired Sneakers", "footwear"],
  ["high-top-sneakers", "High-Top Sneakers", "footwear"],
  ["low-top-sneakers", "Low-Top Sneakers", "footwear"],
  ["casual-shoes", "Casual Shoes", "footwear"],
  ["boots", "Boots", "footwear"],
  ["sandals", "Sandals", "footwear"],
  ["slides", "Slides", "footwear"],
  ["bags", "Bags", "accessories"],
  ["hats", "Hats & Beanies", "accessories"],
  ["socks", "Socks", "accessories"],
];

const collections = [
  ["everyday-edit", "The Everyday Edit", "Complete everyday outfits built from easy essentials.", false],
  ["sneaker-spotlight", "Sneaker Spotlight", "Featured sneaker releases and the styles everyone is wearing.", false],
  ["complete-the-look", "Complete the Look", "Clothing and footwear chosen to be worn together.", false],
  ["summer-light", "Summer Light", "Breathable layers, slides and sandals for warm days.", true],
  ["autumn-layers", "Autumn Layers", "Knits, outerwear and boots for cooler weather.", true],
];

// shoe sizes: US men's → EU
const shoeSizes = [
  [5, 37.5], [5.5, 38], [6, 38.5], [6.5, 39], [7, 40], [7.5, 40.5], [8, 41], [8.5, 42],
  [9, 42.5], [9.5, 43], [10, 44], [10.5, 44.5], [11, 45], [11.5, 45.5], [12, 46], [13, 47.5],
];
const clothingSizes = ["XS", "S", "M", "L", "XL", "XXL"];

const C = {
  cream: ["Cream", "#F3EEE6"], white: ["Optic White", "#FAFAF7"], black: ["Black", "#252525"],
  sand: ["Sand", "#E6DCD0"], sage: ["Sage", "#B2B8A7"], peach: ["Peach", "#EBA98C"],
  navy: ["Navy", "#2E3647"], grey: ["Heather Grey", "#B9B7B2"], olive: ["Olive", "#6F7259"],
  indigo: ["Indigo Wash", "#3F4E6B"], light: ["Light Wash", "#9DB0C8"], brown: ["Chestnut", "#7A5A44"],
  stone: ["Stone", "#CFC6B8"], rust: ["Rust", "#B4673F"],
};

// [slug, name, dept, category, gender, style, price, compare, sizes, colors, flags, collections, desc, materials, fit]
const P = [
  // ---- Clothing ----
  ["oversized-essential-t-shirt", "Oversized Essential T-Shirt", "clothing", "t-shirts-tops", "unisex", "Oversized", 2900, null, "clothing", ["white", "black", "sand", "sage"], ["trending", "bestseller"], ["everyday-edit", "complete-the-look"],
    "A heavyweight cotton tee with a dropped shoulder and a relaxed, boxy body. The foundation of every everyday outfit.", "100% organic cotton jersey, 240 gsm", "Relaxed oversized fit — size down for a closer fit (sample guidance)"],
  ["relaxed-fit-hoodie", "Relaxed Fit Hoodie", "clothing", "hoodies-sweatshirts", "unisex", "Relaxed", 6900, null, "clothing", ["grey", "sage", "black"], ["trending", "bestseller"], ["everyday-edit", "autumn-layers"],
    "Brushed-back fleece hoodie with a double-layer hood, kangaroo pocket and ribbed cuffs.", "80% cotton, 20% recycled polyester fleece", null],
  ["straight-leg-denim", "Straight-Leg Denim", "clothing", "jeans-denim", "women", "Straight", 7900, null, "clothing", ["indigo", "light", "black"], ["bestseller"], ["everyday-edit", "complete-the-look"],
    "High-rise straight-leg jeans in rigid denim that softens with every wear.", "100% cotton denim, 12 oz", null],
  ["everyday-cargo-pants", "Everyday Cargo Pants", "clothing", "pants-trousers", "men", "Utility", 6900, null, "clothing", ["olive", "stone", "black"], ["new", "trending"], ["complete-the-look"],
    "Relaxed cargo pants with low-profile pockets and an adjustable drawcord hem.", "98% cotton twill, 2% elastane", null],
  ["lightweight-bomber-jacket", "Lightweight Bomber Jacket", "clothing", "jackets-outerwear", "men", "Bomber", 11900, 14900, "clothing", ["olive", "black", "sand"], ["new"], ["autumn-layers"],
    "A water-repellent bomber with a clean zip front, ribbed trims and a light padded lining.", "Shell: 100% recycled nylon. Lining: 100% polyester", null],
  ["everyday-knit-sweater", "Everyday Knit Sweater", "clothing", "knitwear", "women", "Crew", 7400, null, "clothing", ["cream", "sage", "peach"], ["new"], ["autumn-layers", "everyday-edit"],
    "A soft crew-neck knit with a slightly cropped body and dropped shoulders.", "60% cotton, 40% recycled wool", null],
  ["classic-sweatshirt", "Classic Sweatshirt", "clothing", "hoodies-sweatshirts", "unisex", "Crew", 5900, null, "clothing", ["grey", "navy", "cream"], ["bestseller"], ["everyday-edit"],
    "The crewneck sweatshirt, done properly: loopback cotton, raglan sleeves and a V-insert at the neck.", "100% cotton loopback terry", null],
  ["relaxed-fit-shorts", "Relaxed Fit Shorts", "clothing", "shorts", "men", "Relaxed", 3900, 4900, "clothing", ["sand", "black", "sage"], [], ["summer-light"],
    "Easy pull-on shorts with an elastic waist, side pockets and a 7\" inseam.", "100% cotton twill", null],
  ["casual-summer-dress", "Casual Summer Dress", "clothing", "dresses-skirts", "women", "Midi", 6900, null, "clothing", ["peach", "cream", "sage"], ["new", "trending"], ["summer-light", "complete-the-look"],
    "A breezy midi dress with adjustable straps, a smocked back and side pockets.", "100% linen-look viscose", null],
  ["wide-leg-trousers", "Wide-Leg Trousers", "clothing", "pants-trousers", "women", "Wide-Leg", 7900, null, "clothing", ["sand", "black", "stone"], [], ["everyday-edit"],
    "Fluid high-waisted trousers with front pleats and a wide, floor-grazing leg.", "68% recycled polyester, 30% viscose, 2% elastane", null],
  ["everyday-tank-top", "Everyday Tank Top", "clothing", "t-shirts-tops", "women", "Fitted", 1900, null, "clothing", ["white", "black", "sage", "peach"], ["bestseller"], ["summer-light"],
    "A ribbed tank with a scoop neck and a close, comfortable fit.", "95% organic cotton, 5% elastane rib", null],
  ["minimalist-denim-jacket", "Minimalist Denim Jacket", "clothing", "jackets-outerwear", "unisex", "Trucker", 9900, null, "clothing", ["indigo", "light"], ["trending"], ["complete-the-look", "autumn-layers"],
    "A clean, pocket-light trucker jacket in mid-weight denim with tonal buttons.", "100% cotton denim", null],
  // ---- Footwear ----
  ["velvoria-everyday-low-sneakers", "Velvoria Everyday Low Sneakers", "footwear", "everyday-sneakers", "unisex", "Minimal", 8900, null, "shoe", ["white", "black", "sand"], ["bestseller", "featured"], ["sneaker-spotlight", "everyday-edit", "complete-the-look"],
    "Our everyday low-top: a smooth leather upper, padded collar and a cushioned cupsole built for all-day wear.", "Upper: leather. Lining: recycled polyester. Outsole: rubber cupsole", "True to size (sample data)"],
  ["velvoria-retro-runner", "Velvoria Retro Runner", "footwear", "retro-sneakers", "unisex", "Retro", 10900, null, "shoe", ["cream", "sage", "navy"], ["new", "trending", "featured"], ["sneaker-spotlight"],
    "Seventies running lines, rebuilt with suede overlays, a breathable mesh base and a lightweight EVA wedge.", "Upper: suede and mesh. Midsole: EVA. Outsole: rubber", "Runs slightly small — consider half a size up (sample data)"],
  ["velvoria-classic-high-tops", "Velvoria Classic High-Tops", "footwear", "high-top-sneakers", "unisex", "High-Top", 9900, null, "shoe", ["white", "black"], ["trending"], ["sneaker-spotlight", "complete-the-look"],
    "A heritage high-top with a canvas upper, rubber toe cap and vulcanized sole.", "Upper: cotton canvas. Outsole: vulcanized rubber", null],
  ["velvoria-urban-low-tops", "Velvoria Urban Low-Tops", "footwear", "low-top-sneakers", "men", "Court", 9500, 11500, "shoe", ["black", "grey", "white"], [], ["sneaker-spotlight"],
    "A tonal low-top with a sleek nubuck upper and a slim rubber sole for city days.", "Upper: nubuck. Outsole: rubber", null],
  ["velvoria-canvas-sneakers", "Velvoria Canvas Sneakers", "footwear", "lifestyle-sneakers", "unisex", "Canvas", 5900, null, "shoe", ["cream", "black", "sage", "peach"], ["bestseller"], ["summer-light", "everyday-edit"],
    "A lightweight canvas sneaker with a cushioned insole and a classic striped foxing tape.", "Upper: organic cotton canvas. Outsole: natural rubber", "True to size (sample data)"],
  ["velvoria-everyday-trainers", "Velvoria Everyday Trainers", "footwear", "running-inspired-sneakers", "women", "Running", 11900, null, "shoe", ["grey", "peach", "white"], ["new"], ["sneaker-spotlight"],
    "A running-inspired trainer with a knit upper, responsive foam midsole and grippy rubber outsole.", "Upper: engineered knit. Midsole: foam. Outsole: rubber", null],
  ["velvoria-minimal-court-sneakers", "Velvoria Minimal Court Sneakers", "footwear", "low-top-sneakers", "women", "Court", 9900, null, "shoe", ["white", "sand"], ["trending", "bestseller"], ["complete-the-look", "everyday-edit"],
    "A pared-back court sneaker with tonal stitching, a slim profile and a stitched cupsole.", "Upper: leather. Outsole: rubber cupsole", null],
  ["velvoria-street-runner", "Velvoria Street Runner", "footwear", "running-inspired-sneakers", "men", "Running", 12900, null, "shoe", ["black", "stone", "sage"], ["new", "featured"], ["sneaker-spotlight"],
    "A chunky running-inspired silhouette with layered mesh and suede and a sculpted, cushioned sole.", "Upper: mesh and suede. Midsole: dual-density foam. Outsole: rubber", null],
  ["velvoria-casual-slip-ons", "Velvoria Casual Slip-Ons", "footwear", "casual-shoes", "unisex", "Slip-On", 6900, null, "shoe", ["black", "sand", "navy"], [], ["summer-light"],
    "Laceless canvas slip-ons with elastic side gores and a padded collar.", "Upper: cotton canvas. Outsole: vulcanized rubber", null],
  ["velvoria-essential-boots", "Velvoria Essential Boots", "footwear", "boots", "unisex", "Chelsea", 15900, null, "shoe", ["black", "brown"], ["new"], ["autumn-layers"],
    "A water-resistant suede Chelsea boot with elastic side panels and a lug sole.", "Upper: water-resistant suede. Outsole: lug rubber", null],
  ["velvoria-summer-slides", "Velvoria Summer Slides", "footwear", "slides", "unisex", "Slide", 3500, null, "shoe", ["sand", "black", "sage", "peach"], ["trending"], ["summer-light"],
    "A one-piece cushioned slide with a contoured footbed. Pool, beach, coffee run.", "Molded EVA foam", null],
  ["velvoria-everyday-sandals", "Velvoria Everyday Sandals", "footwear", "sandals", "women", "Strappy", 5900, 6900, "shoe", ["brown", "black", "sand"], [], ["summer-light"],
    "Two-strap sandals with adjustable buckles and a cork-blend footbed.", "Straps: vegan leather. Footbed: cork blend. Outsole: rubber", null],
  // ---- Accessories ----
  ["everyday-canvas-tote", "Everyday Canvas Tote", "accessories", "bags", "unisex", "Tote", 3900, null, "one", ["cream", "black"], ["new"], ["everyday-edit"],
    "A heavy canvas tote with an inside zip pocket and long shoulder straps.", "16 oz cotton canvas", null],
  ["ribbed-beanie", "Ribbed Beanie", "accessories", "hats", "unisex", "Beanie", 2500, null, "one", ["sand", "black", "sage", "rust"], [], ["autumn-layers"],
    "A soft ribbed beanie with a deep turn-up cuff.", "50% merino wool, 50% acrylic", null],
  ["everyday-crew-socks-3-pack", "Everyday Crew Socks (3-Pack)", "accessories", "socks", "unisex", "Crew", 1800, null, "one", ["white", "black", "grey"], ["bestseller"], ["everyday-edit"],
    "Cushioned cotton crew socks with arch support — the right partner for every sneaker.", "78% cotton, 20% polyamide, 2% elastane", null],
];

let sql = `-- VELVORIA demonstration catalog (generated by scripts/generate-seed.mjs)
-- All products below are marked is_demo = true. Replace them from the admin dashboard.
begin;

`;

sql += "insert into public.sizes (system, label, us, eu, sort) values\n" + [
  ...clothingSizes.map((s, i) => `('clothing', ${q(s)}, null, null, ${i})`),
  ...shoeSizes.map(([us, eu], i) => `('shoe', ${q("US " + us)}, ${us}, ${eu}, ${i})`),
  `('one', 'One Size', null, null, 0)`,
].join(",\n") + "\non conflict (system, label) do nothing;\n\n";

sql += "insert into public.categories (slug, name, department, sort) values\n" +
  categories.map(([s, n, d], i) => `(${q(s)}, ${q(n)}, ${q(d)}, ${i})`).join(",\n") +
  "\non conflict (slug) do nothing;\n\n";

sql += "insert into public.collections (slug, name, description, is_seasonal, sort) values\n" +
  collections.map(([s, n, d, seas], i) => `(${q(s)}, ${q(n)}, ${q(d)}, ${seas}, ${i})`).join(",\n") +
  "\non conflict (slug) do nothing;\n\n";

P.forEach((p, idx) => {
  const [slug, name, dept, cat, gender, style, price, compare, system, colors, flags, cols, desc, materials, fit] = p;
  const daysAgo = idx * 3 % 60;
  sql += `-- ${name}
insert into public.products (slug, name, description, department, category_id, gender, style, size_system, price_cents, compare_at_cents, materials, construction, fit_note, is_new, is_trending, is_bestseller, is_featured, is_demo, popularity, created_at)
values (${q(slug)}, ${q(name)}, ${q(desc)}, ${q(dept)}, (select id from public.categories where slug = ${q(cat)}), ${q(gender)}, ${q(style)}, ${q(system)}, ${price}, ${compare ?? "null"}, ${q(materials)}, ${q(dept === "footwear" ? "Cemented construction with a removable cushioned insole." : null)}, ${q(fit)}, ${flags.includes("new")}, ${flags.includes("trending")}, ${flags.includes("bestseller")}, ${flags.includes("featured")}, true, ${(P.length - idx) * 7 + (flags.includes("bestseller") ? 120 : 0)}, now() - interval '${daysAgo} days')
on conflict (slug) do nothing;
insert into public.colorways (product_id, name, hex, sort)
select p.id, v.name, v.hex, v.sort from public.products p,
  (values ${colors.map((c, i) => `(${q(C[c][0])}, ${q(C[c][1])}, ${i})`).join(", ")}) as v(name, hex, sort)
where p.slug = ${q(slug)} and not exists (select 1 from public.colorways c where c.product_id = p.id);
insert into public.product_collections (product_id, collection_id)
select p.id, c.id from public.products p, public.collections c
where p.slug = ${q(slug)} and c.slug in (${cols.map(q).join(", ")}) on conflict do nothing;

`;
});

// Variants: every colorway × every size of the product's size system, with demo stock.
sql += `-- Variants (every colorway × size) with demonstration stock levels
insert into public.product_variants (product_id, colorway_id, size_id, sku, stock)
select p.id, c.id, s.id,
  'VEL-' || upper(substr(md5(p.slug || c.name || s.label), 1, 10)),
  case when abs(hashtext(p.slug || c.name || s.label)) % 9 = 0 then 0
       else 2 + abs(hashtext(s.label || p.slug || c.name)) % 24 end
from public.products p
join public.colorways c on c.product_id = p.id
join public.sizes s on s.system = p.size_system
  and (p.size_system <> 'shoe' or (p.gender <> 'women' or s.us <= 11)) -- women's styles stop at US M 11
  and (p.size_system <> 'shoe' or (p.gender <> 'men' or s.us >= 6))
on conflict (colorway_id, size_id) do nothing;

insert into public.discount_codes (code, kind, value, min_subtotal_cents) values
('WELCOME10', 'percent', 10, 0),
('STEP20', 'fixed', 2000, 15000)
on conflict (code) do nothing;

insert into public.banners (placement, eyebrow, title, subtitle, cta_label, cta_href, sort)
select * from (values
('hero', 'Autumn / Winter Campaign', 'MADE FOR EVERYDAY.', 'Discover effortless fashion, fresh sneakers, and everyday essentials designed for your lifestyle.', 'SHOP CLOTHING', '/clothing', 0),
('sneakers', 'Footwear', 'STEP INTO YOUR STYLE', 'Clean lines, cushioned soles and colorways made to match everything you own.', 'Shop Sneakers', '/shoes?category=sneakers', 0),
('seasonal', 'Seasonal', 'Autumn Layers', 'Knits, outerwear and boots for cooler days.', 'Shop the Collection', '/collections/autumn-layers', 0),
('seasonal', 'Seasonal', 'Summer Light', 'Breathable layers, slides and sandals.', 'Shop the Collection', '/collections/summer-light', 1)
) as v(placement, eyebrow, title, subtitle, cta_label, cta_href, sort)
where not exists (select 1 from public.banners);

insert into public.reviews (product_id, author_name, rating, title, body, fit, approved)
select p.id, v.author, v.rating, v.title, v.body, v.fit, true from public.products p,
 (values
   ('velvoria-everyday-low-sneakers', 'Sample reviewer A', 5, 'Goes with everything', 'Demonstration review: comfortable from day one and easy to style.', 'true'),
   ('velvoria-everyday-low-sneakers', 'Sample reviewer B', 4, 'Clean and comfy', 'Demonstration review: great cushioning, the leather creases a little.', 'true'),
   ('velvoria-retro-runner', 'Sample reviewer C', 5, 'Love the colorway', 'Demonstration review: the sage colorway is even better in person.', 'small'),
   ('oversized-essential-t-shirt', 'Sample reviewer D', 5, 'Perfect weight', 'Demonstration review: thick cotton that keeps its shape.', 'large')
 ) as v(slug, author, rating, title, body, fit)
where p.slug = v.slug and not exists (select 1 from public.reviews r where r.product_id = p.id and r.author_name = v.author);

commit;
`;

writeFileSync(new URL("../supabase/seed.sql", import.meta.url), sql);
console.log(`Wrote seed.sql with ${P.length} products`);
