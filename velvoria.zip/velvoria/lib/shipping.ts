/** Shipping rules — used by the bag (estimate) and by the server (final). */
export const FREE_SHIPPING_THRESHOLD = 10000; // $100 after discounts
export const STANDARD_SHIPPING = 795;
export const EXPRESS_SHIPPING = 1800;

export function standardShipping(subtotalAfterDiscount: number) {
  return subtotalAfterDiscount >= FREE_SHIPPING_THRESHOLD || subtotalAfterDiscount === 0 ? 0 : STANDARD_SHIPPING;
}
