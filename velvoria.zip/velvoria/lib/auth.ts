import "server-only";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export async function getUser() {
  const supabase = await createClient();
  const { data } = await supabase.auth.getUser();
  return data.user;
}

export async function requireUser(next = "/account") {
  const user = await getUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(next)}`);
  return user;
}

/** Server-side admin check. Every admin page and admin action calls this. */
export async function isAdmin(userId: string) {
  const admin = createAdminClient();
  const { data } = await admin.from("profiles").select("is_admin").eq("id", userId).single();
  return Boolean(data?.is_admin);
}

export async function requireAdmin() {
  const user = await requireUser("/admin");
  if (!(await isAdmin(user.id))) redirect("/");
  return user;
}
