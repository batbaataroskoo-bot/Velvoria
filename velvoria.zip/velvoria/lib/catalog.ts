import { createPublicClient } from "@/lib/supabase/public";
import type { Banner, Category, Collection, ProductFull, Review, Variant } from "@/lib/types";

const PRODUCT_SELECT =
  "*, category:categories(*), colorways(*), variants:product_variants(*, size:sizes(*)), images:product_images(*), product_collections(collection:collections(slug))";

type RawProduct = Omit<ProductFull, "collections"> & { product_collections: { collection: { slug: string } | null }[] };

function normalize(p: RawProduct): ProductFull {
  const { product_collections, ...rest } = p;
  return {
    ...rest,
    colorways: [...(rest.colorways ?? [])].sort((a, b) => a.sort - b.sort),
    variants: [...(rest.variants ?? [])].sort((a, b) => a.size.sort - b.size.sort),
    images: [...(rest.images ?? [])].sort((a, b) => a.sort - b.sort),
    collections: (product_collections ?? []).map((pc) => pc.collection?.slug).filter(Boolean) as string[],
  };
}

export async function getAllProducts(): Promise<ProductFull[]> {
  const supabase = createPublicClient();
  const { data, error } = await supabase.from("products").select(PRODUCT_SELECT).eq("active", true);
  if (error) {
    console.error("getAllProducts", error.message);
    return [];
  }
  return (data as unknown as RawProduct[]).map(normalize);
}

export async function getProduct(slug: string): Promise<ProductFull | null> {
  const supabase = createPublicClient();
  const { data } = await supabase.from("products").select(PRODUCT_SELECT).eq("slug", slug).eq("active", true).maybeSingle();
  return data ? normalize(data as unknown as RawProduct) : null;
}

export async function getCategories(): Promise<Category[]> {
  const { data } = await createPublicClient().from("categories").select("*").order("sort");
  return (data ?? []) as Category[];
}

export async function getCollections(): Promise<Collection[]> {
  const { data } = await createPublicClient().from("collections").select("*").eq("active", true).order("sort");
  return (data ?? []) as Collection[];
}

export async function getBanners(): Promise<Banner[]> {
  const { data } = await createPublicClient().from("banners").select("*").eq("active", true).order("sort");
  return (data ?? []) as Banner[];
}

export async function getReviews(productId: string): Promise<Review[]> {
  const { data } = await createPublicClient()
    .from("reviews").select("*").eq("product_id", productId).eq("approved", true).order("created_at", { ascending: false });
  return (data ?? []) as Review[];
}

// ---------- helpers ----------
export const totalStock = (p: ProductFull) => p.variants.reduce((s, v) => s + v.stock, 0);
export const isOnSale = (p: ProductFull) => p.compare_at_cents != null && p.compare_at_cents > p.price_cents;
export const variantPrice = (p: ProductFull, v: Variant) => v.price_cents ?? p.price_cents;
export const isSneaker = (p: ProductFull) => p.department === "footwear" && (p.category?.slug ?? "").includes("sneakers");

export function availability(p: ProductFull): { label: string; tone: "ok" | "low" | "out" } {
  const stock = totalStock(p);
  if (stock === 0) return { label: "Sold out", tone: "out" };
  const sizesInStock = new Set(p.variants.filter((v) => v.stock > 0).map((v) => v.size_id)).size;
  const allSizes = new Set(p.variants.map((v) => v.size_id)).size;
  if (stock < 15 || sizesInStock < allSizes / 2) return { label: "Limited sizes", tone: "low" };
  return { label: "In stock", tone: "ok" };
}

export function badge(p: ProductFull): string | null {
  if (isOnSale(p)) return "Sale";
  if (p.is_new) return "New Arrival";
  if (p.is_trending) return "Trending";
  if (p.is_bestseller) return "Best Seller";
  return null;
}
