import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";

export interface DiscountResult { code: string; amountCents: number; message: string }

/** Validates a discount code against the database and returns the amount off. */
export async function evaluateDiscount(rawCode: string, subtotalCents: number): Promise<DiscountResult | { error: string }> {
  const code = rawCode.trim().toUpperCase().slice(0, 40);
  if (!code) return { error: "Enter a code." };
  const { data: d } = await createAdminClient().from("discount_codes").select("*").eq("code", code).maybeSingle();
  const now = Date.now();
  if (!d || !d.active) return { error: "This code isn't valid." };
  if (d.starts_at && new Date(d.starts_at).getTime() > now) return { error: "This code isn't active yet." };
  if (d.ends_at && new Date(d.ends_at).getTime() < now) return { error: "This code has expired." };
  if (d.max_uses != null && d.uses >= d.max_uses) return { error: "This code has reached its limit." };
  if (subtotalCents < d.min_subtotal_cents) return { error: `Spend $${(d.min_subtotal_cents / 100).toFixed(0)} or more to use this code.` };
  const amount = d.kind === "percent" ? Math.round((subtotalCents * Math.min(d.value, 100)) / 100) : Math.min(d.value, subtotalCents);
  return {
    code,
    amountCents: amount,
    message: d.kind === "percent" ? `${d.value}% off applied` : `$${(d.value / 100).toFixed(2)} off applied`,
  };
}
