import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";

// Not a server action: only callable from server code that has already checked admin rights.
const ALLOWED = new Map([["image/jpeg", "jpg"], ["image/png", "png"], ["image/webp", "webp"], ["image/avif", "avif"]]);
const MAX_BYTES = 5 * 1024 * 1024;

async function looksLikeImage(file: File) {
  const b = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  const jpg = b[0] === 0xff && b[1] === 0xd8;
  const png = b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47;
  const webp = String.fromCharCode(...b.slice(0, 4)) === "RIFF" && String.fromCharCode(...b.slice(8, 12)) === "WEBP";
  const avif = String.fromCharCode(...b.slice(4, 12)).startsWith("ftypavi");
  return jpg || png || webp || avif;
}

export async function uploadImageFile(file: File, folder: string) {
  if (!(file instanceof File) || file.size === 0) throw new Error("Choose an image file.");
  const ext = ALLOWED.get(file.type);
  if (!ext) throw new Error("Images must be JPG, PNG, WebP or AVIF.");
  if (file.size > MAX_BYTES) throw new Error("Images must be 5 MB or smaller.");
  if (!(await looksLikeImage(file))) throw new Error("That file doesn't look like a real image.");
  const path = `${folder}/${crypto.randomUUID()}.${ext}`; // random name: never trust the uploaded filename
  const db = createAdminClient();
  const { error } = await db.storage.from("product-images").upload(path, file, { contentType: file.type, cacheControl: "31536000", upsert: false });
  if (error) throw new Error(error.message);
  return db.storage.from("product-images").getPublicUrl(path).data.publicUrl;
}

