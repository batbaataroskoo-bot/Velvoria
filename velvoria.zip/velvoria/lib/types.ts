export type Department = "clothing" | "footwear" | "accessories";
export type Gender = "women" | "men" | "unisex";
export type SizeSystem = "clothing" | "shoe" | "one";
export type Angle = "front" | "side" | "top" | "back" | "outsole" | "detail" | "lifestyle";

export interface Category { id: string; slug: string; name: string; department: Department; description: string | null; sort: number }
export interface Collection { id: string; slug: string; name: string; description: string | null; image_url: string | null; is_seasonal: boolean; active: boolean; sort: number }
export interface Colorway { id: string; product_id: string; name: string; hex: string; sort: number }
export interface Size { id: string; system: SizeSystem; label: string; us: number | null; eu: number | null; sort: number }
export interface ProductImage { id: string; product_id: string; colorway_id: string | null; url: string; alt: string | null; angle: Angle; sort: number }
export interface Variant { id: string; product_id: string; colorway_id: string; size_id: string; sku: string; price_cents: number | null; stock: number; size: Size }

export interface Product {
  id: string; slug: string; name: string; description: string; department: Department;
  category_id: string | null; gender: Gender; brand: string; style: string | null; size_system: SizeSystem;
  price_cents: number; compare_at_cents: number | null; materials: string | null; construction: string | null;
  fit_note: string | null; is_new: boolean; is_trending: boolean; is_bestseller: boolean; is_featured: boolean;
  is_demo: boolean; active: boolean; popularity: number; created_at: string;
}

export interface ProductFull extends Product {
  category: Category | null;
  colorways: Colorway[];
  variants: Variant[];
  images: ProductImage[];
  collections: string[];
}

export interface Banner { id: string; placement: "hero" | "sneakers" | "seasonal"; eyebrow: string | null; title: string; subtitle: string | null; image_url: string | null; cta_label: string | null; cta_href: string | null; active: boolean; sort: number }

export interface Review { id: string; product_id: string; author_name: string; rating: number; title: string | null; body: string; fit: "small" | "true" | "large" | null; created_at: string }

/** What the bag stores in the browser. Prices here are for display only — the server recalculates. */
export interface CartItem {
  variantId: string; productId: string; slug: string; name: string;
  color: string; hex: string; size: string; priceCents: number; image: string | null;
  qty: number; department: Department; categorySlug: string | null; maxStock: number;
}

export interface WishItem { productId: string; slug: string; name: string; priceCents: number; hex: string; image: string | null; department: Department; categorySlug: string | null }
