import "server-only";
import { createClient } from "@supabase/supabase-js";

/**
 * Service-role client: bypasses Row Level Security.
 * Only use on the server AFTER checking the caller is allowed (see lib/auth.ts).
 */
export function createAdminClient() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) throw new Error("SUPABASE_SERVICE_ROLE_KEY is not set");
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, key, { auth: { persistSession: false } });
}
