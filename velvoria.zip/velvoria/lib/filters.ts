import type { Department, ProductFull } from "@/lib/types";
import { isOnSale, totalStock } from "@/lib/catalog";

export type SP = Record<string, string | string[] | undefined>;

export interface Filters {
  department?: Department;
  category: string[];
  gender: string[];
  brand: string[];
  size: string[]; // clothing size labels
  us: string[];
  eu: string[];
  color: string[];
  style: string[];
  min?: number;
  max?: number;
  inStock: boolean;
  isNew: boolean;
  best: boolean;
  sale: boolean;
  collection?: string;
  q?: string;
  sort: "featured" | "newest" | "price-asc" | "price-desc" | "popular";
}

const list = (v: string | string[] | undefined) =>
  (Array.isArray(v) ? v.join(",") : v ?? "").split(",").map((s) => s.trim()).filter(Boolean);
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) || undefined;

export function parseFilters(sp: SP, preset: Partial<Filters> = {}): Filters {
  const dept = one(sp.department);
  const sort = one(sp.sort);
  return {
    department: preset.department ?? (dept === "clothing" || dept === "footwear" || dept === "accessories" ? dept : undefined),
    category: preset.category ?? list(sp.category),
    gender: preset.gender ?? list(sp.gender),
    brand: list(sp.brand),
    size: list(sp.size),
    us: list(sp.us),
    eu: list(sp.eu),
    color: list(sp.color),
    style: list(sp.style),
    min: one(sp.min) ? Number(one(sp.min)) : undefined,
    max: one(sp.max) ? Number(one(sp.max)) : undefined,
    inStock: one(sp.avail) === "in",
    isNew: preset.isNew ?? one(sp.new) === "1",
    best: one(sp.best) === "1",
    sale: preset.sale ?? one(sp.sale) === "1",
    collection: preset.collection ?? one(sp.collection),
    q: one(sp.q)?.slice(0, 80),
    sort: (["newest", "price-asc", "price-desc", "popular"].includes(sort ?? "") ? sort : "featured") as Filters["sort"],
  };
}

function matchesCategory(p: ProductFull, cats: string[]) {
  const slug = p.category?.slug ?? "";
  return cats.some((c) => (c === "sneakers" ? slug.endsWith("sneakers") : c === "shoes" ? p.department === "footwear" : slug === c));
}

export function matchesQuery(p: ProductFull, q: string) {
  const hay = [p.name, p.description, p.style, p.category?.name, p.department, p.gender, ...p.colorways.map((c) => c.name)]
    .join(" ").toLowerCase();
  return q.toLowerCase().split(/\s+/).filter(Boolean).every((w) => hay.includes(w));
}

/** Products that match the "scope" (department, gender preset, collection) — used for building facet lists. */
export function scope(products: ProductFull[], f: Filters) {
  return products.filter((p) =>
    (!f.department || p.department === f.department) &&
    (!f.collection || p.collections.includes(f.collection)) &&
    (!f.isNew || p.is_new) &&
    (!f.sale || isOnSale(p)),
  );
}

export function applyFilters(products: ProductFull[], f: Filters) {
  const inStockVariant = (p: ProductFull, test: (v: ProductFull["variants"][number]) => boolean) =>
    p.variants.some((v) => test(v) && (!f.inStock || v.stock > 0));

  const out = scope(products, f).filter((p) => {
    if (f.category.length && !matchesCategory(p, f.category)) return false;
    if (f.gender.length && !f.gender.includes(p.gender) && !(p.gender === "unisex" && f.gender.some((g) => g !== "unisex"))) return false;
    if (f.brand.length && !f.brand.includes(p.brand)) return false;
    if (f.style.length && !f.style.includes(p.style ?? "")) return false;
    if (f.color.length && !p.colorways.some((c) => f.color.includes(c.name))) return false;
    if (f.min != null && p.price_cents < f.min * 100) return false;
    if (f.max != null && p.price_cents > f.max * 100) return false;
    if (f.inStock && totalStock(p) === 0) return false;
    if (f.best && !p.is_bestseller) return false;
    if (f.size.length && !inStockVariant(p, (v) => f.size.includes(v.size.label))) return false;
    if (f.us.length && !inStockVariant(p, (v) => v.size.us != null && f.us.includes(String(v.size.us)))) return false;
    if (f.eu.length && !inStockVariant(p, (v) => v.size.eu != null && f.eu.includes(String(v.size.eu)))) return false;
    if (f.q && !matchesQuery(p, f.q)) return false;
    return true;
  });

  const by = {
    featured: (a: ProductFull, b: ProductFull) =>
      Number(b.is_featured) - Number(a.is_featured) || Number(b.is_trending) - Number(a.is_trending) || b.popularity - a.popularity,
    newest: (a: ProductFull, b: ProductFull) => +new Date(b.created_at) - +new Date(a.created_at),
    "price-asc": (a: ProductFull, b: ProductFull) => a.price_cents - b.price_cents,
    "price-desc": (a: ProductFull, b: ProductFull) => b.price_cents - a.price_cents,
    popular: (a: ProductFull, b: ProductFull) => b.popularity - a.popularity,
  }[f.sort];
  return out.sort(by);
}

export function facets(products: ProductFull[]) {
  const uniq = <T,>(a: T[]) => [...new Set(a)];
  const sizes = products.flatMap((p) => p.variants.map((v) => v.size));
  const sizeMap = new Map(sizes.map((s) => [s.id, s]));
  const sorted = [...sizeMap.values()].sort((a, b) => a.sort - b.sort);
  const cats = new Map(products.filter((p) => p.category).map((p) => [p.category!.slug, p.category!]));
  return {
    categories: [...cats.values()].sort((a, b) => a.sort - b.sort),
    genders: uniq(products.map((p) => p.gender)),
    brands: uniq(products.map((p) => p.brand)),
    styles: uniq(products.map((p) => p.style).filter(Boolean) as string[]).sort(),
    colors: uniq(products.flatMap((p) => p.colorways.map((c) => `${c.name}|${c.hex}`))).map((s) => {
      const [name, hex] = s.split("|");
      return { name, hex };
    }),
    clothingSizes: sorted.filter((s) => s.system === "clothing").map((s) => s.label),
    us: sorted.filter((s) => s.system === "shoe").map((s) => String(s.us)),
    eu: sorted.filter((s) => s.system === "shoe").map((s) => String(s.eu)),
    priceMax: Math.ceil(Math.max(0, ...products.map((p) => p.price_cents)) / 100),
  };
}
