-- =====================================================================
-- VELVORIA — Supabase PostgreSQL schema
-- Run this whole file once in Supabase → SQL Editor, then run seed.sql.
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- Customers ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  phone text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  label text default 'Home',
  full_name text not null,
  line1 text not null,
  line2 text,
  city text not null,
  state text not null,
  postal_code text not null,
  country text not null default 'US',
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- Catalog ----------
create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  department text not null check (department in ('clothing','footwear','accessories')),
  description text,
  sort int not null default 0
);

create table if not exists public.collections (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text,
  image_url text,
  is_seasonal boolean not null default false,
  active boolean not null default true,
  sort int not null default 0
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text not null default '',
  department text not null check (department in ('clothing','footwear','accessories')),
  category_id uuid references public.categories(id) on delete set null,
  gender text not null default 'unisex' check (gender in ('women','men','unisex')),
  brand text not null default 'Velvoria',
  style text,
  size_system text not null check (size_system in ('clothing','shoe','one')),
  price_cents int not null check (price_cents >= 0),
  compare_at_cents int check (compare_at_cents is null or compare_at_cents >= 0),
  materials text,
  construction text,
  fit_note text,               -- only fill when fit has been verified
  is_new boolean not null default false,
  is_trending boolean not null default false,
  is_bestseller boolean not null default false,
  is_featured boolean not null default false,
  is_demo boolean not null default true,  -- demonstration product (not real stock)
  active boolean not null default true,
  popularity int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists products_department_idx on public.products(department);
create index if not exists products_category_idx on public.products(category_id);

create table if not exists public.product_collections (
  product_id uuid references public.products(id) on delete cascade,
  collection_id uuid references public.collections(id) on delete cascade,
  primary key (product_id, collection_id)
);

create table if not exists public.colorways (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  name text not null,
  hex text not null default '#E6DCD0',
  sort int not null default 0
);

-- Clothing sizes and shoe sizes live in one table, separated by "system".
create table if not exists public.sizes (
  id uuid primary key default gen_random_uuid(),
  system text not null check (system in ('clothing','shoe','one')),
  label text not null,
  us numeric,          -- shoe: US men's size
  eu numeric,          -- shoe: EU size
  sort int not null default 0,
  unique (system, label)
);

create table if not exists public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  colorway_id uuid references public.colorways(id) on delete set null,
  url text not null,
  alt text,
  angle text not null default 'front'
    check (angle in ('front','side','top','back','outsole','detail','lifestyle')),
  sort int not null default 0
);

-- Each variant = one colorway + one size, with its own stock (inventory).
create table if not exists public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  colorway_id uuid not null references public.colorways(id) on delete cascade,
  size_id uuid not null references public.sizes(id),
  sku text unique not null,
  price_cents int check (price_cents is null or price_cents >= 0), -- optional override
  stock int not null default 0 check (stock >= 0),
  unique (colorway_id, size_id)
);
create index if not exists variants_product_idx on public.product_variants(product_id);

create table if not exists public.inventory_log (
  id bigserial primary key,
  variant_id uuid references public.product_variants(id) on delete set null,
  change int not null,
  reason text not null,
  order_id uuid,
  created_at timestamptz not null default now()
);

-- ---------- Shopping ----------
create table if not exists public.carts (
  user_id uuid primary key references auth.users(id) on delete cascade,
  items jsonb not null default '[]',
  updated_at timestamptz not null default now()
);

create table if not exists public.wishlists (
  user_id uuid references auth.users(id) on delete cascade,
  product_id uuid references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

create table if not exists public.discount_codes (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  kind text not null check (kind in ('percent','fixed')),
  value int not null check (value > 0),          -- percent (1-100) or cents
  min_subtotal_cents int not null default 0,
  max_uses int,
  uses int not null default 0,
  starts_at timestamptz,
  ends_at timestamptz,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create sequence if not exists public.order_number_seq start 10001;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number bigint not null default nextval('public.order_number_seq') unique,
  user_id uuid references auth.users(id) on delete set null,
  email text,
  status text not null default 'pending'
    check (status in ('pending','paid','processing','shipped','delivered','cancelled','refunded')),
  subtotal_cents int not null,
  discount_cents int not null default 0,
  shipping_cents int not null default 0,
  tax_cents int not null default 0,
  total_cents int not null default 0,
  discount_code text,
  shipping_method text,
  shipping_address jsonb,
  stripe_session_id text unique,
  stripe_payment_intent text,
  tracking_number text,
  tracking_url text,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);
create index if not exists orders_user_idx on public.orders(user_id);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  variant_id uuid references public.product_variants(id) on delete set null,
  name text not null,
  color text,
  size text,
  unit_price_cents int not null,
  quantity int not null check (quantity > 0),
  image_url text
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  author_name text not null,
  rating int not null check (rating between 1 and 5),
  title text,
  body text not null,
  fit text check (fit in ('small','true','large')),
  approved boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- Content ----------
create table if not exists public.banners (
  id uuid primary key default gen_random_uuid(),
  placement text not null default 'hero' check (placement in ('hero','sneakers','seasonal')),
  eyebrow text,
  title text not null,
  subtitle text,
  image_url text,
  cta_label text,
  cta_href text,
  active boolean not null default true,
  sort int not null default 0
);

create table if not exists public.newsletter_subscribers (
  email text primary key,
  created_at timestamptz not null default now()
);

create table if not exists public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  message text not null,
  created_at timestamptz not null default now()
);

-- =====================================================================
-- Functions & triggers
-- =====================================================================

-- Create a profile row whenever someone signs up.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', ''))
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false);
$$;

-- Marks an order paid exactly once, reduces stock and counts discount use.
-- Called only by the Stripe webhook using the service-role key.
create or replace function public.complete_order(
  p_order_id uuid, p_payment_intent text, p_email text, p_address jsonb,
  p_shipping_cents int, p_tax_cents int, p_total_cents int, p_shipping_method text
) returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_updated int;
  r record;
begin
  update public.orders
     set status = 'paid', paid_at = now(), stripe_payment_intent = p_payment_intent,
         email = coalesce(p_email, email), shipping_address = coalesce(p_address, shipping_address),
         shipping_cents = p_shipping_cents, tax_cents = p_tax_cents, total_cents = p_total_cents,
         shipping_method = coalesce(p_shipping_method, shipping_method)
   where id = p_order_id and status = 'pending';
  get diagnostics v_updated = row_count;
  if v_updated = 0 then
    return false; -- already processed (webhooks can arrive more than once)
  end if;

  for r in select variant_id, quantity from public.order_items where order_id = p_order_id loop
    if r.variant_id is not null then
      update public.product_variants set stock = greatest(stock - r.quantity, 0) where id = r.variant_id;
      insert into public.inventory_log (variant_id, change, reason, order_id)
      values (r.variant_id, -r.quantity, 'sale', p_order_id);
    end if;
  end loop;

  update public.discount_codes d set uses = uses + 1
    from public.orders o where o.id = p_order_id and o.discount_code is not null and d.code = o.discount_code;

  update public.products p set popularity = popularity + oi.quantity
    from public.order_items oi where oi.order_id = p_order_id and oi.product_id = p.id;

  return true;
end $$;

revoke all on function public.complete_order(uuid, text, text, jsonb, int, int, int, text) from public, anon, authenticated;
grant execute on function public.complete_order(uuid, text, text, jsonb, int, int, int, text) to service_role;

-- =====================================================================
-- Row Level Security (who may read / write which rows)
-- =====================================================================
alter table public.profiles enable row level security;
alter table public.addresses enable row level security;
alter table public.categories enable row level security;
alter table public.collections enable row level security;
alter table public.products enable row level security;
alter table public.product_collections enable row level security;
alter table public.colorways enable row level security;
alter table public.sizes enable row level security;
alter table public.product_images enable row level security;
alter table public.product_variants enable row level security;
alter table public.inventory_log enable row level security;
alter table public.carts enable row level security;
alter table public.wishlists enable row level security;
alter table public.discount_codes enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.reviews enable row level security;
alter table public.banners enable row level security;
alter table public.newsletter_subscribers enable row level security;
alter table public.contact_messages enable row level security;

-- Public catalog: anyone can read active items. Writes happen only through
-- the server with the service-role key after an admin check.
create policy "read categories" on public.categories for select using (true);
create policy "read collections" on public.collections for select using (active or public.is_admin());
create policy "read products" on public.products for select using (active or public.is_admin());
create policy "read product_collections" on public.product_collections for select using (true);
create policy "read colorways" on public.colorways for select using (true);
create policy "read sizes" on public.sizes for select using (true);
create policy "read images" on public.product_images for select using (true);
create policy "read variants" on public.product_variants for select using (true);
create policy "read banners" on public.banners for select using (active or public.is_admin());
create policy "read approved reviews" on public.reviews for select using (approved or user_id = auth.uid() or public.is_admin());
create policy "write own review" on public.reviews for insert to authenticated
  with check (user_id = auth.uid() and approved = false);

-- Profiles: users see and edit their own name/phone only (not is_admin).
create policy "own profile read" on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy "own profile update" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
revoke update on public.profiles from authenticated, anon;
grant update (full_name, phone) on public.profiles to authenticated;

create policy "own addresses" on public.addresses for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own cart" on public.carts for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own wishlist" on public.wishlists for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Orders: customers can only read their own; creation happens on the server.
create policy "own orders" on public.orders for select using (user_id = auth.uid() or public.is_admin());
create policy "own order items" on public.order_items for select using (
  exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin()))
);
-- discount_codes, inventory_log, newsletter_subscribers, contact_messages:
-- no public policies → only the server (service role) can touch them.

-- =====================================================================
-- Storage bucket for product photos (public read; uploads via server only)
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 5242880,
        array['image/jpeg','image/png','image/webp','image/avif'])
on conflict (id) do update set public = true, file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/avif'];
