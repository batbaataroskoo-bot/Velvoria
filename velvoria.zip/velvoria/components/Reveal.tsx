"use client";

import { motion, useReducedMotion } from "motion/react";

/** Fades & lifts content in as it scrolls into view. Respects reduced-motion settings. */
export function Reveal({ children, delay = 0, className, y = 24 }: { children: React.ReactNode; delay?: number; className?: string; y?: number }) {
  const reduce = useReducedMotion();
  if (reduce) return <div className={className}>{children}</div>;
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

/** Editorial image reveal: a sand-colored panel wipes away to uncover the image. */
export function ImageReveal({ children, className }: { children: React.ReactNode; className?: string }) {
  const reduce = useReducedMotion();
  return (
    <div className={`relative overflow-hidden ${className ?? ""}`}>
      <motion.div
        initial={reduce ? false : { scale: 1.08 }} whileInView={{ scale: 1 }} viewport={{ once: true }}
        transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }} className="h-full w-full"
      >
        {children}
      </motion.div>
      {!reduce && (
        <motion.div aria-hidden className="absolute inset-0 origin-top bg-sand"
          initial={{ scaleY: 1 }} whileInView={{ scaleY: 0 }} viewport={{ once: true }}
          transition={{ duration: 1.1, ease: [0.76, 0, 0.24, 1] }} />
      )}
    </div>
  );
}
