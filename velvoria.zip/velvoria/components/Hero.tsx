"use client";

import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "motion/react";
import type { Banner } from "@/lib/types";
import { ProductArt } from "@/components/ProductArt";

export function Hero({ banner }: { banner?: Banner }) {
  const reduce = useReducedMotion();
  const rise = (d: number) => (reduce ? {} : { initial: { opacity: 0, y: 28 }, animate: { opacity: 1, y: 0 }, transition: { duration: 1, delay: d, ease: [0.22, 1, 0.36, 1] as const } });
  const title = banner?.title ?? "MADE FOR EVERYDAY.";
  const subtitle = banner?.subtitle ?? "Discover effortless fashion, fresh sneakers, and everyday essentials designed for your lifestyle.";

  return (
    <section className="relative min-h-[720px] overflow-hidden bg-sand sm:h-[calc(100svh-100px)] sm:min-h-[560px] sm:max-h-[920px]" aria-label="Campaign">
      <motion.div className="absolute inset-0" initial={reduce ? false : { scale: 1.06 }} animate={{ scale: 1 }} transition={{ duration: 2.2, ease: [0.22, 1, 0.36, 1] }}>
        {banner?.image_url ? (
          <Image src={banner.image_url} alt="VELVORIA campaign" fill priority sizes="100vw" className="object-cover" />
        ) : (
          // Campaign image placeholder — upload campaign photography in Admin → Banners.
          <div className="absolute inset-0 grid grid-cols-12">
            <div className="col-span-12 bg-[#DCD2C4] md:col-span-7" />
            <div className="hidden bg-sage md:col-span-5 md:block" />
            <div className="absolute right-[4%] top-[8%] hidden w-[34%] max-w-[460px] md:block"><ProductArt kind="hoodie" hex="#F3EEE6" angle="front" label={false} /></div>
            <div className="absolute right-[4%] top-[2%] w-[58%] max-w-[560px] md:bottom-[6%] md:right-[22%] md:top-auto md:w-[30%]"><ProductArt kind="sneaker" hex="#FAFAF7" angle="side" label={false} /></div>
            <p className="absolute bottom-3 right-4 text-[10px] uppercase tracking-[0.2em] text-charcoal/50">Campaign image placeholder</p>
          </div>
        )}
      </motion.div>
      <div className={`absolute inset-0 ${banner?.image_url ? "bg-gradient-to-r from-charcoal/55 via-charcoal/20 to-transparent" : ""}`} />
      <div className="container-x relative flex h-full min-h-[720px] flex-col justify-end pb-10 sm:min-h-0 sm:pb-20 lg:justify-center lg:pb-0">
        <div className={`max-w-2xl ${banner?.image_url ? "text-cream" : "text-charcoal"}`}>
          {banner?.eyebrow && <motion.p {...rise(0.1)} className="mb-4 text-[11px] font-medium uppercase tracking-[0.28em] opacity-80">{banner.eyebrow}</motion.p>}
          <motion.h1 {...rise(0.2)} className="headline text-[52px] leading-[0.95] sm:text-[84px] lg:text-[112px]">{title}</motion.h1>
          <motion.p {...rise(0.35)} className="mt-6 max-w-md text-[15px] leading-7 opacity-90 sm:text-base">{subtitle}</motion.p>
          <motion.div {...rise(0.5)} className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <Link href="/clothing" className={banner?.image_url ? "btn-light" : "btn-dark"}>Shop Clothing</Link>
            <Link href="/shoes" className={banner?.image_url ? "btn-light" : "btn-dark"}>Shop Shoes & Sneakers</Link>
            <Link href="/new-arrivals" className={banner?.image_url ? "btn-outline-light" : "btn-outline"}>Explore New Arrivals</Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
