import Link from "next/link";
import { Logo } from "@/components/Header";
import { Newsletter } from "@/components/Newsletter";

const COLS: [string, [string, string][]][] = [
  ["Shop", [["New Arrivals", "/new-arrivals"], ["Women", "/women"], ["Men", "/men"], ["Clothing", "/clothing"], ["Shoes & Sneakers", "/shoes"], ["Accessories", "/accessories"], ["Sale", "/sale"]]],
  ["Help", [["FAQ", "/faq"], ["Shipping", "/shipping"], ["Returns", "/returns"], ["Clothing Size Guide", "/size-guide/clothing"], ["Shoe Size Guide", "/size-guide/shoes"], ["Contact", "/contact"]]],
  ["Velvoria", [["About", "/about"], ["Collections", "/collections"], ["Account", "/account"], ["Order History", "/account/orders"], ["Privacy Policy", "/privacy"], ["Terms", "/terms"]]],
];

export function Footer() {
  return (
    <footer className="mt-24 bg-charcoal text-cream">
      <div className="container-x grid gap-12 py-16 lg:grid-cols-[1.3fr_2fr]">
        <div className="space-y-5">
          <Logo className="text-cream" />
          <p className="headline max-w-sm text-3xl">Effortless Style. Every Day.</p>
          <p className="max-w-sm text-sm text-cream/70">Join for early access to new collections, sneaker releases and members-only offers.</p>
          <Newsletter dark />
        </div>
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
          {COLS.map(([title, links]) => (
            <div key={title}>
              <p className="mb-4 text-[11px] uppercase tracking-[0.2em] text-cream/60">{title}</p>
              <ul className="space-y-2.5">
                {links.map(([l, h]) => <li key={h}><Link href={h} className="text-sm text-cream/90 hover:text-cream hover:underline underline-offset-4">{l}</Link></li>)}
              </ul>
            </div>
          ))}
        </div>
      </div>
      <div className="border-t border-cream/10">
        <div className="container-x flex flex-col gap-2 py-6 text-xs text-cream/60 sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} VELVORIA. All rights reserved.</p>
          <p>Secure payments by Stripe · Prices in USD</p>
        </div>
      </div>
    </footer>
  );
}
