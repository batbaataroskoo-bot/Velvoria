"use client";

import type { ProductFull } from "@/lib/types";
import { useStore } from "@/components/StoreProvider";
import { ProductRail, SectionHead } from "@/components/Sections";

export function RecentlyViewed({ products, excludeId }: { products: ProductFull[]; excludeId?: string }) {
  const { recent, ready } = useStore();
  if (!ready) return null;
  const list = recent.filter((id) => id !== excludeId).map((id) => products.find((p) => p.id === id)).filter(Boolean).slice(0, 4) as ProductFull[];
  if (!list.length) return null;
  return (
    <section className="container-x mt-24">
      <SectionHead title="Recently Viewed" />
      <ProductRail products={list} />
    </section>
  );
}
