import Image from "next/image";
import type { Angle, ProductFull } from "@/lib/types";
import { ProductArt, kindFor } from "@/components/ProductArt";

export function anglesFor(p: ProductFull): Angle[] {
  const uploaded = [...new Set(p.images.map((i) => i.angle))];
  if (uploaded.length >= 2) return uploaded;
  if (p.department === "footwear") return ["side", "top", "back", "outsole", "detail", "lifestyle"];
  if (p.department === "accessories") return ["front", "detail", "lifestyle"];
  return ["front", "back", "detail", "lifestyle"];
}

export function photoFor(p: ProductFull, colorwayId: string | undefined, angle: Angle) {
  return (
    p.images.find((i) => i.angle === angle && i.colorway_id === colorwayId) ??
    p.images.find((i) => i.angle === angle && !i.colorway_id) ??
    null
  );
}

export function firstPhotoUrl(p: ProductFull, colorwayId?: string) {
  return (p.images.find((i) => i.colorway_id === colorwayId) ?? p.images[0])?.url ?? null;
}

/** 4:5 product image: real photo if uploaded, otherwise a labelled placeholder. */
export function ProductMedia({
  product, colorwayId, angle, sizes = "(min-width:1024px) 25vw, 50vw", priority, className = "",
}: { product: ProductFull; colorwayId?: string; angle: Angle; sizes?: string; priority?: boolean; className?: string }) {
  const photo = photoFor(product, colorwayId, angle);
  const color = product.colorways.find((c) => c.id === colorwayId) ?? product.colorways[0];
  return (
    <div className={`relative aspect-[4/5] w-full overflow-hidden bg-mist ${className}`}>
      {photo ? (
        <Image src={photo.url} alt={photo.alt || `${product.name} — ${color?.name ?? ""} (${angle})`} fill sizes={sizes} priority={priority} className="object-cover" />
      ) : (
        <ProductArt kind={kindFor(product.category?.slug, product.name)} hex={color?.hex ?? "#E6DCD0"} angle={angle} className="h-full w-full" />
      )}
    </div>
  );
}
