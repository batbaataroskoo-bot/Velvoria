import Link from "next/link";
import { getAllProducts } from "@/lib/catalog";
import { applyFilters, facets, parseFilters, scope, type Filters, type SP } from "@/lib/filters";
import { ProductGrid } from "@/components/ProductCard";
import { FilterPanel } from "@/components/FilterPanel";
import { RecentlyViewed } from "@/components/RecentlyViewed";

export async function Catalog({
  title, eyebrow, intro, preset = {}, searchParams, basePath, quickLinks,
}: {
  title: string; eyebrow?: string; intro?: string; preset?: Partial<Filters>; searchParams: SP; basePath: string;
  quickLinks?: [string, string][];
}) {
  const all = await getAllProducts();
  const f = parseFilters(searchParams, preset);
  const results = applyFilters(all, f);
  const fac = facets(scope(all, f));
  const mode = f.department === "footwear" ? "footwear" : f.department === "clothing" ? "clothing" : f.department === "accessories" ? "accessories" : "all";

  return (
    <div className="container-x pb-8 pt-10 sm:pt-14">
      <nav aria-label="Breadcrumb" className="mb-4 text-xs text-ink-soft"><Link href="/" className="hover:underline">Home</Link> / <span>{title}</span></nav>
      <header className="mb-8 max-w-3xl">
        {eyebrow && <p className="eyebrow mb-2">{eyebrow}</p>}
        <h1 className="headline text-4xl sm:text-6xl">{title}</h1>
        {intro && <p className="mt-4 text-[15px] leading-7 text-ink-soft">{intro}</p>}
      </header>
      {quickLinks && (
        <div className="no-scrollbar -mx-4 mb-8 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:flex-wrap sm:px-0">
          {quickLinks.map(([l, h]) => <Link key={h} href={h} className="shrink-0 border border-charcoal/20 px-4 py-2 text-xs uppercase tracking-[0.12em] hover:border-charcoal">{l}</Link>)}
        </div>
      )}
      <div className="lg:grid lg:grid-cols-[240px_1fr] lg:gap-10">
        <FilterPanel facets={fac} filters={f} mode={mode} basePath={basePath} count={results.length} preset={Object.keys(preset)} />
        <div>
          {results.length ? <ProductGrid products={results} cols={3} /> : (
            <div className="border border-dashed border-charcoal/20 px-6 py-20 text-center">
              <p className="headline text-2xl">No products match these filters</p>
              <p className="mt-2 text-sm text-ink-soft">Try removing a filter or two.</p>
              <Link href={basePath} className="btn-outline mt-6">Clear all filters</Link>
            </div>
          )}
        </div>
      </div>
      <RecentlyViewed products={all} />
    </div>
  );
}
