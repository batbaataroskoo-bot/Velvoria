"use client";

import Link from "next/link";
import Image from "next/image";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { useEffect, useState } from "react";
import { useStore } from "@/components/StoreProvider";
import { ProductArt, kindFor } from "@/components/ProductArt";
import { CloseIcon } from "@/components/Icons";
import { money } from "@/lib/format";
import { FREE_SHIPPING_THRESHOLD, standardShipping } from "@/lib/shipping";

interface Discount { code: string; amountCents: number; message: string }

function useDiscount(subtotal: number) {
  const [code, setCode] = useState("");
  const [discount, setDiscount] = useState<Discount | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function apply(c = code) {
    if (!c.trim()) return;
    setBusy(true); setError(null);
    try {
      const res = await fetch("/api/discount", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ code: c, subtotalCents: subtotal }) });
      const data = await res.json();
      if (!res.ok) { setDiscount(null); setError(data.error ?? "Code not valid"); sessionStorage.removeItem("vel_code"); }
      else { setDiscount(data); sessionStorage.setItem("vel_code", data.code); }
    } finally { setBusy(false); }
  }
  // Re-check the saved code whenever the subtotal changes.
  useEffect(() => {
    const saved = sessionStorage.getItem("vel_code");
    if (saved && subtotal > 0) { setCode(saved); apply(saved); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subtotal]);
  const remove = () => { setDiscount(null); setCode(""); sessionStorage.removeItem("vel_code"); };
  return { code, setCode, discount, error, busy, apply, remove };
}

export function BagContents({ onNavigate }: { onNavigate?: () => void }) {
  const { cart, setQty, removeItem, subtotal } = useStore();
  const d = useDiscount(subtotal);
  const [checkingOut, setCheckingOut] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const discountCents = d.discount?.amountCents ?? 0;
  const afterDiscount = Math.max(0, subtotal - discountCents);
  const shipping = standardShipping(afterDiscount);
  const toFree = FREE_SHIPPING_THRESHOLD - afterDiscount;

  async function checkout() {
    setCheckingOut(true); setError(null);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ items: cart.map((i) => ({ variantId: i.variantId, qty: i.qty })), discountCode: d.discount?.code ?? null }),
      });
      const data = await res.json();
      if (!res.ok || !data.url) throw new Error(data.error ?? "Checkout is unavailable right now.");
      window.location.href = data.url;
    } catch (e) {
      setError((e as Error).message);
      setCheckingOut(false);
    }
  }

  if (cart.length === 0) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-5 px-6 py-16 text-center">
        <p className="headline text-3xl">Your bag is empty</p>
        <p className="text-sm text-ink-soft">Fresh sneakers and everyday essentials are waiting.</p>
        <div className="flex w-full max-w-xs flex-col gap-3">
          <Link href="/clothing" onClick={onNavigate} className="btn-dark">Shop Clothing</Link>
          <Link href="/shoes" onClick={onNavigate} className="btn-outline">Shop Shoes & Sneakers</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="border-b border-charcoal/10 px-5 py-3 text-xs">
        {toFree > 0 ? <>You&apos;re <strong>{money(toFree)}</strong> away from free standard shipping.</> : <>You&apos;ve unlocked <strong>free standard shipping</strong>.</>}
        <div className="mt-2 h-1 bg-sand"><div className="h-1 bg-charcoal transition-all" style={{ width: `${Math.min(100, (afterDiscount / FREE_SHIPPING_THRESHOLD) * 100)}%` }} /></div>
      </div>
      <ul className="flex-1 divide-y divide-charcoal/10 overflow-y-auto px-5">
        {cart.map((i) => (
          <li key={i.variantId} className="flex gap-4 py-5">
            <Link href={`/products/${i.slug}`} onClick={onNavigate} className="relative block aspect-[4/5] w-20 shrink-0 overflow-hidden bg-mist">
              {i.image ? <Image src={i.image} alt={i.name} fill sizes="80px" className="object-cover" />
                : <ProductArt kind={kindFor(i.categorySlug, i.name)} hex={i.hex} angle={i.department === "footwear" ? "side" : "front"} label={false} className="h-full w-full" />}
            </Link>
            <div className="flex flex-1 flex-col">
              <div className="flex justify-between gap-2">
                <Link href={`/products/${i.slug}`} onClick={onNavigate} className="text-sm font-medium">{i.name}</Link>
                <p className="text-sm">{money(i.priceCents * i.qty)}</p>
              </div>
              <p className="mt-1 text-xs text-ink-soft">{i.department === "footwear" ? "Colorway" : "Color"}: {i.color}</p>
              <p className="text-xs text-ink-soft">{i.department === "footwear" ? "Shoe size" : "Size"}: {i.size}</p>
              <div className="mt-auto flex items-center justify-between pt-3">
                <div className="flex items-center border border-charcoal/20" role="group" aria-label={`Quantity for ${i.name}`}>
                  <button className="h-8 w-8" onClick={() => setQty(i.variantId, i.qty - 1)} aria-label="Decrease quantity" disabled={i.qty <= 1}>−</button>
                  <span className="w-8 text-center text-sm" aria-live="polite">{i.qty}</span>
                  <button className="h-8 w-8" onClick={() => setQty(i.variantId, i.qty + 1)} aria-label="Increase quantity" disabled={i.qty >= Math.min(10, i.maxStock)}>+</button>
                </div>
                <button onClick={() => removeItem(i.variantId)} className="text-xs underline underline-offset-4">Remove</button>
              </div>
            </div>
          </li>
        ))}
      </ul>

      <div className="space-y-3 border-t border-charcoal/10 bg-cream px-5 py-5">
        {d.discount ? (
          <div className="flex items-center justify-between bg-sage/40 px-3 py-2 text-xs">
            <span><strong>{d.discount.code}</strong> — {d.discount.message}</span>
            <button onClick={d.remove} className="underline">Remove</button>
          </div>
        ) : (
          <form onSubmit={(e) => { e.preventDefault(); d.apply(); }} className="flex gap-2">
            <label htmlFor="discount" className="sr-only">Discount code</label>
            <input id="discount" value={d.code} onChange={(e) => d.setCode(e.target.value.toUpperCase())} placeholder="Discount code" className="input h-10" />
            <button className="btn-outline h-10 px-4" disabled={d.busy}>Apply</button>
          </form>
        )}
        {d.error && <p role="alert" className="text-xs text-red-700">{d.error}</p>}
        <dl className="space-y-1.5 text-sm">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{money(subtotal)}</dd></div>
          {discountCents > 0 && <div className="flex justify-between text-[#4d5a43]"><dt>Discount</dt><dd>−{money(discountCents)}</dd></div>}
          <div className="flex justify-between"><dt>Standard shipping</dt><dd>{shipping === 0 ? "Free" : money(shipping)}</dd></div>
          <div className="flex justify-between border-t border-charcoal/10 pt-2 font-medium"><dt>Estimated total</dt><dd>{money(afterDiscount + shipping)}</dd></div>
        </dl>
        <p className="text-[11px] text-ink-soft">Taxes and express shipping options are shown at checkout. Final totals are calculated securely on our server.</p>
        {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
        <button className="btn-dark w-full" onClick={checkout} disabled={checkingOut}>{checkingOut ? "Opening secure checkout…" : "Checkout securely"}</button>
        <p className="text-center text-[11px] text-ink-soft">Guest checkout available · Payments processed by Stripe</p>
      </div>
    </div>
  );
}

export function CartDrawer() {
  const { drawerOpen, setDrawerOpen, cartCount, toast } = useStore();
  const reduce = useReducedMotion();
  useEffect(() => {
    if (!drawerOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setDrawerOpen(false);
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [drawerOpen, setDrawerOpen]);

  return (
    <>
      <AnimatePresence>
        {drawerOpen && (
          <motion.div className="fixed inset-0 z-[80]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-charcoal/40" onClick={() => setDrawerOpen(false)} aria-hidden />
            <motion.aside role="dialog" aria-modal="true" aria-label="Shopping bag"
              initial={reduce ? false : { x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
              className="absolute inset-y-0 right-0 flex w-full max-w-md flex-col bg-cream">
              <div className="flex h-16 items-center justify-between border-b border-charcoal/10 px-5">
                <h2 className="text-sm font-medium uppercase tracking-[0.16em]">Your Bag ({cartCount})</h2>
                <button onClick={() => setDrawerOpen(false)} aria-label="Close bag" className="-mr-2 p-2"><CloseIcon /></button>
              </div>
              <BagContents onNavigate={() => setDrawerOpen(false)} />
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[90] flex justify-center lg:bottom-8" role="status" aria-live="polite">
        <AnimatePresence>
          {toast && (
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }}
              className="bg-charcoal px-5 py-3 text-sm text-cream shadow-lg">
              {toast}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}
