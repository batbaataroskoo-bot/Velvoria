"use client";

import { useState } from "react";
import { Modal } from "@/components/Modal";

const SHOE: [number, number, number, number][] = [
  // US men, US women, EU, foot length cm
  [5, 6.5, 37.5, 23.5], [5.5, 7, 38, 24], [6, 7.5, 38.5, 24], [6.5, 8, 39, 24.5], [7, 8.5, 40, 25],
  [7.5, 9, 40.5, 25.5], [8, 9.5, 41, 26], [8.5, 10, 42, 26.5], [9, 10.5, 42.5, 27], [9.5, 11, 43, 27.5],
  [10, 11.5, 44, 28], [10.5, 12, 44.5, 28.5], [11, 12.5, 45, 29], [11.5, 13, 45.5, 29.5], [12, 13.5, 46, 30], [13, 14.5, 47.5, 31],
];
const CLOTHING: [string, string, string, string, string][] = [
  // size, US numeric, chest in, waist in, hip in
  ["XS", "0–2", "32–34", "25–27", "34–36"], ["S", "4–6", "35–37", "28–30", "37–39"], ["M", "8–10", "38–40", "31–33", "40–42"],
  ["L", "12–14", "41–43", "34–36", "43–45"], ["XL", "16–18", "44–46", "37–39", "46–48"], ["XXL", "20–22", "47–49", "40–42", "49–51"],
];

export function ShoeSizeTable() {
  return (
    <div>
      <p className="mb-4 text-sm text-ink-soft">Measure your foot from heel to longest toe, standing, at the end of the day. If you are between sizes, choose the larger size. Fit notes on each product page tell you if a style runs small or large.</p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-charcoal/20 text-left text-xs uppercase tracking-wider text-ink-soft"><th className="py-2 pr-3">US Men</th><th className="pr-3">US Women</th><th className="pr-3">EU</th><th>Foot length (cm)</th></tr></thead>
          <tbody>{SHOE.map((r) => <tr key={r[0]} className="border-b border-charcoal/10"><td className="py-2 pr-3">{r[0]}</td><td className="pr-3">{r[1]}</td><td className="pr-3">{r[2]}</td><td>{r[3]}</td></tr>)}</tbody>
        </table>
      </div>
    </div>
  );
}

export function ClothingSizeTable() {
  return (
    <div>
      <p className="mb-4 text-sm text-ink-soft">Body measurements in inches. Oversized and relaxed styles are cut with extra room — size down for a closer fit.</p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-charcoal/20 text-left text-xs uppercase tracking-wider text-ink-soft"><th className="py-2 pr-3">Size</th><th className="pr-3">US</th><th className="pr-3">Chest</th><th className="pr-3">Waist</th><th>Hip</th></tr></thead>
          <tbody>{CLOTHING.map((r) => <tr key={r[0]} className="border-b border-charcoal/10">{r.map((c, i) => <td key={i} className="py-2 pr-3">{c}</td>)}</tr>)}</tbody>
        </table>
      </div>
    </div>
  );
}

export function SizeGuideButton({ type }: { type: "shoe" | "clothing" }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="link-u text-xs">{type === "shoe" ? "Shoe size guide" : "Size guide"}</button>
      <Modal open={open} onClose={() => setOpen(false)} title={type === "shoe" ? "Footwear Size Guide" : "Clothing Size Guide"}>
        {type === "shoe" ? <ShoeSizeTable /> : <ClothingSizeTable />}
      </Modal>
    </>
  );
}
