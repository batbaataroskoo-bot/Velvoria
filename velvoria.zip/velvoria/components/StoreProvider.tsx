"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { CartItem } from "@/lib/types";
import { createClient } from "@/lib/supabase/client";

interface Store {
  ready: boolean;
  cart: CartItem[];
  cartCount: number;
  subtotal: number;
  addToCart: (item: CartItem) => void;
  setQty: (variantId: string, qty: number) => void;
  removeItem: (variantId: string) => void;
  clearCart: () => void;
  wish: string[];
  toggleWish: (productId: string) => void;
  recent: string[];
  pushRecent: (productId: string) => void;
  drawerOpen: boolean;
  setDrawerOpen: (v: boolean) => void;
  toast: string | null;
  notify: (msg: string) => void;
  userId: string | null;
}

const Ctx = createContext<Store | null>(null);

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function save(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable */
  }
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wish, setWish] = useState<string[]>([]);
  const [recent, setRecent] = useState<string[]>([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const supabase = useMemo(() => createClient(), []);

  // Load saved state from this browser.
  useEffect(() => {
    setCart(load("vel_cart", []));
    setWish(load("vel_wish", []));
    setRecent(load("vel_recent", []));
    setReady(true);
  }, []);

  // When signed in, merge the browser's bag & wishlist with the account's saved ones.
  useEffect(() => {
    const sync = async (uid: string | null) => {
      setUserId(uid);
      if (!uid) return;
      const [{ data: w }, { data: c }] = await Promise.all([
        supabase.from("wishlists").select("product_id"),
        supabase.from("carts").select("items").eq("user_id", uid).maybeSingle(),
      ]);
      setWish((local) => {
        const merged = [...new Set([...(w ?? []).map((r) => r.product_id as string), ...local])];
        const missing = local.filter((id) => !(w ?? []).some((r) => r.product_id === id));
        if (missing.length) supabase.from("wishlists").upsert(missing.map((product_id) => ({ user_id: uid, product_id }))).then(() => {});
        return merged;
      });
      const saved = (c?.items ?? []) as CartItem[];
      if (saved.length) {
        setCart((local) => {
          const map = new Map(saved.map((i) => [i.variantId, i]));
          local.forEach((i) => map.set(i.variantId, i));
          return [...map.values()];
        });
      }
    };
    supabase.auth.getUser().then(({ data }) => sync(data.user?.id ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" || event === "SIGNED_OUT") sync(session?.user?.id ?? null);
    });
    return () => sub.subscription.unsubscribe();
  }, [supabase]);

  useEffect(() => {
    if (!ready) return;
    save("vel_cart", cart);
    if (userId) {
      const t = setTimeout(() => {
        supabase.from("carts").upsert({ user_id: userId, items: cart, updated_at: new Date().toISOString() }).then(() => {});
      }, 800);
      return () => clearTimeout(t);
    }
  }, [cart, ready, userId, supabase]);
  useEffect(() => { if (ready) save("vel_wish", wish); }, [wish, ready]);
  useEffect(() => { if (ready) save("vel_recent", recent); }, [recent, ready]);

  const notify = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2600);
  }, []);

  const addToCart = useCallback((item: CartItem) => {
    setCart((c) => {
      const existing = c.find((i) => i.variantId === item.variantId);
      if (existing) {
        return c.map((i) => i.variantId === item.variantId ? { ...i, qty: Math.min(i.qty + item.qty, item.maxStock, 10) } : i);
      }
      return [...c, { ...item, qty: Math.min(item.qty, item.maxStock, 10) }];
    });
    setDrawerOpen(true);
  }, []);

  const setQty = useCallback((variantId: string, qty: number) => {
    setCart((c) => c.map((i) => (i.variantId === variantId ? { ...i, qty: Math.max(1, Math.min(qty, i.maxStock, 10)) } : i)));
  }, []);
  const removeItem = useCallback((variantId: string) => setCart((c) => c.filter((i) => i.variantId !== variantId)), []);
  const clearCart = useCallback(() => setCart([]), []);

  const toggleWish = useCallback((productId: string) => {
    setWish((w) => {
      const has = w.includes(productId);
      if (userId) {
        if (has) supabase.from("wishlists").delete().eq("user_id", userId).eq("product_id", productId).then(() => {});
        else supabase.from("wishlists").upsert({ user_id: userId, product_id: productId }).then(() => {});
      }
      return has ? w.filter((id) => id !== productId) : [productId, ...w];
    });
  }, [userId, supabase]);

  const pushRecent = useCallback((productId: string) => {
    setRecent((r) => [productId, ...r.filter((id) => id !== productId)].slice(0, 12));
  }, []);

  const value: Store = {
    ready, cart, addToCart, setQty, removeItem, clearCart,
    cartCount: cart.reduce((s, i) => s + i.qty, 0),
    subtotal: cart.reduce((s, i) => s + i.qty * i.priceCents, 0),
    wish, toggleWish, recent, pushRecent, drawerOpen, setDrawerOpen, toast, notify, userId,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be used inside <StoreProvider>");
  return ctx;
}
