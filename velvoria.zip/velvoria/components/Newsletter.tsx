"use client";

import { useActionState } from "react";
import { subscribeNewsletter } from "@/app/actions";

export function Newsletter({ dark = false }: { dark?: boolean }) {
  const [state, action, pending] = useActionState(subscribeNewsletter, null);
  return (
    <form action={action} className="flex w-full max-w-md flex-col gap-3 sm:flex-row">
      <label htmlFor={`nl-${dark}`} className="sr-only">Email address</label>
      <input id={`nl-${dark}`} name="email" type="email" required placeholder="Your email address" autoComplete="email"
        className={`h-12 flex-1 border bg-transparent px-4 text-sm outline-none ${dark ? "border-cream/40 text-cream placeholder:text-cream/50 focus:border-cream" : "border-charcoal/30 focus:border-charcoal"}`} />
      <input name="company" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      <button disabled={pending} className={dark ? "btn-light" : "btn-dark"}>{pending ? "…" : "Subscribe"}</button>
      {state && <p role="status" className={`text-sm sm:basis-full ${state.ok ? "" : "text-red-400"}`}>{state.message}</p>}
    </form>
  );
}
