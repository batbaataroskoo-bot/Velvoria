type P = { className?: string };
const base = { fill: "none", stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };

export const SearchIcon = ({ className = "h-5 w-5" }: P) => (<svg viewBox="0 0 24 24" className={className} {...base} aria-hidden><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>);
export const UserIcon = ({ className = "h-5 w-5" }: P) => (<svg viewBox="0 0 24 24" className={className} {...base} aria-hidden><circle cx="12" cy="8" r="4" /><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" /></svg>);
export const HeartIcon = ({ className = "h-5 w-5", filled = false }: P & { filled?: boolean }) => (<svg viewBox="0 0 24 24" className={className} {...base} fill={filled ? "currentColor" : "none"} aria-hidden><path d="M12 20s-7-4.4-9-9a4.8 4.8 0 0 1 9-3 4.8 4.8 0 0 1 9 3c-2 4.6-9 9-9 9Z" /></svg>);
export const BagIcon = ({ className = "h-5 w-5" }: P) => (<svg viewBox="0 0 24 24" className={className} {...base} aria-hidden><path d="M5 8h14l-1 13H6L5 8Z" /><path d="M9 8V6a3 3 0 0 1 6 0v2" /></svg>);
export const MenuIcon = ({ className = "h-6 w-6" }: P) => (<svg viewBox="0 0 24 24" className={className} {...base} aria-hidden><path d="M3 7h18M3 12h18M3 17h18" /></svg>);
export const CloseIcon = ({ className = "h-6 w-6" }: P) => (<svg viewBox="0 0 24 24" className={className} {...base} aria-hidden><path d="M6 6l12 12M18 6 6 18" /></svg>);
export const ChevronIcon = ({ className = "h-4 w-4" }: P) => (<svg viewBox="0 0 24 24" className={className} {...base} aria-hidden><path d="m6 9 6 6 6-6" /></svg>);
export const ArrowIcon = ({ className = "h-4 w-4" }: P) => (<svg viewBox="0 0 24 24" className={className} {...base} aria-hidden><path d="M5 12h14M13 6l6 6-6 6" /></svg>);
export const EyeIcon = ({ className = "h-4 w-4" }: P) => (<svg viewBox="0 0 24 24" className={className} {...base} aria-hidden><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" /><circle cx="12" cy="12" r="3" /></svg>);
export const StarIcon = ({ className = "h-4 w-4", filled = true }: P & { filled?: boolean }) => (<svg viewBox="0 0 24 24" className={className} fill={filled ? "currentColor" : "none"} stroke="currentColor" strokeWidth={1.2} aria-hidden><path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3Z" /></svg>);
