"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { useStore } from "@/components/StoreProvider";
import { BagIcon, ChevronIcon, CloseIcon, HeartIcon, MenuIcon, SearchIcon, UserIcon } from "@/components/Icons";
import { cn, money } from "@/lib/format";

export const SHOE_LINKS = [
  ["All Shoes", "/shoes"],
  ["Sneakers", "/shoes?category=sneakers"],
  ["Running-Inspired Sneakers", "/shoes?category=running-inspired-sneakers"],
  ["Casual Shoes", "/shoes?category=casual-shoes"],
  ["Boots", "/shoes?category=boots"],
  ["Sandals", "/shoes?category=sandals"],
  ["Slides", "/shoes?category=slides"],
  ["New Arrivals", "/shoes?new=1"],
  ["Best Sellers", "/shoes?best=1"],
] as const;

const NAV = [
  ["New Arrivals", "/new-arrivals"],
  ["Women", "/women"],
  ["Men", "/men"],
  ["Clothing", "/clothing"],
  ["Shoes & Sneakers", "/shoes"],
  ["Accessories", "/accessories"],
  ["Collections", "/collections"],
  ["Sale", "/sale"],
] as const;

export function Logo({ className = "" }: { className?: string }) {
  return <span className={cn("font-sans text-[17px] font-medium uppercase tracking-[var(--tracking-logo)] sm:text-[19px]", className)}>Velvoria</span>;
}

export function Header() {
  const { cartCount, setDrawerOpen, wish, ready } = useStore();
  const [menu, setMenu] = useState(false);
  const [shoesOpen, setShoesOpen] = useState(false);
  const [search, setSearch] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const reduce = useReducedMotion();
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => { setMenu(false); setSearch(false); setShoesOpen(false); }, [pathname]);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  useEffect(() => { document.body.style.overflow = menu ? "hidden" : ""; }, [menu]);

  const openShoes = () => { if (closeTimer.current) clearTimeout(closeTimer.current); setShoesOpen(true); };
  const closeShoes = () => { closeTimer.current = setTimeout(() => setShoesOpen(false), 120); };

  return (
    <>
      <div className="bg-charcoal py-2 text-center text-[11px] tracking-[0.14em] text-cream">
        FREE STANDARD SHIPPING ON ORDERS OVER $100 · FREE 30-DAY RETURNS
      </div>
      <header className={cn("sticky top-0 z-50 border-b transition-colors duration-300", scrolled ? "border-charcoal/10 bg-cream/95 backdrop-blur" : "border-transparent bg-cream")}>
        <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-2 focus:bg-white focus:px-3 focus:py-2">Skip to content</a>
        <div className="container-x flex h-16 items-center justify-between gap-4 lg:h-[72px]">
          <div className="flex items-center gap-2 lg:hidden">
            <button onClick={() => setMenu(true)} aria-label="Open menu" className="-ml-2 p-2"><MenuIcon /></button>
            <button onClick={() => setSearch(true)} aria-label="Search" className="p-2"><SearchIcon /></button>
          </div>

          <Link href="/" aria-label="Velvoria home" className="lg:mr-6"><Logo /></Link>

          <nav aria-label="Main" className="hidden flex-1 lg:block">
            <ul className="flex items-center gap-6 xl:gap-8">
              {NAV.map(([label, href]) => label === "Shoes & Sneakers" ? (
                <li key={label} className="relative" onMouseEnter={openShoes} onMouseLeave={closeShoes}>
                  <div className="flex items-center gap-1">
                    <Link href={href} className={cn("py-6 text-[12px] font-medium uppercase tracking-[0.12em] hover:opacity-60", pathname.startsWith("/shoes") && "underline underline-offset-8")}>{label}</Link>
                    <button aria-label="Open shoes menu" aria-expanded={shoesOpen} onClick={() => setShoesOpen((v) => !v)} className="p-1"><ChevronIcon className={cn("h-3.5 w-3.5 transition", shoesOpen && "rotate-180")} /></button>
                  </div>
                  <AnimatePresence>
                    {shoesOpen && (
                      <motion.div
                        initial={reduce ? false : { opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}
                        transition={{ duration: 0.25 }}
                        className="absolute left-[-160px] top-full z-50 w-[520px] border border-charcoal/10 bg-cream p-7 shadow-[0_20px_40px_-20px_rgba(0,0,0,0.25)]"
                      >
                        <div className="grid grid-cols-[1fr_180px] gap-8">
                          <ul className="grid grid-cols-1 gap-2.5">
                            {SHOE_LINKS.map(([l, h]) => (
                              <li key={l}><Link href={h} className="text-sm hover:underline underline-offset-4">{l}</Link></li>
                            ))}
                          </ul>
                          <Link href="/shoes?category=sneakers" className="group flex flex-col justify-end bg-sage p-4">
                            <span className="eyebrow text-charcoal/70">Spotlight</span>
                            <span className="headline mt-1 text-2xl">Step into your style</span>
                            <span className="mt-2 text-xs underline underline-offset-4">Shop Sneakers</span>
                          </Link>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </li>
              ) : (
                <li key={label}>
                  <Link href={href} className={cn("py-6 text-[12px] font-medium uppercase tracking-[0.12em] hover:opacity-60", label === "Sale" && "text-[#a4532f]", pathname === href && "underline underline-offset-8")}>{label}</Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="flex items-center gap-1 sm:gap-2">
            <button onClick={() => setSearch(true)} aria-label="Search" className="hidden p-2 lg:block"><SearchIcon /></button>
            <Link href="/account" aria-label="Account" className="hidden p-2 sm:block"><UserIcon /></Link>
            <Link href="/wishlist" aria-label={`Wishlist (${wish.length})`} className="relative p-2">
              <HeartIcon />
              {ready && wish.length > 0 && <span className="absolute right-0.5 top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-peach px-1 text-[9px] font-semibold">{wish.length}</span>}
            </Link>
            <button onClick={() => setDrawerOpen(true)} aria-label={`Shopping bag (${cartCount} items)`} className="relative -mr-2 p-2">
              <BagIcon />
              {ready && cartCount > 0 && <span className="absolute right-0.5 top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-charcoal px-1 text-[9px] font-semibold text-cream">{cartCount}</span>}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <AnimatePresence>
        {menu && (
          <motion.div className="fixed inset-0 z-[60] lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-charcoal/40" onClick={() => setMenu(false)} aria-hidden />
            <motion.nav aria-label="Mobile"
              initial={reduce ? false : { x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }} transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="absolute inset-y-0 left-0 flex w-[88%] max-w-sm flex-col overflow-y-auto bg-cream">
              <div className="flex h-16 items-center justify-between border-b border-charcoal/10 px-5">
                <Logo />
                <button onClick={() => setMenu(false)} aria-label="Close menu" className="-mr-2 p-2"><CloseIcon /></button>
              </div>
              <ul className="px-5 py-4">
                {NAV.filter(([l]) => l !== "Shoes & Sneakers").map(([label, href]) => (
                  <li key={label}><Link href={href} className={cn("block border-b border-charcoal/10 py-3.5 text-[15px] uppercase tracking-[0.1em]", label === "Sale" && "text-[#a4532f]")}>{label}</Link></li>
                ))}
              </ul>
              <div className="mx-5 mb-4 bg-sand/60 p-5">
                <p className="eyebrow mb-3">Shoes & Sneakers</p>
                <ul className="grid grid-cols-2 gap-x-3 gap-y-2.5">
                  {SHOE_LINKS.map(([l, h]) => <li key={l}><Link href={h} className="text-sm">{l}</Link></li>)}
                </ul>
              </div>
              <div className="mt-auto space-y-3 border-t border-charcoal/10 px-5 py-5 text-sm">
                <Link href="/account" className="flex items-center gap-3"><UserIcon /> Account</Link>
                <Link href="/wishlist" className="flex items-center gap-3"><HeartIcon /> Wishlist</Link>
                <Link href="/faq" className="block text-ink-soft">Help & FAQ</Link>
              </div>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>

      <SearchOverlay open={search} onClose={() => setSearch(false)} />
    </>
  );
}

interface Suggestion { slug: string; name: string; price_cents: number; department: string; hex: string }

function SearchOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Suggestion[]>([]);
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { if (open) setTimeout(() => inputRef.current?.focus(), 50); }, [open]);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  useEffect(() => {
    if (q.trim().length < 2) { setResults([]); return; }
    const ctrl = new AbortController();
    const t = setTimeout(() => {
      fetch(`/api/search?q=${encodeURIComponent(q)}`, { signal: ctrl.signal })
        .then((r) => r.json()).then((d) => setResults(d.results ?? [])).catch(() => {});
    }, 180);
    return () => { clearTimeout(t); ctrl.abort(); };
  }, [q]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[65]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-charcoal/30" onClick={onClose} aria-hidden />
          <motion.div role="dialog" aria-modal="true" aria-label="Search" initial={{ y: -20 }} animate={{ y: 0 }} exit={{ y: -20 }}
            className="relative bg-cream pb-8 pt-6 shadow-xl">
            <div className="container-x">
              <form onSubmit={(e) => { e.preventDefault(); if (q.trim()) { router.push(`/search?q=${encodeURIComponent(q.trim())}`); onClose(); } }}
                className="flex items-center gap-3 border-b border-charcoal pb-3">
                <SearchIcon className="h-6 w-6" />
                <input ref={inputRef} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search clothing, sneakers, colors…"
                  aria-label="Search products" className="w-full bg-transparent text-xl outline-none placeholder:text-ink-soft/60 sm:text-2xl" />
                <button type="button" onClick={onClose} aria-label="Close search" className="p-1"><CloseIcon /></button>
              </form>
              <div className="mt-5">
                {results.length > 0 ? (
                  <ul className="grid gap-1 sm:grid-cols-2">
                    {results.map((r) => (
                      <li key={r.slug}>
                        <Link href={`/products/${r.slug}`} onClick={onClose} className="flex items-center gap-3 p-2 hover:bg-sand/50">
                          <span className="h-10 w-8 shrink-0" style={{ background: r.hex }} />
                          <span className="flex-1 text-sm">{r.name}</span>
                          <span className="text-sm text-ink-soft">{money(r.price_cents)}</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="flex flex-wrap gap-2 text-sm">
                    <span className="eyebrow mr-2 self-center">Popular</span>
                    {["Sneakers", "Hoodie", "Denim", "Retro Runner", "Slides", "Sage"].map((s) => (
                      <button key={s} onClick={() => setQ(s)} className="border border-charcoal/20 px-3 py-1.5 hover:border-charcoal">{s}</button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
