"use client";

import Link from "next/link";
import { useState } from "react";
import type { ProductFull } from "@/lib/types";
import { availability, badge, isOnSale } from "@/lib/catalog";
import { cn, money } from "@/lib/format";
import { useStore } from "@/components/StoreProvider";
import { ProductMedia, anglesFor } from "@/components/ProductMedia";
import { HeartIcon, EyeIcon } from "@/components/Icons";
import { Modal } from "@/components/Modal";
import { VariantPicker } from "@/components/VariantPicker";

export function ProductCard({ product, priority }: { product: ProductFull; priority?: boolean }) {
  const { wish, toggleWish, notify } = useStore();
  const [colorwayId, setColorwayId] = useState(product.colorways[0]?.id);
  const [quick, setQuick] = useState(false);
  const angles = anglesFor(product);
  const [main, alt] = [angles[0], angles[1] ?? angles[0]];
  const wished = wish.includes(product.id);
  const b = badge(product);
  const avail = availability(product);
  const href = `/products/${product.slug}`;

  return (
    <article className="group relative">
      <div className="relative">
        <Link href={href} className="block overflow-hidden" aria-label={product.name}>
          <div className="relative transition-transform duration-700 ease-[var(--ease-editorial)] group-hover:scale-[1.03]">
            <ProductMedia product={product} colorwayId={colorwayId} angle={main} priority={priority} />
            {/* Alternate angle on hover */}
            <div className="absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100">
              <ProductMedia product={product} colorwayId={colorwayId} angle={alt} />
            </div>
          </div>
        </Link>
        {b && (
          <span className={cn("pointer-events-none absolute left-3 top-3 px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.14em]",
            b === "Sale" ? "bg-peach text-charcoal" : "bg-cream text-charcoal")}>{b}</span>
        )}
        <button
          onClick={() => { toggleWish(product.id); notify(wished ? "Removed from wishlist" : "Saved to wishlist"); }}
          aria-label={wished ? `Remove ${product.name} from wishlist` : `Save ${product.name} to wishlist`} aria-pressed={wished}
          className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-cream/90 transition hover:bg-cream"
        >
          <HeartIcon filled={wished} className={cn("h-[18px] w-[18px]", wished && "text-peach")} />
        </button>
        <button
          onClick={() => setQuick(true)}
          className="absolute inset-x-3 bottom-3 flex h-10 items-center justify-center gap-2 bg-cream/95 text-[11px] font-semibold uppercase tracking-[0.16em] opacity-100 transition duration-300 hover:bg-white lg:translate-y-2 lg:opacity-0 lg:group-hover:translate-y-0 lg:group-hover:opacity-100 focus:opacity-100 focus:translate-y-0"
        >
          <EyeIcon /> Quick View
        </button>
      </div>

      <div className="mt-3 space-y-1">
        <div className="flex items-start justify-between gap-3">
          <h3 className="text-[13px] font-medium leading-snug sm:text-sm"><Link href={href} className="hover:underline underline-offset-4">{product.name}</Link></h3>
          <p className="shrink-0 text-[13px] sm:text-sm">
            {isOnSale(product) && <span className="mr-1.5 text-ink-soft line-through">{money(product.compare_at_cents!)}</span>}
            <span className={cn(isOnSale(product) && "text-[#a4532f]")}>{money(product.price_cents)}</span>
          </p>
        </div>
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5" aria-label="Available colorways">
            {product.colorways.slice(0, 5).map((c) => (
              <button key={c.id} onMouseEnter={() => setColorwayId(c.id)} onFocus={() => setColorwayId(c.id)} onClick={() => setColorwayId(c.id)}
                aria-label={`Show ${c.name}`} title={c.name}
                className={cn("h-3.5 w-3.5 rounded-full border transition", c.id === colorwayId ? "border-charcoal ring-1 ring-charcoal ring-offset-1 ring-offset-cream" : "border-black/15")}
                style={{ background: c.hex }} />
            ))}
            <span className="ml-1 text-[11px] text-ink-soft">{product.colorways.length} {product.department === "footwear" ? "colorways" : "colors"}</span>
          </div>
          <span className={cn("text-[11px]", avail.tone === "out" ? "text-red-700" : avail.tone === "low" ? "text-[#a4532f]" : "text-ink-soft")}>{avail.label}</span>
        </div>
        {product.is_demo && <p className="text-[10px] uppercase tracking-[0.14em] text-ink-soft/70">Sample product</p>}
      </div>

      <Modal open={quick} onClose={() => setQuick(false)} title={product.name} wide>
        <div className="grid gap-6 md:grid-cols-2">
          <div className="grid grid-cols-2 gap-2">
            {angles.slice(0, 4).map((a) => <ProductMedia key={a} product={product} colorwayId={colorwayId} angle={a} sizes="25vw" />)}
          </div>
          <div className="space-y-5">
            <p className="text-lg">{money(product.price_cents)}</p>
            <p className="text-sm leading-6 text-ink-soft">{product.description}</p>
            {colorwayId && <VariantPicker product={product} colorwayId={colorwayId} onColorway={setColorwayId} compact />}
            <Link href={href} className="link-u text-sm" onClick={() => setQuick(false)}>View full details</Link>
          </div>
        </div>
      </Modal>
    </article>
  );
}

export function ProductGrid({ products, cols = 4 }: { products: ProductFull[]; cols?: 3 | 4 }) {
  return (
    <div className={cn("grid grid-cols-2 gap-x-3 gap-y-10 sm:gap-x-5 md:grid-cols-3", cols === 4 && "lg:grid-cols-4")}>
      {products.map((p, i) => <ProductCard key={p.id} product={p} priority={i < 4} />)}
    </div>
  );
}
