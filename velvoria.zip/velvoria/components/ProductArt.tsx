import type { Angle } from "@/lib/types";

/**
 * Clearly-labelled IMAGE PLACEHOLDER drawn in code.
 * Shown whenever a product has no uploaded photograph yet.
 * Upload real 4:5 photography from Admin → Products to replace it.
 */
type Kind = "tee" | "tank" | "long" | "hoodie" | "pants" | "shorts" | "dress" | "jacket" | "sneaker" | "hightop" | "boot" | "slide" | "sandal" | "bag" | "beanie" | "socks";

export function kindFor(categorySlug: string | null | undefined, name = ""): Kind {
  const s = categorySlug ?? "";
  const n = name.toLowerCase();
  if (n.includes("tank")) return "tank";
  if (s === "t-shirts-tops" || s === "everyday-essentials" || s === "activewear") return "tee";
  if (s === "hoodies-sweatshirts") return n.includes("hoodie") ? "hoodie" : "long";
  if (s === "knitwear") return "long";
  if (s === "jeans-denim" || s === "pants-trousers") return "pants";
  if (s === "shorts") return "shorts";
  if (s === "dresses-skirts") return "dress";
  if (s === "jackets-outerwear") return "jacket";
  if (s === "high-top-sneakers") return "hightop";
  if (s === "boots") return "boot";
  if (s === "slides") return "slide";
  if (s === "sandals") return "sandal";
  if (s === "bags") return "bag";
  if (s === "hats") return "beanie";
  if (s === "socks") return "socks";
  return "sneaker";
}

function shade(hex: string, amt: number) {
  const n = parseInt(hex.replace("#", ""), 16);
  const c = (v: number) => Math.max(0, Math.min(255, v + amt));
  return `rgb(${c(n >> 16)},${c((n >> 8) & 255)},${c(n & 255)})`;
}

const LONG = "M62 62 L85 52 Q100 66 115 52 L138 62 L160 120 L162 185 L145 187 L140 122 L138 192 L62 192 L60 122 L55 187 L38 185 L40 120 Z";

function Shape({ kind, fill, line }: { kind: Kind; fill: string; line: string }) {
  const sole = "#F5F2EC";
  const p = { fill, stroke: line, strokeWidth: 1.4, strokeLinejoin: "round" as const };
  switch (kind) {
    case "tee": return <path {...p} d="M60 60 L85 50 Q100 64 115 50 L140 60 L166 92 L146 106 L138 98 L138 192 L62 192 L62 98 L54 106 L34 92 Z" />;
    case "tank": return <path {...p} d="M76 52 Q82 80 74 98 L70 192 L130 192 L126 98 Q118 80 124 52 L112 52 Q100 76 88 52 Z" />;
    case "long": return <path {...p} d={LONG} />;
    case "hoodie": return <g><path {...p} d={LONG} /><path {...p} d="M82 56 Q80 30 100 28 Q120 30 118 56 Q100 72 82 56 Z" /><path fill="none" stroke={line} strokeWidth={1.2} d="M78 150 L122 150 L118 175 L82 175 Z" /></g>;
    case "jacket": return <g><path {...p} d={LONG} /><path stroke={line} strokeWidth={1.4} d="M100 62 L100 192" /><path fill="none" stroke={line} strokeWidth={1.2} d="M70 140 L90 140 M110 140 L130 140" /></g>;
    case "pants": return <path {...p} d="M70 42 L130 42 L140 210 L110 210 L100 92 L90 210 L60 210 Z" />;
    case "shorts": return <path {...p} d="M66 72 L134 72 L142 152 L106 152 L100 106 L94 152 L58 152 Z" />;
    case "dress": return <path {...p} d="M86 42 L114 42 L118 82 L152 204 L48 204 L82 82 Z" />;
    case "sneaker": return <g><path {...p} d="M30 158 Q30 120 60 116 L94 108 Q110 94 126 110 Q150 130 170 138 Q184 143 182 158 Z" /><path fill={sole} stroke={line} strokeWidth={1.4} d="M27 158 L184 158 Q186 172 172 175 L38 175 Q25 172 27 158 Z" /><path fill="none" stroke={line} strokeWidth={1.1} d="M96 112 L120 132 M104 108 L128 128 M60 140 Q100 130 150 145" /></g>;
    case "hightop": return <g><path {...p} d="M40 158 L42 82 L92 80 L100 108 Q140 124 168 137 Q182 143 180 158 Z" /><path fill={sole} stroke={line} strokeWidth={1.4} d="M37 158 L182 158 Q184 172 170 175 L48 175 Q35 172 37 158 Z" /><path fill="none" stroke={line} strokeWidth={1.1} d="M50 100 L90 100 M50 115 L94 115" /></g>;
    case "boot": return <g><path {...p} d="M55 162 L58 66 L106 66 L108 124 Q150 130 165 145 Q171 155 168 162 Z" /><path fill={shade(fill, -40)} stroke={line} strokeWidth={1.4} d="M52 162 L170 162 L170 176 L52 176 Z" /><path fill={shade(fill, -15)} stroke={line} d="M90 70 L104 70 L104 120 L90 120 Z" /></g>;
    case "slide": return <g><path fill={sole} stroke={line} strokeWidth={1.4} d="M28 166 Q28 150 48 150 L166 150 Q182 152 180 166 Q178 177 162 177 L44 177 Q28 176 28 166 Z" /><path {...p} d="M66 151 Q72 112 106 110 Q140 112 144 151 Z" /></g>;
    case "sandal": return <g><path fill={shade(fill, 30)} stroke={line} strokeWidth={1.4} d="M28 166 Q28 152 48 152 L166 152 Q182 154 180 166 Q178 177 162 177 L44 177 Q28 176 28 166 Z" /><path fill="none" stroke={fill} strokeWidth={9} strokeLinecap="round" d="M70 152 Q80 122 108 122 Q126 124 132 152 M118 152 Q140 128 162 152" /></g>;
    case "bag": return <g><path fill="none" stroke={line} strokeWidth={6} d="M76 102 Q76 48 100 48 Q124 48 124 102" /><path {...p} d="M48 100 L152 100 L162 204 L38 204 Z" /></g>;
    case "beanie": return <g><path {...p} d="M56 150 Q56 66 100 66 Q144 66 144 150 Z" /><path fill={shade(fill, -18)} stroke={line} strokeWidth={1.4} d="M50 140 L150 140 L150 172 L50 172 Z" /></g>;
    case "socks": return <path {...p} d="M80 48 L116 48 L116 150 Q116 174 140 180 Q162 186 160 200 Q156 213 130 210 L96 205 Q78 200 80 180 Z" />;
  }
}

export function ProductArt({
  kind, hex, angle = "front", label = true, className = "",
}: { kind: Kind; hex: string; angle?: Angle; label?: boolean; className?: string }) {
  const line = shade(hex, -70);
  const transform =
    angle === "back" ? "translate(200 0) scale(-1 1)"
      : angle === "top" ? "rotate(-90 100 125) translate(0 10)"
      : angle === "detail" ? "translate(-100 -150) scale(2)"
      : angle === "outsole" ? "translate(0 300) scale(1 -1)"
      : angle === "lifestyle" ? "translate(20 30) scale(0.8)"
      : undefined;
  const bg = angle === "lifestyle" ? "#B2B8A7" : angle === "detail" ? "#EFEBE4" : "#E9E2D8";
  return (
    <svg viewBox="0 0 200 250" className={className} role="img" aria-label={`Image placeholder (${angle} view)`}>
      <defs>
        <radialGradient id="glow" cx="50%" cy="45%" r="70%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="200" height="250" fill={bg} />
      <rect width="200" height="250" fill="url(#glow)" />
      <ellipse cx="100" cy="214" rx="66" ry="5" fill="#000" opacity="0.06" />
      <g transform={transform}><Shape kind={kind} fill={hex} line={line} /></g>
      {label && (
        <text x="100" y="238" textAnchor="middle" fontSize="6.5" letterSpacing="1.6" fill="#5E5B56" opacity="0.75" fontFamily="sans-serif">
          IMAGE PLACEHOLDER · {angle.toUpperCase()}
        </text>
      )}
    </svg>
  );
}
