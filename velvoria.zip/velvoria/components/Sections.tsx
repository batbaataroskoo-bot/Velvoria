import Link from "next/link";
import Image from "next/image";
import type { ProductFull } from "@/lib/types";
import { ProductCard } from "@/components/ProductCard";
import { ProductMedia, anglesFor } from "@/components/ProductMedia";
import { Reveal } from "@/components/Reveal";
import { ArrowIcon } from "@/components/Icons";
import { money } from "@/lib/format";

export function SectionHead({ eyebrow, title, href, cta = "View all" }: { eyebrow?: string; title: string; href?: string; cta?: string }) {
  return (
    <div className="mb-8 flex items-end justify-between gap-6">
      <div>
        {eyebrow && <p className="eyebrow mb-2">{eyebrow}</p>}
        <h2 className="headline text-3xl sm:text-4xl lg:text-5xl">{title}</h2>
      </div>
      {href && <Link href={href} className="group flex shrink-0 items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.14em]">{cta}<ArrowIcon className="h-4 w-4 transition group-hover:translate-x-1" /></Link>}
    </div>
  );
}

/** Horizontal swipe rail on mobile, grid on desktop. */
export function ProductRail({ products }: { products: ProductFull[] }) {
  return (
    <div className="no-scrollbar -mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 sm:-mx-6 sm:px-6 lg:mx-0 lg:grid lg:grid-cols-4 lg:gap-5 lg:overflow-visible lg:px-0">
      {products.map((p) => (
        <div key={p.id} className="w-[46%] shrink-0 snap-start sm:w-[31%] lg:w-auto"><ProductCard product={p} /></div>
      ))}
    </div>
  );
}

const TOP = ["t-shirts-tops", "hoodies-sweatshirts", "knitwear", "jackets-outerwear", "dresses-skirts"];
const BOTTOM = ["jeans-denim", "pants-trousers", "shorts"];

/** Builds outfits (top + bottom + footwear) from products in a collection. */
export function buildLooks(products: ProductFull[], collection: string, count = 3) {
  const inC = products.filter((p) => p.collections.includes(collection));
  const tops = inC.filter((p) => TOP.includes(p.category?.slug ?? ""));
  const bottoms = inC.filter((p) => BOTTOM.includes(p.category?.slug ?? ""));
  const shoes = inC.filter((p) => p.department === "footwear");
  const looks: ProductFull[][] = [];
  for (let i = 0; i < count && tops[i] && shoes[i % (shoes.length || 1)]; i++) {
    const top = tops[i];
    const look = [top];
    if (top.category?.slug !== "dresses-skirts" && bottoms.length) look.push(bottoms[i % bottoms.length]);
    look.push(shoes[i % shoes.length]);
    looks.push(look);
  }
  return looks;
}

export function LookCard({ look, index }: { look: ProductFull[]; index: number }) {
  const total = look.reduce((s, p) => s + p.price_cents, 0);
  return (
    <Reveal delay={index * 0.08} className="bg-white/60 p-3">
      <div className="grid grid-cols-2 gap-2">
        <div className="row-span-2"><ProductMedia product={look[0]} angle={anglesFor(look[0])[look[0].images.length ? 0 : 3] ?? "front"} /></div>
        {look.slice(1).map((p) => <ProductMedia key={p.id} product={p} angle={anglesFor(p)[0]} sizes="20vw" />)}
      </div>
      <div className="px-1 pb-1 pt-4">
        <p className="eyebrow mb-2">Look {String(index + 1).padStart(2, "0")}</p>
        <ul className="space-y-1.5">
          {look.map((p) => (
            <li key={p.id} className="flex justify-between gap-2 text-sm">
              <Link href={`/products/${p.slug}`} className="hover:underline underline-offset-4">{p.name}</Link>
              <span className="text-ink-soft">{money(p.price_cents)}</span>
            </li>
          ))}
        </ul>
        <p className="mt-3 border-t border-charcoal/10 pt-3 text-sm font-medium">Complete look {money(total)}</p>
      </div>
    </Reveal>
  );
}

export function EditorialTile({ href, title, eyebrow, image, children, className = "" }: {
  href: string; title: string; eyebrow?: string; image?: string | null; children?: React.ReactNode; className?: string;
}) {
  return (
    <Link href={href} className={`group relative block overflow-hidden bg-sand ${className}`}>
      <div className="absolute inset-0 transition-transform duration-[1.2s] ease-[var(--ease-editorial)] group-hover:scale-105">
        {image ? <Image src={image} alt="" fill sizes="(min-width:1024px) 50vw, 100vw" className="object-cover" /> : children}
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-charcoal/45 via-transparent to-transparent" />
      <div className="absolute inset-x-0 bottom-0 p-5 text-cream sm:p-7">
        {eyebrow && <p className="mb-1 text-[11px] uppercase tracking-[0.2em] text-cream/80">{eyebrow}</p>}
        <p className="headline text-2xl sm:text-3xl">{title}</p>
        <span className="mt-2 inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em]">Shop now <ArrowIcon className="h-3.5 w-3.5 transition group-hover:translate-x-1" /></span>
      </div>
    </Link>
  );
}
