"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import type { Angle, ProductFull } from "@/lib/types";
import { useStore } from "@/components/StoreProvider";
import { ProductMedia, anglesFor, photoFor } from "@/components/ProductMedia";
import { ProductArt, kindFor } from "@/components/ProductArt";
import { VariantPicker } from "@/components/VariantPicker";
import { HeartIcon, CloseIcon } from "@/components/Icons";
import { cn, money } from "@/lib/format";
import { badge, isOnSale } from "@/lib/catalog";
import { FREE_SHIPPING_THRESHOLD } from "@/lib/shipping";

export function ProductDetail({ product, rating }: { product: ProductFull; rating: { avg: number; count: number } }) {
  const { pushRecent, wish, toggleWish, notify } = useStore();
  const [colorwayId, setColorwayId] = useState(product.colorways[0]?.id ?? "");
  const [zoom, setZoom] = useState<Angle | null>(null);
  const [active, setActive] = useState(0);
  const angles = anglesFor(product);
  const scroller = useRef<HTMLDivElement>(null);
  const wished = wish.includes(product.id);
  const isShoe = product.department === "footwear";
  const b = badge(product);

  useEffect(() => { pushRecent(product.id); }, [product.id, pushRecent]);

  const onScroll = () => {
    const el = scroller.current;
    if (el) setActive(Math.round(el.scrollLeft / el.clientWidth));
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[1.35fr_1fr] lg:gap-14">
      {/* Gallery: swipeable on mobile, grid on desktop */}
      <div>
        <div ref={scroller} onScroll={onScroll} className="no-scrollbar -mx-4 flex snap-x snap-mandatory overflow-x-auto sm:mx-0 lg:grid lg:grid-cols-2 lg:gap-2 lg:overflow-visible">
          {angles.map((a, i) => (
            <button key={a} onClick={() => setZoom(a)} aria-label={`Zoom ${a} view`}
              className="relative w-full shrink-0 snap-center cursor-zoom-in lg:w-auto">
              <ProductMedia product={product} colorwayId={colorwayId} angle={a} priority={i < 2} sizes="(min-width:1024px) 30vw, 100vw" />
              <span className="absolute left-3 top-3 bg-cream/90 px-2 py-0.5 text-[10px] uppercase tracking-[0.14em]">{a}</span>
            </button>
          ))}
        </div>
        <div className="mt-3 flex justify-center gap-1.5 lg:hidden" aria-hidden>
          {angles.map((a, i) => <span key={a} className={cn("h-1 rounded-full transition-all", i === active ? "w-6 bg-charcoal" : "w-1.5 bg-charcoal/25")} />)}
        </div>
      </div>

      {/* Info */}
      <div className="lg:sticky lg:top-24 lg:self-start">
        <div className="mb-2 flex items-center gap-3">
          {b && <span className={cn("px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.14em]", b === "Sale" ? "bg-peach" : "bg-sand")}>{b}</span>}
          {product.is_demo && <span className="border border-charcoal/20 px-2 py-1 text-[10px] uppercase tracking-[0.14em] text-ink-soft">Sample product</span>}
        </div>
        <div className="flex items-start justify-between gap-4">
          <h1 className="headline text-3xl sm:text-4xl">{product.name}</h1>
          <button onClick={() => { toggleWish(product.id); notify(wished ? "Removed from wishlist" : "Saved to wishlist"); }}
            aria-pressed={wished} aria-label={wished ? "Remove from wishlist" : "Save to wishlist"} className="mt-1 grid h-10 w-10 shrink-0 place-items-center rounded-full border border-charcoal/15">
            <HeartIcon filled={wished} className={cn(wished && "text-peach")} />
          </button>
        </div>
        <p className="mt-1 text-sm text-ink-soft">{product.category?.name} · {product.gender === "unisex" ? "Unisex" : product.gender === "women" ? "Women's" : "Men's"}</p>
        <p className="mt-4 text-xl">
          {isOnSale(product) && <span className="mr-2 text-ink-soft line-through">{money(product.compare_at_cents!)}</span>}
          <span className={cn(isOnSale(product) && "text-[#a4532f]")}>{money(product.price_cents)}</span>
        </p>
        {rating.count > 0 && (
          <a href="#reviews" className="mt-2 inline-block text-sm text-ink-soft hover:underline">★ {rating.avg.toFixed(1)} · {rating.count} review{rating.count === 1 ? "" : "s"}</a>
        )}

        <div className="mt-8">
          {colorwayId && <VariantPicker product={product} colorwayId={colorwayId} onColorway={setColorwayId} />}
        </div>

        {product.fit_note && (
          <p className="mt-6 bg-sage/30 px-4 py-3 text-sm"><span className="font-medium">Fit: </span>{product.fit_note}</p>
        )}

        <div className="mt-8 divide-y divide-charcoal/10 border-y border-charcoal/10">
          <Accordion title="Description" defaultOpen><p>{product.description}</p></Accordion>
          {(product.materials || product.construction) && (
            <Accordion title={isShoe ? "Materials & construction" : "Materials & care"}>
              {product.materials && <p>{product.materials}</p>}
              {product.construction && <p className="mt-2">{product.construction}</p>}
              {!isShoe && <p className="mt-2">Machine wash cold, inside out. Tumble dry low. Do not bleach.</p>}
            </Accordion>
          )}
          <Accordion title="Shipping & returns">
            <p>Free standard shipping on orders over {money(FREE_SHIPPING_THRESHOLD)} (3–6 business days). Express available at checkout.</p>
            <p className="mt-2">Free returns within 30 days of delivery on unworn items with tags{isShoe ? " — please try shoes on a clean, soft surface" : ""}. <a href="/returns" className="link-u">Returns policy</a></p>
          </Accordion>
        </div>
      </div>

      {zoom && <ZoomViewer product={product} colorwayId={colorwayId} angle={zoom} angles={angles} onClose={() => setZoom(null)} onAngle={setZoom} />}
    </div>
  );
}

function Accordion({ title, children, defaultOpen = false }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  return (
    <details open={defaultOpen} className="group py-4">
      <summary className="flex cursor-pointer list-none items-center justify-between text-xs font-semibold uppercase tracking-[0.14em]">
        {title}<span className="text-lg transition group-open:rotate-45">+</span>
      </summary>
      <div className="mt-3 text-sm leading-6 text-ink-soft">{children}</div>
    </details>
  );
}

/** Full-screen zoom: move the mouse (or drag a finger) to pan around a 2.2× image. */
function ZoomViewer({ product, colorwayId, angle, angles, onClose, onAngle }: {
  product: ProductFull; colorwayId: string; angle: Angle; angles: Angle[]; onClose: () => void; onAngle: (a: Angle) => void;
}) {
  const [origin, setOrigin] = useState("50% 50%");
  const [zoomed, setZoomed] = useState(true);
  const photo = photoFor(product, colorwayId, angle);
  const color = product.colorways.find((c) => c.id === colorwayId);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      const i = angles.indexOf(angle);
      if (e.key === "ArrowRight") onAngle(angles[(i + 1) % angles.length]);
      if (e.key === "ArrowLeft") onAngle(angles[(i - 1 + angles.length) % angles.length]);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [angle, angles, onAngle, onClose]);

  const move = (x: number, y: number, el: HTMLElement) => {
    const r = el.getBoundingClientRect();
    setOrigin(`${((x - r.left) / r.width) * 100}% ${((y - r.top) / r.height) * 100}%`);
  };

  return (
    <div className="fixed inset-0 z-[85] flex flex-col bg-cream" role="dialog" aria-modal="true" aria-label="Image zoom">
      <div className="flex items-center justify-between px-4 py-3">
        <p className="text-xs uppercase tracking-[0.14em]">{product.name} — {angle}</p>
        <button onClick={onClose} aria-label="Close zoom" className="p-2"><CloseIcon /></button>
      </div>
      <div className="relative flex-1 overflow-hidden"
        onMouseMove={(e) => move(e.clientX, e.clientY, e.currentTarget)}
        onTouchMove={(e) => move(e.touches[0].clientX, e.touches[0].clientY, e.currentTarget)}
        onClick={() => setZoomed((z) => !z)}>
        <div className="mx-auto h-full max-w-[min(100%,80vh)] transition-transform duration-200" style={{ transform: zoomed ? "scale(2.2)" : "scale(1)", transformOrigin: origin }}>
          {photo ? <div className="relative h-full w-full"><Image src={photo.url} alt={photo.alt ?? product.name} fill sizes="100vw" className="object-contain" /></div>
            : <ProductArt kind={kindFor(product.category?.slug, product.name)} hex={color?.hex ?? "#E6DCD0"} angle={angle} className="h-full w-full" />}
        </div>
      </div>
      <div className="flex justify-center gap-2 overflow-x-auto p-3">
        {angles.map((a) => (
          <button key={a} onClick={() => onAngle(a)} aria-label={`${a} view`} className={cn("w-14 shrink-0 border", a === angle ? "border-charcoal" : "border-transparent")}>
            <ProductMedia product={product} colorwayId={colorwayId} angle={a} sizes="56px" />
          </button>
        ))}
      </div>
    </div>
  );
}
