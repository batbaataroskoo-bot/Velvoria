"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useState, useTransition } from "react";
import type { Filters } from "@/lib/filters";
import type { Category } from "@/lib/types";
import { cn } from "@/lib/format";
import { ChevronIcon, CloseIcon } from "@/components/Icons";

interface Facets {
  categories: Category[]; genders: string[]; brands: string[]; styles: string[];
  colors: { name: string; hex: string }[]; clothingSizes: string[]; us: string[]; eu: string[]; priceMax: number;
}

const SORTS: [Filters["sort"], string][] = [["featured", "Featured"], ["newest", "Newest"], ["popular", "Most popular"], ["price-asc", "Price: low to high"], ["price-desc", "Price: high to low"]];

export function FilterPanel({ facets, filters, mode, basePath, count, preset }: {
  facets: Facets; filters: Filters; mode: "footwear" | "clothing" | "accessories" | "all"; basePath: string; count: number; preset: string[];
}) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();

  function update(mut: (p: URLSearchParams) => void) {
    const p = new URLSearchParams(params.toString());
    mut(p);
    start(() => router.replace(`${pathname}${p.toString() ? `?${p}` : ""}`, { scroll: false }));
  }
  const toggle = (key: string, value: string) => update((p) => {
    const cur = (p.get(key) ?? "").split(",").filter(Boolean);
    const next = cur.includes(value) ? cur.filter((v) => v !== value) : [...cur, value];
    if (next.length) p.set(key, next.join(",")); else p.delete(key);
  });
  const flag = (key: string, value: string) => update((p) => (p.get(key) === value ? p.delete(key) : p.set(key, value)));
  const has = (key: string, value: string) => (params.get(key) ?? "").split(",").includes(value);
  const activeCount = [...params.keys()].filter((k) => k !== "sort" && k !== "q").length;

  const panel = (
    <div className={cn("space-y-1 text-sm", pending && "opacity-60")}>
      {!preset.includes("category") && facets.categories.length > 1 && (
        <Group title="Category">
          {mode === "footwear" && <Check label="All Sneakers" checked={has("category", "sneakers")} onChange={() => toggle("category", "sneakers")} />}
          {facets.categories.map((c) => <Check key={c.slug} label={c.name} checked={has("category", c.slug)} onChange={() => toggle("category", c.slug)} />)}
        </Group>
      )}
      {!preset.includes("gender") && (
        <Group title={mode === "footwear" ? "Men's / Women's / Unisex" : "Gender"}>
          {(["women", "men", "unisex"] as const).filter((g) => facets.genders.includes(g) || g !== "unisex").map((g) => (
            <Check key={g} label={g === "women" ? "Women's" : g === "men" ? "Men's" : "Unisex"} checked={has("gender", g)} onChange={() => toggle("gender", g)} />
          ))}
        </Group>
      )}
      {facets.brands.length > 1 && (
        <Group title="Brand">{facets.brands.map((b) => <Check key={b} label={b} checked={has("brand", b)} onChange={() => toggle("brand", b)} />)}</Group>
      )}
      {mode !== "clothing" && facets.us.length > 0 && (
        <Group title="US shoe size">
          <div className="grid grid-cols-4 gap-1.5">{facets.us.map((s) => <Chip key={s} label={s} active={has("us", s)} onClick={() => toggle("us", s)} />)}</div>
          <p className="mt-2 text-[11px] text-ink-soft">US men&apos;s sizing. Women add 1.5.</p>
        </Group>
      )}
      {mode !== "clothing" && facets.eu.length > 0 && (
        <Group title="EU shoe size" defaultOpen={false}>
          <div className="grid grid-cols-4 gap-1.5">{facets.eu.map((s) => <Chip key={s} label={s} active={has("eu", s)} onClick={() => toggle("eu", s)} />)}</div>
        </Group>
      )}
      {mode !== "footwear" && facets.clothingSizes.length > 0 && (
        <Group title="Clothing size">
          <div className="grid grid-cols-3 gap-1.5">{facets.clothingSizes.map((s) => <Chip key={s} label={s} active={has("size", s)} onClick={() => toggle("size", s)} />)}</div>
        </Group>
      )}
      <Group title="Color">
        <div className="grid grid-cols-2 gap-2">
          {facets.colors.map((c) => (
            <button key={c.name} onClick={() => toggle("color", c.name)} aria-pressed={has("color", c.name)} className="flex items-center gap-2 text-left">
              <span className={cn("h-5 w-5 shrink-0 rounded-full border", has("color", c.name) ? "border-charcoal ring-1 ring-charcoal ring-offset-1" : "border-black/15")} style={{ background: c.hex }} />
              <span className="text-xs">{c.name}</span>
            </button>
          ))}
        </div>
      </Group>
      <Group title="Price">
        <form className="flex items-end gap-2" onSubmit={(e) => {
          e.preventDefault();
          const fd = new FormData(e.currentTarget);
          update((p) => {
            for (const k of ["min", "max"]) { const v = String(fd.get(k) ?? ""); if (v) p.set(k, v); else p.delete(k); }
          });
        }}>
          <label className="flex-1"><span className="mb-1 block text-[11px] text-ink-soft">Min $</span><input name="min" type="number" min={0} defaultValue={filters.min ?? ""} className="input h-9" /></label>
          <label className="flex-1"><span className="mb-1 block text-[11px] text-ink-soft">Max $</span><input name="max" type="number" min={0} defaultValue={filters.max ?? ""} placeholder={String(facets.priceMax)} className="input h-9" /></label>
          <button className="h-9 border border-charcoal px-3 text-xs">Go</button>
        </form>
      </Group>
      {facets.styles.length > 1 && (
        <Group title="Style" defaultOpen={false}>{facets.styles.map((s) => <Check key={s} label={s} checked={has("style", s)} onChange={() => toggle("style", s)} />)}</Group>
      )}
      <Group title="Availability & more">
        <Check label="In stock only" checked={params.get("avail") === "in"} onChange={() => flag("avail", "in")} />
        {!preset.includes("isNew") && <Check label="New Arrivals" checked={params.get("new") === "1"} onChange={() => flag("new", "1")} />}
        <Check label="Best Sellers" checked={params.get("best") === "1"} onChange={() => flag("best", "1")} />
        {!preset.includes("sale") && <Check label="On sale" checked={params.get("sale") === "1"} onChange={() => flag("sale", "1")} />}
      </Group>
    </div>
  );

  return (
    <>
      <div className="mb-6 flex items-center justify-between gap-3 border-y border-charcoal/10 py-3 lg:col-span-2">
        <button onClick={() => setOpen(true)} className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] lg:hidden">
          Filters{activeCount ? ` (${activeCount})` : ""}
        </button>
        <p className="hidden text-xs text-ink-soft lg:block" aria-live="polite">{count} {count === 1 ? "product" : "products"}</p>
        <div className="flex items-center gap-4">
          {activeCount > 0 && <button onClick={() => update((p) => { for (const k of [...p.keys()]) if (k !== "q") p.delete(k); })} className="hidden text-xs underline underline-offset-4 sm:block">Clear filters</button>}
          <label className="flex items-center gap-2 text-xs">
            <span className="text-ink-soft">Sort</span>
            <select value={filters.sort} onChange={(e) => update((p) => (e.target.value === "featured" ? p.delete("sort") : p.set("sort", e.target.value)))}
              className="border-0 bg-transparent py-1 pr-6 text-xs font-medium outline-none">
              {SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </label>
        </div>
      </div>

      <aside className="hidden lg:block" aria-label="Filters">{panel}</aside>

      {open && (
        <div className="fixed inset-0 z-[75] lg:hidden" role="dialog" aria-modal="true" aria-label="Filters">
          <div className="absolute inset-0 bg-charcoal/40" onClick={() => setOpen(false)} aria-hidden />
          <div className="absolute inset-x-0 bottom-0 flex max-h-[88vh] flex-col bg-cream">
            <div className="flex items-center justify-between border-b border-charcoal/10 px-5 py-4">
              <p className="text-sm font-semibold uppercase tracking-[0.14em]">Filters</p>
              <button onClick={() => setOpen(false)} aria-label="Close filters"><CloseIcon /></button>
            </div>
            <div className="flex-1 overflow-y-auto px-5 py-2">{panel}</div>
            <div className="grid grid-cols-2 gap-3 border-t border-charcoal/10 p-4">
              <button className="btn-outline" onClick={() => router.replace(basePath)}>Clear</button>
              <button className="btn-dark" onClick={() => setOpen(false)}>Show {count}</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function Group({ title, children, defaultOpen = true }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-charcoal/10 py-4">
      <button onClick={() => setOpen(!open)} aria-expanded={open} className="flex w-full items-center justify-between text-xs font-semibold uppercase tracking-[0.14em]">
        {title}<ChevronIcon className={cn("h-3.5 w-3.5 transition", open && "rotate-180")} />
      </button>
      {open && <div className="mt-3 space-y-2">{children}</div>}
    </div>
  );
}

function Check({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <label className="flex cursor-pointer items-center gap-2.5">
      <input type="checkbox" checked={checked} onChange={onChange} className="h-4 w-4 accent-charcoal" />
      <span>{label}</span>
    </label>
  );
}

function Chip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} aria-pressed={active} className={cn("h-9 border text-xs transition", active ? "border-charcoal bg-charcoal text-cream" : "border-charcoal/15 bg-white hover:border-charcoal")}>{label}</button>
  );
}
