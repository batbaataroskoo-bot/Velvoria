"use client";

import { useMemo, useState } from "react";
import type { ProductFull, Variant } from "@/lib/types";
import { cn, money } from "@/lib/format";
import { useStore } from "@/components/StoreProvider";
import { firstPhotoUrl } from "@/components/ProductMedia";
import { SizeGuideButton } from "@/components/SizeGuide";
import { useRouter } from "next/navigation";

export function sizeText(v: Variant, gender: string) {
  if (v.size.system !== "shoe") return v.size.label;
  return gender === "women" ? `W ${Number(v.size.us) + 1.5}` : `US ${v.size.us}`;
}

/** Colorway + size selection. Updates the chosen variant, price and stock live. */
export function VariantPicker({
  product, colorwayId, onColorway, compact = false, showBuyNow = true,
}: { product: ProductFull; colorwayId: string; onColorway: (id: string) => void; compact?: boolean; showBuyNow?: boolean }) {
  const { addToCart, notify } = useStore();
  const router = useRouter();
  const [sizeId, setSizeId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const isShoe = product.size_system === "shoe";
  const [showEU, setShowEU] = useState(false);

  const variants = useMemo(() => product.variants.filter((v) => v.colorway_id === colorwayId), [product, colorwayId]);
  const selected = variants.find((v) => v.size_id === sizeId) ?? (product.size_system === "one" ? variants[0] : undefined);
  const color = product.colorways.find((c) => c.id === colorwayId)!;
  const price = selected?.price_cents ?? product.price_cents;
  const soldOutColor = variants.every((v) => v.stock === 0);

  function add(buyNow = false) {
    if (!selected) { setError(isShoe ? "Please select a shoe size." : "Please select a size."); return; }
    if (selected.stock === 0) { setError("This size is sold out."); return; }
    addToCart({
      variantId: selected.id, productId: product.id, slug: product.slug, name: product.name,
      color: color.name, hex: color.hex, size: sizeText(selected, product.gender), priceCents: price,
      image: firstPhotoUrl(product, colorwayId), qty: 1, department: product.department,
      categorySlug: product.category?.slug ?? null, maxStock: selected.stock,
    });
    notify(`Added ${product.name} to your bag`);
    if (buyNow) router.push("/bag");
  }

  return (
    <div className="space-y-6">
      <div>
        <p className="mb-3 text-sm"><span className="text-ink-soft">{isShoe ? "Colorway" : "Color"}:</span> <span className="font-medium">{color.name}</span></p>
        <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Choose color">
          {product.colorways.map((c) => (
            <button
              key={c.id} role="radio" aria-checked={c.id === colorwayId} aria-label={c.name} title={c.name}
              onClick={() => { onColorway(c.id); setError(null); }}
              className={cn("h-9 w-9 rounded-full border-2 p-0.5 transition", c.id === colorwayId ? "border-charcoal" : "border-transparent hover:border-charcoal/30")}
            >
              <span className="block h-full w-full rounded-full border border-black/10" style={{ background: c.hex }} />
            </button>
          ))}
        </div>
      </div>

      {product.size_system !== "one" && (
        <div>
          <div className="mb-3 flex items-center justify-between text-sm">
            <span className="text-ink-soft">{isShoe ? "Shoe size" : "Size"}{selected ? <>: <span className="font-medium text-charcoal">{isShoe && showEU ? `EU ${selected.size.eu}` : sizeText(selected, product.gender)}</span></> : null}</span>
            <div className="flex items-center gap-4">
              {isShoe && (
                <div className="flex text-xs" role="group" aria-label="Size system">
                  {["US", "EU"].map((s) => (
                    <button key={s} onClick={() => setShowEU(s === "EU")} aria-pressed={showEU === (s === "EU")}
                      className={cn("px-2 py-1 border", showEU === (s === "EU") ? "border-charcoal bg-charcoal text-cream" : "border-charcoal/20")}>{s}</button>
                  ))}
                </div>
              )}
              <SizeGuideButton type={isShoe ? "shoe" : "clothing"} />
            </div>
          </div>
          <div className={cn("grid gap-2", isShoe ? "grid-cols-4 sm:grid-cols-5" : "grid-cols-3 sm:grid-cols-6")} role="radiogroup" aria-label="Choose size">
            {variants.map((v) => {
              const out = v.stock === 0;
              return (
                <button
                  key={v.id} role="radio" aria-checked={v.size_id === sizeId} disabled={out}
                  onClick={() => { setSizeId(v.size_id); setError(null); }}
                  className={cn(
                    "relative h-11 border text-sm transition",
                    v.size_id === sizeId ? "border-charcoal bg-charcoal text-cream" : "border-charcoal/15 bg-white hover:border-charcoal",
                    out && "cursor-not-allowed text-charcoal/30 line-through",
                  )}
                  aria-label={`${isShoe && showEU ? `EU ${v.size.eu}` : sizeText(v, product.gender)}${out ? " — sold out" : v.stock <= 3 ? ` — only ${v.stock} left` : ""}`}
                >
                  {isShoe && showEU ? v.size.eu : isShoe ? sizeText(v, product.gender).replace(/^US /, "") : v.size.label}
                  {!out && v.stock <= 3 && <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-peach" />}
                </button>
              );
            })}
          </div>
          {isShoe && <p className="mt-2 text-xs text-ink-soft">{product.gender === "women" ? "Women's US sizes shown." : "US men's sizes shown. Women: add 1.5."}</p>}
        </div>
      )}

      <p className="text-sm" aria-live="polite">
        {soldOutColor ? <span className="text-red-700">This colorway is sold out.</span>
          : selected ? (selected.stock === 0 ? <span className="text-red-700">Sold out in this size</span>
            : selected.stock <= 3 ? <span className="text-[#a4532f]">Only {selected.stock} left in this size</span>
            : <span className="text-[#4d5a43]">In stock — ready to ship</span>)
          : <span className="text-ink-soft">Select a size to see availability.</span>}
        {selected && <span className="ml-2 text-xs text-ink-soft">SKU {selected.sku}</span>}
      </p>

      {error && <p role="alert" className="text-sm text-red-700">{error}</p>}

      <div className={cn("grid gap-3", !compact && showBuyNow && "sm:grid-cols-2")}>
        <button className="btn-dark w-full" onClick={() => add(false)} disabled={soldOutColor}>Add to Bag — {money(price)}</button>
        {showBuyNow && !compact && <button className="btn-outline w-full" onClick={() => add(true)} disabled={soldOutColor}>Buy Now</button>}
      </div>

      {!compact && (
        // Sticky Add to Bag bar on mobile
        <div className="fixed inset-x-0 bottom-0 z-40 flex items-center gap-3 border-t border-charcoal/10 bg-cream/95 px-4 py-3 backdrop-blur lg:hidden">
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{product.name}</p>
            <p className="text-xs text-ink-soft">{color.name}{selected && product.size_system !== "one" ? ` · ${sizeText(selected, product.gender)}` : " · Select size"}</p>
          </div>
          <button className="btn-dark h-11 px-5" disabled={soldOutColor}
            onClick={() => { if (!selected) { setError(isShoe ? "Please select a shoe size." : "Please select a size."); document.querySelector('[aria-label="Choose size"]')?.scrollIntoView({ behavior: "smooth", block: "center" }); } else add(false); }}>
            Add — {money(price)}
          </button>
        </div>
      )}
    </div>
  );
}
